<table border="1">
	  <tr>
		<td colspan="2">Komórka 1</td>
		<td>Komórka 2</td>
	  </tr>
	  <tr>
		<td>Komórka 3</td>
		<td>Komórka 4</td>
		<td>Komórka 5</td>
	  </tr>
	</table>