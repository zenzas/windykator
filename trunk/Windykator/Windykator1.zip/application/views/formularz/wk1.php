<h1>Wezwanie o wyznaczeniu Dyrektora</h1>




W związku z postanowieniem Sądu Rejonowego Lublin - Zachód w Lublinie Sekcja
Egzekucyjno - Zabezpieczająca VIII Wydziału Cywilnego w Lublinie sygn. akt
VIII Co 5780/13 wyznaczającym Dyrektora Oddziału Zakładu Ubezpieczeń Społecznych
w Lublinie do łącznego prowadzenia egzekucji z wynagrodzenia za pracę dłużnika
Iwony Kosior (PESEL 73102701944) z wniosku wierzycieli: Zakładu Ubezpieczeń 
Społecznych Oddział w Lublinie, Pracowniczej Spółdzielni Mieszkaniowej "Kolejarz"
w Lublinie, wzywam do realizacji zajęć.
Jednocześnie informuję, iż wyegzekwowane środki należy przekazywać na rachunek
bankowy prowadzony przez Bank PKO BP S.A. nr:
61 1020 5590 0000 0302 8160 1019
Zgodnie z art. 773 § 3 ustawy z dnia 17 listopada 1964r. kodeks postępowania cywilnego
(Dz. U. z 1964r., Nr 43, poz. 296 z późn. zm.) w przypadku wystąpienia daszych zbiegów
egzekucji do tej samej rzeczy lub prawa majątkowego, łączne prowadzenie egzekucji
przejmuje organ egzekucyjny wyznaczony przy pierwszym zbiegu egzekucji.
W przypadku występowania przeszkód w realizacji zajęcia, organ egzekucyjny wzywa do ich
wskazania, w terminie 7 dni od otrzymania zawiadomienia.
Ponadto zawiadamiam, iż nienależyte wykonanie obowiązków związanych z egzekucją prawa majątkowego, zgodnie z art. 168e § 1-3
ustawy o postępowaniu egzekucyjnym w administracji (Dz. U. z 2005r., nr 229, poz. 1954 ze zm.), może pociągnąć za sobą
ukaranie odpowiedzialnego za realizację wyznaczonego pracownika, względnie bezpośredniego kierownika, bądź odpowiedzialnego członka 
zarządu, czy wspólnika - karą do wysokości 3800 zł. Kara ta może być powtarzana.




W załączeniu:
	kopia postanowienia z dnia 25 października 2013r. Sądu Rejonowego Lublin - Zachód w Lublinie sygn. akt VIII Co 5780/13

Do wiadomości:
	a/a 
