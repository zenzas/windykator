<div id="podglad_user">
	<p>
	<?=form_label('Nazwa', 'nazwa')?>
	<?=$user['nazwa']?>
</p>
<p>
	<?=form_label('Typ użytkownika', 'typ')?>
	<?=$user['nazwa_typ']?>
</p>
<p>
	<?=form_label('Login', 'login')?>
	<?=$user['login']?>
</p>
<p>
	<?=form_label('E-mail', 'email')?>
	<?=$user['email']?>
</p>
<p>
	<?=form_label('NIP', 'NIP')?>
	<?=$user['NIP']?>
</p>
<p>
	<?=form_label('PESEL', 'PESEL')?>
	<?=$user['PESEL']?>
</p>
<p>
	<?=form_label('Ulica', 'ulica') ?>
	<?=$user['ulica'] ?>
</p>
<p>
	<?=form_label('Nr domu', 'nr_dom') ?>
	<?=$user['nr_dom'] ?>
</p>
<p>
	<?=form_label('Nr lokalu', 'nr_lokal') ?>
	<?=$user['nr_lokal'] ?>
</p>
<p>
	<?=form_label('Miasto', 'miasto') ?>
	<?=$user['miasto'] ?>
</p>
<p>
	<?=form_label('Kod pocztowy', 'kod') ?>
	<?=$user['kod'] ?>
</p>
<p>
	<?=form_label('Nr telefonu', 'nr_telefonu') ?>
	<?=$user['nr_telefonu'] ?>
</p>
<p>
	<?=form_label('Nr telefonu', 'nr_rachunku') ?>
	<?=$user['nr_rachunku'] ?>
</p>
</div>