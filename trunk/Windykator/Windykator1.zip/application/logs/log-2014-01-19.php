<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-01-19 01:27:37 --> Config Class Initialized
DEBUG - 2014-01-19 01:27:37 --> Hooks Class Initialized
DEBUG - 2014-01-19 01:27:37 --> Utf8 Class Initialized
DEBUG - 2014-01-19 01:27:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 01:27:37 --> URI Class Initialized
DEBUG - 2014-01-19 01:27:37 --> Router Class Initialized
DEBUG - 2014-01-19 01:27:37 --> No URI present. Default controller set.
DEBUG - 2014-01-19 01:27:37 --> Output Class Initialized
DEBUG - 2014-01-19 01:27:37 --> Security Class Initialized
DEBUG - 2014-01-19 01:27:37 --> Input Class Initialized
DEBUG - 2014-01-19 01:27:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 01:27:37 --> Language Class Initialized
DEBUG - 2014-01-19 01:27:37 --> Loader Class Initialized
DEBUG - 2014-01-19 01:27:37 --> Helper loaded: url_helper
DEBUG - 2014-01-19 01:27:37 --> Helper loaded: form_helper
DEBUG - 2014-01-19 01:27:37 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 01:27:37 --> Database Driver Class Initialized
DEBUG - 2014-01-19 01:27:37 --> Session Class Initialized
DEBUG - 2014-01-19 01:27:38 --> Helper loaded: string_helper
DEBUG - 2014-01-19 01:27:38 --> A session cookie was not found.
DEBUG - 2014-01-19 01:27:38 --> Session routines successfully run
DEBUG - 2014-01-19 01:27:38 --> User Agent Class Initialized
DEBUG - 2014-01-19 01:27:38 --> Form Validation Class Initialized
DEBUG - 2014-01-19 01:27:38 --> Model Class Initialized
DEBUG - 2014-01-19 01:27:38 --> Model Class Initialized
DEBUG - 2014-01-19 01:27:38 --> Controller Class Initialized
DEBUG - 2014-01-19 01:27:38 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-19 01:27:38 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 01:27:38 --> Final output sent to browser
DEBUG - 2014-01-19 01:27:38 --> Total execution time: 0.0796
DEBUG - 2014-01-19 01:28:03 --> Config Class Initialized
DEBUG - 2014-01-19 01:28:03 --> Hooks Class Initialized
DEBUG - 2014-01-19 01:28:03 --> Utf8 Class Initialized
DEBUG - 2014-01-19 01:28:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 01:28:03 --> URI Class Initialized
DEBUG - 2014-01-19 01:28:03 --> Router Class Initialized
DEBUG - 2014-01-19 01:28:03 --> Output Class Initialized
DEBUG - 2014-01-19 01:28:03 --> Security Class Initialized
DEBUG - 2014-01-19 01:28:03 --> Input Class Initialized
DEBUG - 2014-01-19 01:28:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 01:28:03 --> Language Class Initialized
DEBUG - 2014-01-19 01:28:03 --> Loader Class Initialized
DEBUG - 2014-01-19 01:28:03 --> Helper loaded: url_helper
DEBUG - 2014-01-19 01:28:03 --> Helper loaded: form_helper
DEBUG - 2014-01-19 01:28:03 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 01:28:03 --> Database Driver Class Initialized
DEBUG - 2014-01-19 01:28:03 --> Session Class Initialized
DEBUG - 2014-01-19 01:28:03 --> Helper loaded: string_helper
DEBUG - 2014-01-19 01:28:03 --> Session routines successfully run
DEBUG - 2014-01-19 01:28:03 --> User Agent Class Initialized
DEBUG - 2014-01-19 01:28:03 --> Form Validation Class Initialized
DEBUG - 2014-01-19 01:28:03 --> Model Class Initialized
DEBUG - 2014-01-19 01:28:03 --> Model Class Initialized
DEBUG - 2014-01-19 01:28:03 --> Controller Class Initialized
DEBUG - 2014-01-19 01:28:03 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-19 01:28:03 --> Config Class Initialized
DEBUG - 2014-01-19 01:28:03 --> Hooks Class Initialized
DEBUG - 2014-01-19 01:28:03 --> Utf8 Class Initialized
DEBUG - 2014-01-19 01:28:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 01:28:03 --> URI Class Initialized
DEBUG - 2014-01-19 01:28:03 --> Router Class Initialized
DEBUG - 2014-01-19 01:28:03 --> Output Class Initialized
DEBUG - 2014-01-19 01:28:03 --> Security Class Initialized
DEBUG - 2014-01-19 01:28:03 --> Input Class Initialized
DEBUG - 2014-01-19 01:28:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 01:28:03 --> Language Class Initialized
DEBUG - 2014-01-19 01:28:03 --> Loader Class Initialized
DEBUG - 2014-01-19 01:28:03 --> Helper loaded: url_helper
DEBUG - 2014-01-19 01:28:03 --> Helper loaded: form_helper
DEBUG - 2014-01-19 01:28:03 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 01:28:03 --> Database Driver Class Initialized
DEBUG - 2014-01-19 01:28:03 --> Session Class Initialized
DEBUG - 2014-01-19 01:28:03 --> Helper loaded: string_helper
DEBUG - 2014-01-19 01:28:04 --> Session routines successfully run
DEBUG - 2014-01-19 01:28:04 --> User Agent Class Initialized
DEBUG - 2014-01-19 01:28:04 --> Form Validation Class Initialized
DEBUG - 2014-01-19 01:28:04 --> Model Class Initialized
DEBUG - 2014-01-19 01:28:04 --> Model Class Initialized
DEBUG - 2014-01-19 01:28:04 --> Controller Class Initialized
DEBUG - 2014-01-19 01:28:04 --> Model Class Initialized
DEBUG - 2014-01-19 01:28:04 --> Model Class Initialized
DEBUG - 2014-01-19 01:28:04 --> File loaded: application/views/wniosek/lista.php
DEBUG - 2014-01-19 01:28:04 --> File loaded: application/views/user/aktualnosci.php
DEBUG - 2014-01-19 01:28:04 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 01:28:04 --> Final output sent to browser
DEBUG - 2014-01-19 01:28:04 --> Total execution time: 0.1786
DEBUG - 2014-01-19 01:28:06 --> Config Class Initialized
DEBUG - 2014-01-19 01:28:06 --> Hooks Class Initialized
DEBUG - 2014-01-19 01:28:06 --> Utf8 Class Initialized
DEBUG - 2014-01-19 01:28:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 01:28:06 --> URI Class Initialized
DEBUG - 2014-01-19 01:28:06 --> Router Class Initialized
DEBUG - 2014-01-19 01:28:06 --> Output Class Initialized
DEBUG - 2014-01-19 01:28:06 --> Security Class Initialized
DEBUG - 2014-01-19 01:28:06 --> Input Class Initialized
DEBUG - 2014-01-19 01:28:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 01:28:06 --> Language Class Initialized
DEBUG - 2014-01-19 01:28:06 --> Loader Class Initialized
DEBUG - 2014-01-19 01:28:06 --> Helper loaded: url_helper
DEBUG - 2014-01-19 01:28:06 --> Helper loaded: form_helper
DEBUG - 2014-01-19 01:28:06 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 01:28:06 --> Database Driver Class Initialized
DEBUG - 2014-01-19 01:28:06 --> Session Class Initialized
DEBUG - 2014-01-19 01:28:06 --> Helper loaded: string_helper
DEBUG - 2014-01-19 01:28:06 --> Session routines successfully run
DEBUG - 2014-01-19 01:28:06 --> User Agent Class Initialized
DEBUG - 2014-01-19 01:28:06 --> Form Validation Class Initialized
DEBUG - 2014-01-19 01:28:06 --> Model Class Initialized
DEBUG - 2014-01-19 01:28:06 --> Model Class Initialized
DEBUG - 2014-01-19 01:28:06 --> Controller Class Initialized
DEBUG - 2014-01-19 01:28:06 --> Model Class Initialized
DEBUG - 2014-01-19 01:28:06 --> Model Class Initialized
DEBUG - 2014-01-19 01:28:06 --> Model Class Initialized
DEBUG - 2014-01-19 01:28:06 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 01:28:06 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 01:28:06 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 01:28:06 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 01:28:06 --> Final output sent to browser
DEBUG - 2014-01-19 01:28:06 --> Total execution time: 0.1582
DEBUG - 2014-01-19 01:28:51 --> Config Class Initialized
DEBUG - 2014-01-19 01:28:51 --> Hooks Class Initialized
DEBUG - 2014-01-19 01:28:51 --> Utf8 Class Initialized
DEBUG - 2014-01-19 01:28:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 01:28:51 --> URI Class Initialized
DEBUG - 2014-01-19 01:28:51 --> Router Class Initialized
DEBUG - 2014-01-19 01:28:51 --> Output Class Initialized
DEBUG - 2014-01-19 01:28:51 --> Security Class Initialized
DEBUG - 2014-01-19 01:28:51 --> Input Class Initialized
DEBUG - 2014-01-19 01:28:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 01:28:51 --> Language Class Initialized
DEBUG - 2014-01-19 01:28:51 --> Loader Class Initialized
DEBUG - 2014-01-19 01:28:51 --> Helper loaded: url_helper
DEBUG - 2014-01-19 01:28:51 --> Helper loaded: form_helper
DEBUG - 2014-01-19 01:28:51 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 01:28:51 --> Database Driver Class Initialized
DEBUG - 2014-01-19 01:28:51 --> Session Class Initialized
DEBUG - 2014-01-19 01:28:51 --> Helper loaded: string_helper
DEBUG - 2014-01-19 01:28:51 --> Session routines successfully run
DEBUG - 2014-01-19 01:28:51 --> User Agent Class Initialized
DEBUG - 2014-01-19 01:28:51 --> Form Validation Class Initialized
DEBUG - 2014-01-19 01:28:51 --> Model Class Initialized
DEBUG - 2014-01-19 01:28:51 --> Model Class Initialized
DEBUG - 2014-01-19 01:28:51 --> Controller Class Initialized
DEBUG - 2014-01-19 01:28:51 --> Model Class Initialized
DEBUG - 2014-01-19 01:28:51 --> Model Class Initialized
DEBUG - 2014-01-19 01:28:51 --> Model Class Initialized
DEBUG - 2014-01-19 01:28:51 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 01:28:51 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 01:28:51 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 01:28:51 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 01:28:51 --> Final output sent to browser
DEBUG - 2014-01-19 01:28:51 --> Total execution time: 0.0650
DEBUG - 2014-01-19 01:29:06 --> Config Class Initialized
DEBUG - 2014-01-19 01:29:06 --> Hooks Class Initialized
DEBUG - 2014-01-19 01:29:06 --> Utf8 Class Initialized
DEBUG - 2014-01-19 01:29:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 01:29:06 --> URI Class Initialized
DEBUG - 2014-01-19 01:29:06 --> Router Class Initialized
DEBUG - 2014-01-19 01:29:06 --> Output Class Initialized
DEBUG - 2014-01-19 01:29:06 --> Security Class Initialized
DEBUG - 2014-01-19 01:29:06 --> Input Class Initialized
DEBUG - 2014-01-19 01:29:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 01:29:06 --> Language Class Initialized
DEBUG - 2014-01-19 01:29:06 --> Loader Class Initialized
DEBUG - 2014-01-19 01:29:06 --> Helper loaded: url_helper
DEBUG - 2014-01-19 01:29:06 --> Helper loaded: form_helper
DEBUG - 2014-01-19 01:29:06 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 01:29:06 --> Database Driver Class Initialized
DEBUG - 2014-01-19 01:29:06 --> Session Class Initialized
DEBUG - 2014-01-19 01:29:06 --> Helper loaded: string_helper
DEBUG - 2014-01-19 01:29:06 --> Session routines successfully run
DEBUG - 2014-01-19 01:29:06 --> User Agent Class Initialized
DEBUG - 2014-01-19 01:29:06 --> Form Validation Class Initialized
DEBUG - 2014-01-19 01:29:06 --> Model Class Initialized
DEBUG - 2014-01-19 01:29:06 --> Model Class Initialized
DEBUG - 2014-01-19 01:29:06 --> Controller Class Initialized
DEBUG - 2014-01-19 01:29:06 --> Model Class Initialized
DEBUG - 2014-01-19 01:29:06 --> Model Class Initialized
DEBUG - 2014-01-19 01:29:06 --> Model Class Initialized
DEBUG - 2014-01-19 01:29:06 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 01:29:06 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 01:29:06 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 01:29:06 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 01:29:06 --> Final output sent to browser
DEBUG - 2014-01-19 01:29:06 --> Total execution time: 0.0567
DEBUG - 2014-01-19 01:29:07 --> Config Class Initialized
DEBUG - 2014-01-19 01:29:07 --> Hooks Class Initialized
DEBUG - 2014-01-19 01:29:07 --> Utf8 Class Initialized
DEBUG - 2014-01-19 01:29:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 01:29:07 --> URI Class Initialized
DEBUG - 2014-01-19 01:29:07 --> Router Class Initialized
DEBUG - 2014-01-19 01:29:07 --> Output Class Initialized
DEBUG - 2014-01-19 01:29:07 --> Security Class Initialized
DEBUG - 2014-01-19 01:29:07 --> Input Class Initialized
DEBUG - 2014-01-19 01:29:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 01:29:07 --> Language Class Initialized
DEBUG - 2014-01-19 01:29:07 --> Loader Class Initialized
DEBUG - 2014-01-19 01:29:07 --> Helper loaded: url_helper
DEBUG - 2014-01-19 01:29:07 --> Helper loaded: form_helper
DEBUG - 2014-01-19 01:29:07 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 01:29:07 --> Database Driver Class Initialized
DEBUG - 2014-01-19 01:29:07 --> Session Class Initialized
DEBUG - 2014-01-19 01:29:07 --> Helper loaded: string_helper
DEBUG - 2014-01-19 01:29:07 --> Session routines successfully run
DEBUG - 2014-01-19 01:29:07 --> User Agent Class Initialized
DEBUG - 2014-01-19 01:29:07 --> Form Validation Class Initialized
DEBUG - 2014-01-19 01:29:07 --> Model Class Initialized
DEBUG - 2014-01-19 01:29:07 --> Model Class Initialized
DEBUG - 2014-01-19 01:29:07 --> Controller Class Initialized
DEBUG - 2014-01-19 01:29:07 --> Model Class Initialized
DEBUG - 2014-01-19 01:29:07 --> Model Class Initialized
DEBUG - 2014-01-19 01:29:07 --> Model Class Initialized
DEBUG - 2014-01-19 01:29:07 --> File loaded: application/views/sprawa/dodaj.php
DEBUG - 2014-01-19 01:29:07 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 01:29:07 --> Final output sent to browser
DEBUG - 2014-01-19 01:29:07 --> Total execution time: 0.0636
DEBUG - 2014-01-19 01:29:11 --> Config Class Initialized
DEBUG - 2014-01-19 01:29:11 --> Hooks Class Initialized
DEBUG - 2014-01-19 01:29:11 --> Utf8 Class Initialized
DEBUG - 2014-01-19 01:29:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 01:29:11 --> URI Class Initialized
DEBUG - 2014-01-19 01:29:11 --> Router Class Initialized
DEBUG - 2014-01-19 01:29:11 --> Output Class Initialized
DEBUG - 2014-01-19 01:29:11 --> Security Class Initialized
DEBUG - 2014-01-19 01:29:11 --> Input Class Initialized
DEBUG - 2014-01-19 01:29:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 01:29:11 --> Language Class Initialized
DEBUG - 2014-01-19 01:29:11 --> Loader Class Initialized
DEBUG - 2014-01-19 01:29:11 --> Helper loaded: url_helper
DEBUG - 2014-01-19 01:29:11 --> Helper loaded: form_helper
DEBUG - 2014-01-19 01:29:11 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 01:29:11 --> Database Driver Class Initialized
DEBUG - 2014-01-19 01:29:11 --> Session Class Initialized
DEBUG - 2014-01-19 01:29:11 --> Helper loaded: string_helper
DEBUG - 2014-01-19 01:29:11 --> Session routines successfully run
DEBUG - 2014-01-19 01:29:11 --> User Agent Class Initialized
DEBUG - 2014-01-19 01:29:11 --> Form Validation Class Initialized
DEBUG - 2014-01-19 01:29:11 --> Model Class Initialized
DEBUG - 2014-01-19 01:29:11 --> Model Class Initialized
DEBUG - 2014-01-19 01:29:11 --> Controller Class Initialized
DEBUG - 2014-01-19 01:29:11 --> Model Class Initialized
DEBUG - 2014-01-19 01:29:11 --> Model Class Initialized
DEBUG - 2014-01-19 01:29:11 --> Model Class Initialized
DEBUG - 2014-01-19 01:29:11 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 01:29:11 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 01:29:11 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 01:29:11 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 01:29:11 --> Final output sent to browser
DEBUG - 2014-01-19 01:29:11 --> Total execution time: 0.0768
DEBUG - 2014-01-19 01:29:21 --> Config Class Initialized
DEBUG - 2014-01-19 01:29:21 --> Hooks Class Initialized
DEBUG - 2014-01-19 01:29:21 --> Utf8 Class Initialized
DEBUG - 2014-01-19 01:29:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 01:29:21 --> URI Class Initialized
DEBUG - 2014-01-19 01:29:21 --> Router Class Initialized
DEBUG - 2014-01-19 01:29:21 --> Output Class Initialized
DEBUG - 2014-01-19 01:29:21 --> Security Class Initialized
DEBUG - 2014-01-19 01:29:21 --> Input Class Initialized
DEBUG - 2014-01-19 01:29:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 01:29:21 --> Language Class Initialized
DEBUG - 2014-01-19 01:29:21 --> Loader Class Initialized
DEBUG - 2014-01-19 01:29:21 --> Helper loaded: url_helper
DEBUG - 2014-01-19 01:29:21 --> Helper loaded: form_helper
DEBUG - 2014-01-19 01:29:21 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 01:29:21 --> Database Driver Class Initialized
DEBUG - 2014-01-19 01:29:21 --> Session Class Initialized
DEBUG - 2014-01-19 01:29:21 --> Helper loaded: string_helper
DEBUG - 2014-01-19 01:29:21 --> Session routines successfully run
DEBUG - 2014-01-19 01:29:21 --> User Agent Class Initialized
DEBUG - 2014-01-19 01:29:21 --> Form Validation Class Initialized
DEBUG - 2014-01-19 01:29:21 --> Model Class Initialized
DEBUG - 2014-01-19 01:29:21 --> Model Class Initialized
DEBUG - 2014-01-19 01:29:21 --> Controller Class Initialized
DEBUG - 2014-01-19 01:29:21 --> Model Class Initialized
DEBUG - 2014-01-19 01:29:21 --> Model Class Initialized
DEBUG - 2014-01-19 01:29:21 --> Model Class Initialized
DEBUG - 2014-01-19 01:29:21 --> Model Class Initialized
DEBUG - 2014-01-19 01:29:21 --> File loaded: application/views/wplata/lista.php
DEBUG - 2014-01-19 01:29:21 --> File loaded: application/views/sprawa/szczegoly.php
DEBUG - 2014-01-19 01:29:21 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 01:29:21 --> Final output sent to browser
DEBUG - 2014-01-19 01:29:21 --> Total execution time: 0.1829
DEBUG - 2014-01-19 01:30:52 --> Config Class Initialized
DEBUG - 2014-01-19 01:30:52 --> Hooks Class Initialized
DEBUG - 2014-01-19 01:30:52 --> Utf8 Class Initialized
DEBUG - 2014-01-19 01:30:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 01:30:52 --> URI Class Initialized
DEBUG - 2014-01-19 01:30:52 --> Router Class Initialized
DEBUG - 2014-01-19 01:30:52 --> Output Class Initialized
DEBUG - 2014-01-19 01:30:52 --> Security Class Initialized
DEBUG - 2014-01-19 01:30:52 --> Input Class Initialized
DEBUG - 2014-01-19 01:30:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 01:30:52 --> Language Class Initialized
DEBUG - 2014-01-19 01:30:52 --> Loader Class Initialized
DEBUG - 2014-01-19 01:30:52 --> Helper loaded: url_helper
DEBUG - 2014-01-19 01:30:52 --> Helper loaded: form_helper
DEBUG - 2014-01-19 01:30:52 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 01:30:52 --> Database Driver Class Initialized
DEBUG - 2014-01-19 01:30:52 --> Session Class Initialized
DEBUG - 2014-01-19 01:30:52 --> Helper loaded: string_helper
DEBUG - 2014-01-19 01:30:52 --> Session routines successfully run
DEBUG - 2014-01-19 01:30:52 --> User Agent Class Initialized
DEBUG - 2014-01-19 01:30:52 --> Form Validation Class Initialized
DEBUG - 2014-01-19 01:30:52 --> Model Class Initialized
DEBUG - 2014-01-19 01:30:52 --> Model Class Initialized
DEBUG - 2014-01-19 01:30:52 --> Controller Class Initialized
DEBUG - 2014-01-19 01:30:52 --> Model Class Initialized
DEBUG - 2014-01-19 01:30:52 --> Model Class Initialized
DEBUG - 2014-01-19 01:30:52 --> Model Class Initialized
DEBUG - 2014-01-19 01:30:52 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 01:30:52 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 01:30:52 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 01:30:52 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 01:30:52 --> Final output sent to browser
DEBUG - 2014-01-19 01:30:52 --> Total execution time: 0.0556
DEBUG - 2014-01-19 01:33:42 --> Config Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Hooks Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Utf8 Class Initialized
DEBUG - 2014-01-19 01:33:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 01:33:42 --> URI Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Router Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Output Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Security Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Input Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 01:33:42 --> Language Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Loader Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Helper loaded: url_helper
DEBUG - 2014-01-19 01:33:42 --> Helper loaded: form_helper
DEBUG - 2014-01-19 01:33:42 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 01:33:42 --> Database Driver Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Session Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Helper loaded: string_helper
DEBUG - 2014-01-19 01:33:42 --> Session routines successfully run
DEBUG - 2014-01-19 01:33:42 --> User Agent Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Form Validation Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Model Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Model Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Controller Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Model Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Model Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Model Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Config Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Hooks Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Utf8 Class Initialized
DEBUG - 2014-01-19 01:33:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 01:33:42 --> URI Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Router Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Output Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Security Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Input Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 01:33:42 --> Language Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Loader Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Helper loaded: url_helper
DEBUG - 2014-01-19 01:33:42 --> Helper loaded: form_helper
DEBUG - 2014-01-19 01:33:42 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 01:33:42 --> Database Driver Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Session Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Helper loaded: string_helper
DEBUG - 2014-01-19 01:33:42 --> Session routines successfully run
DEBUG - 2014-01-19 01:33:42 --> User Agent Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Form Validation Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Model Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Model Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Controller Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Model Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Model Class Initialized
DEBUG - 2014-01-19 01:33:42 --> Model Class Initialized
DEBUG - 2014-01-19 01:33:42 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 01:33:42 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 01:33:42 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 01:33:42 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 01:33:42 --> Final output sent to browser
DEBUG - 2014-01-19 01:33:42 --> Total execution time: 0.0691
DEBUG - 2014-01-19 01:34:43 --> Config Class Initialized
DEBUG - 2014-01-19 01:34:43 --> Hooks Class Initialized
DEBUG - 2014-01-19 01:34:43 --> Utf8 Class Initialized
DEBUG - 2014-01-19 01:34:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 01:34:43 --> URI Class Initialized
DEBUG - 2014-01-19 01:34:43 --> Router Class Initialized
DEBUG - 2014-01-19 01:34:43 --> Output Class Initialized
DEBUG - 2014-01-19 01:34:43 --> Security Class Initialized
DEBUG - 2014-01-19 01:34:43 --> Input Class Initialized
DEBUG - 2014-01-19 01:34:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 01:34:43 --> Language Class Initialized
DEBUG - 2014-01-19 01:34:43 --> Loader Class Initialized
DEBUG - 2014-01-19 01:34:43 --> Helper loaded: url_helper
DEBUG - 2014-01-19 01:34:43 --> Helper loaded: form_helper
DEBUG - 2014-01-19 01:34:43 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 01:34:43 --> Database Driver Class Initialized
DEBUG - 2014-01-19 01:34:43 --> Session Class Initialized
DEBUG - 2014-01-19 01:34:43 --> Helper loaded: string_helper
DEBUG - 2014-01-19 01:34:43 --> Session routines successfully run
DEBUG - 2014-01-19 01:34:43 --> User Agent Class Initialized
DEBUG - 2014-01-19 01:34:43 --> Form Validation Class Initialized
DEBUG - 2014-01-19 01:34:43 --> Model Class Initialized
DEBUG - 2014-01-19 01:34:43 --> Model Class Initialized
DEBUG - 2014-01-19 01:34:43 --> Controller Class Initialized
DEBUG - 2014-01-19 01:34:43 --> Model Class Initialized
DEBUG - 2014-01-19 01:34:43 --> Model Class Initialized
DEBUG - 2014-01-19 01:34:43 --> Model Class Initialized
DEBUG - 2014-01-19 01:34:43 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 01:34:43 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 01:34:43 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 01:34:43 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 01:34:43 --> Final output sent to browser
DEBUG - 2014-01-19 01:34:43 --> Total execution time: 0.0578
DEBUG - 2014-01-19 01:40:48 --> Config Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Hooks Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Utf8 Class Initialized
DEBUG - 2014-01-19 01:40:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 01:40:48 --> URI Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Router Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Output Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Security Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Input Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 01:40:48 --> Language Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Loader Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Helper loaded: url_helper
DEBUG - 2014-01-19 01:40:48 --> Helper loaded: form_helper
DEBUG - 2014-01-19 01:40:48 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 01:40:48 --> Database Driver Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Session Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Helper loaded: string_helper
DEBUG - 2014-01-19 01:40:48 --> Session routines successfully run
DEBUG - 2014-01-19 01:40:48 --> User Agent Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Form Validation Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Model Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Model Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Controller Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Model Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Model Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Model Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Config Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Hooks Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Utf8 Class Initialized
DEBUG - 2014-01-19 01:40:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 01:40:48 --> URI Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Router Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Output Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Security Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Input Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 01:40:48 --> Language Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Loader Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Helper loaded: url_helper
DEBUG - 2014-01-19 01:40:48 --> Helper loaded: form_helper
DEBUG - 2014-01-19 01:40:48 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 01:40:48 --> Database Driver Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Session Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Helper loaded: string_helper
DEBUG - 2014-01-19 01:40:48 --> Session routines successfully run
DEBUG - 2014-01-19 01:40:48 --> User Agent Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Form Validation Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Model Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Model Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Controller Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Model Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Model Class Initialized
DEBUG - 2014-01-19 01:40:48 --> Model Class Initialized
DEBUG - 2014-01-19 01:40:48 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 01:40:48 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 01:40:48 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 01:40:48 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 01:40:48 --> Final output sent to browser
DEBUG - 2014-01-19 01:40:48 --> Total execution time: 0.0740
DEBUG - 2014-01-19 01:40:53 --> Config Class Initialized
DEBUG - 2014-01-19 01:40:53 --> Hooks Class Initialized
DEBUG - 2014-01-19 01:40:53 --> Utf8 Class Initialized
DEBUG - 2014-01-19 01:40:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 01:40:53 --> URI Class Initialized
DEBUG - 2014-01-19 01:40:53 --> Router Class Initialized
DEBUG - 2014-01-19 01:40:53 --> Output Class Initialized
DEBUG - 2014-01-19 01:40:53 --> Security Class Initialized
DEBUG - 2014-01-19 01:40:53 --> Input Class Initialized
DEBUG - 2014-01-19 01:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 01:40:53 --> Language Class Initialized
DEBUG - 2014-01-19 01:40:53 --> Loader Class Initialized
DEBUG - 2014-01-19 01:40:53 --> Helper loaded: url_helper
DEBUG - 2014-01-19 01:40:53 --> Helper loaded: form_helper
DEBUG - 2014-01-19 01:40:53 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 01:40:53 --> Database Driver Class Initialized
DEBUG - 2014-01-19 01:40:53 --> Session Class Initialized
DEBUG - 2014-01-19 01:40:53 --> Helper loaded: string_helper
DEBUG - 2014-01-19 01:40:53 --> Session routines successfully run
DEBUG - 2014-01-19 01:40:53 --> User Agent Class Initialized
DEBUG - 2014-01-19 01:40:53 --> Form Validation Class Initialized
DEBUG - 2014-01-19 01:40:53 --> Model Class Initialized
DEBUG - 2014-01-19 01:40:53 --> Model Class Initialized
DEBUG - 2014-01-19 01:40:53 --> Controller Class Initialized
DEBUG - 2014-01-19 01:40:53 --> Model Class Initialized
DEBUG - 2014-01-19 01:40:53 --> Model Class Initialized
DEBUG - 2014-01-19 01:40:53 --> Model Class Initialized
DEBUG - 2014-01-19 01:40:53 --> File loaded: application/views/sprawa/edytuj.php
DEBUG - 2014-01-19 01:40:53 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 01:40:53 --> Final output sent to browser
DEBUG - 2014-01-19 01:40:53 --> Total execution time: 0.0921
DEBUG - 2014-01-19 01:41:26 --> Config Class Initialized
DEBUG - 2014-01-19 01:41:26 --> Hooks Class Initialized
DEBUG - 2014-01-19 01:41:26 --> Utf8 Class Initialized
DEBUG - 2014-01-19 01:41:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 01:41:26 --> URI Class Initialized
DEBUG - 2014-01-19 01:41:26 --> Router Class Initialized
DEBUG - 2014-01-19 01:41:26 --> Output Class Initialized
DEBUG - 2014-01-19 01:41:26 --> Security Class Initialized
DEBUG - 2014-01-19 01:41:26 --> Input Class Initialized
DEBUG - 2014-01-19 01:41:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 01:41:26 --> Language Class Initialized
DEBUG - 2014-01-19 01:41:26 --> Loader Class Initialized
DEBUG - 2014-01-19 01:41:26 --> Helper loaded: url_helper
DEBUG - 2014-01-19 01:41:26 --> Helper loaded: form_helper
DEBUG - 2014-01-19 01:41:26 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 01:41:26 --> Database Driver Class Initialized
DEBUG - 2014-01-19 01:41:26 --> Session Class Initialized
DEBUG - 2014-01-19 01:41:26 --> Helper loaded: string_helper
DEBUG - 2014-01-19 01:41:26 --> Session routines successfully run
DEBUG - 2014-01-19 01:41:26 --> User Agent Class Initialized
DEBUG - 2014-01-19 01:41:26 --> Form Validation Class Initialized
DEBUG - 2014-01-19 01:41:26 --> Model Class Initialized
DEBUG - 2014-01-19 01:41:26 --> Model Class Initialized
DEBUG - 2014-01-19 01:41:26 --> Controller Class Initialized
DEBUG - 2014-01-19 01:41:26 --> Model Class Initialized
DEBUG - 2014-01-19 01:41:26 --> Model Class Initialized
DEBUG - 2014-01-19 01:41:26 --> Model Class Initialized
DEBUG - 2014-01-19 01:41:26 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 01:41:26 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 01:41:26 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 01:41:26 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 01:41:26 --> Final output sent to browser
DEBUG - 2014-01-19 01:41:26 --> Total execution time: 0.0747
DEBUG - 2014-01-19 01:42:04 --> Config Class Initialized
DEBUG - 2014-01-19 01:42:04 --> Hooks Class Initialized
DEBUG - 2014-01-19 01:42:04 --> Utf8 Class Initialized
DEBUG - 2014-01-19 01:42:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 01:42:04 --> URI Class Initialized
DEBUG - 2014-01-19 01:42:04 --> Router Class Initialized
DEBUG - 2014-01-19 01:42:04 --> Output Class Initialized
DEBUG - 2014-01-19 01:42:04 --> Security Class Initialized
DEBUG - 2014-01-19 01:42:04 --> Input Class Initialized
DEBUG - 2014-01-19 01:42:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 01:42:04 --> Language Class Initialized
DEBUG - 2014-01-19 01:42:04 --> Loader Class Initialized
DEBUG - 2014-01-19 01:42:04 --> Helper loaded: url_helper
DEBUG - 2014-01-19 01:42:04 --> Helper loaded: form_helper
DEBUG - 2014-01-19 01:42:04 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 01:42:04 --> Database Driver Class Initialized
DEBUG - 2014-01-19 01:42:04 --> Session Class Initialized
DEBUG - 2014-01-19 01:42:04 --> Helper loaded: string_helper
DEBUG - 2014-01-19 01:42:04 --> Session routines successfully run
DEBUG - 2014-01-19 01:42:04 --> User Agent Class Initialized
DEBUG - 2014-01-19 01:42:04 --> Form Validation Class Initialized
DEBUG - 2014-01-19 01:42:04 --> Model Class Initialized
DEBUG - 2014-01-19 01:42:04 --> Model Class Initialized
DEBUG - 2014-01-19 01:42:04 --> Controller Class Initialized
DEBUG - 2014-01-19 01:42:04 --> Model Class Initialized
DEBUG - 2014-01-19 01:42:04 --> Model Class Initialized
DEBUG - 2014-01-19 01:42:04 --> Model Class Initialized
DEBUG - 2014-01-19 01:42:04 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 01:42:04 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 01:42:04 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 01:42:04 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 01:42:04 --> Final output sent to browser
DEBUG - 2014-01-19 01:42:04 --> Total execution time: 0.0588
DEBUG - 2014-01-19 01:42:05 --> Config Class Initialized
DEBUG - 2014-01-19 01:42:05 --> Hooks Class Initialized
DEBUG - 2014-01-19 01:42:05 --> Utf8 Class Initialized
DEBUG - 2014-01-19 01:42:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 01:42:06 --> URI Class Initialized
DEBUG - 2014-01-19 01:42:06 --> Router Class Initialized
DEBUG - 2014-01-19 01:42:06 --> Output Class Initialized
DEBUG - 2014-01-19 01:42:06 --> Security Class Initialized
DEBUG - 2014-01-19 01:42:06 --> Input Class Initialized
DEBUG - 2014-01-19 01:42:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 01:42:06 --> Language Class Initialized
DEBUG - 2014-01-19 01:42:06 --> Loader Class Initialized
DEBUG - 2014-01-19 01:42:06 --> Helper loaded: url_helper
DEBUG - 2014-01-19 01:42:06 --> Helper loaded: form_helper
DEBUG - 2014-01-19 01:42:06 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 01:42:06 --> Database Driver Class Initialized
DEBUG - 2014-01-19 01:42:06 --> Session Class Initialized
DEBUG - 2014-01-19 01:42:06 --> Helper loaded: string_helper
DEBUG - 2014-01-19 01:42:06 --> Session routines successfully run
DEBUG - 2014-01-19 01:42:06 --> User Agent Class Initialized
DEBUG - 2014-01-19 01:42:06 --> Form Validation Class Initialized
DEBUG - 2014-01-19 01:42:06 --> Model Class Initialized
DEBUG - 2014-01-19 01:42:06 --> Model Class Initialized
DEBUG - 2014-01-19 01:42:06 --> Controller Class Initialized
DEBUG - 2014-01-19 01:42:06 --> Model Class Initialized
DEBUG - 2014-01-19 01:42:06 --> Model Class Initialized
DEBUG - 2014-01-19 01:42:06 --> Model Class Initialized
DEBUG - 2014-01-19 01:42:06 --> File loaded: application/views/sprawa/edytuj.php
DEBUG - 2014-01-19 01:42:06 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 01:42:06 --> Final output sent to browser
DEBUG - 2014-01-19 01:42:06 --> Total execution time: 0.0813
DEBUG - 2014-01-19 01:47:00 --> Config Class Initialized
DEBUG - 2014-01-19 01:47:00 --> Hooks Class Initialized
DEBUG - 2014-01-19 01:47:00 --> Utf8 Class Initialized
DEBUG - 2014-01-19 01:47:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 01:47:00 --> URI Class Initialized
DEBUG - 2014-01-19 01:47:00 --> Router Class Initialized
DEBUG - 2014-01-19 01:47:00 --> Output Class Initialized
DEBUG - 2014-01-19 01:47:00 --> Security Class Initialized
DEBUG - 2014-01-19 01:47:00 --> Input Class Initialized
DEBUG - 2014-01-19 01:47:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 01:47:00 --> Language Class Initialized
DEBUG - 2014-01-19 01:47:00 --> Loader Class Initialized
DEBUG - 2014-01-19 01:47:00 --> Helper loaded: url_helper
DEBUG - 2014-01-19 01:47:00 --> Helper loaded: form_helper
DEBUG - 2014-01-19 01:47:00 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 01:47:00 --> Database Driver Class Initialized
DEBUG - 2014-01-19 01:47:00 --> Session Class Initialized
DEBUG - 2014-01-19 01:47:00 --> Helper loaded: string_helper
DEBUG - 2014-01-19 01:47:00 --> Session routines successfully run
DEBUG - 2014-01-19 01:47:00 --> User Agent Class Initialized
DEBUG - 2014-01-19 01:47:00 --> Form Validation Class Initialized
DEBUG - 2014-01-19 01:47:00 --> Model Class Initialized
DEBUG - 2014-01-19 01:47:00 --> Model Class Initialized
DEBUG - 2014-01-19 01:47:00 --> Controller Class Initialized
DEBUG - 2014-01-19 01:47:00 --> Model Class Initialized
DEBUG - 2014-01-19 01:47:00 --> Model Class Initialized
DEBUG - 2014-01-19 01:47:00 --> Model Class Initialized
DEBUG - 2014-01-19 01:47:00 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 01:47:00 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 01:47:00 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 01:47:00 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 01:47:00 --> Final output sent to browser
DEBUG - 2014-01-19 01:47:00 --> Total execution time: 0.0696
DEBUG - 2014-01-19 01:47:02 --> Config Class Initialized
DEBUG - 2014-01-19 01:47:02 --> Hooks Class Initialized
DEBUG - 2014-01-19 01:47:02 --> Utf8 Class Initialized
DEBUG - 2014-01-19 01:47:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 01:47:02 --> URI Class Initialized
DEBUG - 2014-01-19 01:47:02 --> Router Class Initialized
DEBUG - 2014-01-19 01:47:02 --> Output Class Initialized
DEBUG - 2014-01-19 01:47:02 --> Security Class Initialized
DEBUG - 2014-01-19 01:47:02 --> Input Class Initialized
DEBUG - 2014-01-19 01:47:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 01:47:02 --> Language Class Initialized
DEBUG - 2014-01-19 01:47:02 --> Loader Class Initialized
DEBUG - 2014-01-19 01:47:02 --> Helper loaded: url_helper
DEBUG - 2014-01-19 01:47:02 --> Helper loaded: form_helper
DEBUG - 2014-01-19 01:47:02 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 01:47:02 --> Database Driver Class Initialized
DEBUG - 2014-01-19 01:47:02 --> Session Class Initialized
DEBUG - 2014-01-19 01:47:02 --> Helper loaded: string_helper
DEBUG - 2014-01-19 01:47:02 --> Session routines successfully run
DEBUG - 2014-01-19 01:47:02 --> User Agent Class Initialized
DEBUG - 2014-01-19 01:47:02 --> Form Validation Class Initialized
DEBUG - 2014-01-19 01:47:02 --> Model Class Initialized
DEBUG - 2014-01-19 01:47:02 --> Model Class Initialized
DEBUG - 2014-01-19 01:47:02 --> Controller Class Initialized
DEBUG - 2014-01-19 01:47:02 --> Model Class Initialized
DEBUG - 2014-01-19 01:47:02 --> Model Class Initialized
DEBUG - 2014-01-19 01:47:02 --> Model Class Initialized
DEBUG - 2014-01-19 01:47:02 --> Model Class Initialized
DEBUG - 2014-01-19 01:47:02 --> File loaded: application/views/wplata/lista.php
DEBUG - 2014-01-19 01:47:02 --> File loaded: application/views/sprawa/szczegoly.php
DEBUG - 2014-01-19 01:47:02 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 01:47:02 --> Final output sent to browser
DEBUG - 2014-01-19 01:47:02 --> Total execution time: 0.0967
DEBUG - 2014-01-19 01:52:07 --> Config Class Initialized
DEBUG - 2014-01-19 01:52:07 --> Hooks Class Initialized
DEBUG - 2014-01-19 01:52:07 --> Utf8 Class Initialized
DEBUG - 2014-01-19 01:52:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 01:52:07 --> URI Class Initialized
DEBUG - 2014-01-19 01:52:07 --> Router Class Initialized
DEBUG - 2014-01-19 01:52:07 --> Output Class Initialized
DEBUG - 2014-01-19 01:52:07 --> Security Class Initialized
DEBUG - 2014-01-19 01:52:07 --> Input Class Initialized
DEBUG - 2014-01-19 01:52:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 01:52:07 --> Language Class Initialized
DEBUG - 2014-01-19 01:52:07 --> Loader Class Initialized
DEBUG - 2014-01-19 01:52:07 --> Helper loaded: url_helper
DEBUG - 2014-01-19 01:52:07 --> Helper loaded: form_helper
DEBUG - 2014-01-19 01:52:07 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 01:52:07 --> Database Driver Class Initialized
DEBUG - 2014-01-19 01:52:07 --> Session Class Initialized
DEBUG - 2014-01-19 01:52:07 --> Helper loaded: string_helper
DEBUG - 2014-01-19 01:52:07 --> Session routines successfully run
DEBUG - 2014-01-19 01:52:07 --> User Agent Class Initialized
DEBUG - 2014-01-19 01:52:07 --> Form Validation Class Initialized
DEBUG - 2014-01-19 01:52:07 --> Model Class Initialized
DEBUG - 2014-01-19 01:52:07 --> Model Class Initialized
DEBUG - 2014-01-19 01:52:07 --> Controller Class Initialized
DEBUG - 2014-01-19 01:52:07 --> Model Class Initialized
DEBUG - 2014-01-19 01:52:07 --> Model Class Initialized
DEBUG - 2014-01-19 01:52:07 --> Model Class Initialized
DEBUG - 2014-01-19 01:52:07 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 01:52:07 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 01:52:07 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 01:52:07 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 01:52:07 --> Final output sent to browser
DEBUG - 2014-01-19 01:52:07 --> Total execution time: 0.0906
DEBUG - 2014-01-19 01:52:40 --> Config Class Initialized
DEBUG - 2014-01-19 01:52:40 --> Hooks Class Initialized
DEBUG - 2014-01-19 01:52:40 --> Utf8 Class Initialized
DEBUG - 2014-01-19 01:52:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 01:52:40 --> URI Class Initialized
DEBUG - 2014-01-19 01:52:40 --> Router Class Initialized
DEBUG - 2014-01-19 01:52:40 --> Output Class Initialized
DEBUG - 2014-01-19 01:52:40 --> Security Class Initialized
DEBUG - 2014-01-19 01:52:40 --> Input Class Initialized
DEBUG - 2014-01-19 01:52:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 01:52:40 --> Language Class Initialized
DEBUG - 2014-01-19 01:52:40 --> Loader Class Initialized
DEBUG - 2014-01-19 01:52:40 --> Helper loaded: url_helper
DEBUG - 2014-01-19 01:52:40 --> Helper loaded: form_helper
DEBUG - 2014-01-19 01:52:40 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 01:52:40 --> Database Driver Class Initialized
DEBUG - 2014-01-19 01:52:40 --> Session Class Initialized
DEBUG - 2014-01-19 01:52:40 --> Helper loaded: string_helper
DEBUG - 2014-01-19 01:52:40 --> Session routines successfully run
DEBUG - 2014-01-19 01:52:40 --> User Agent Class Initialized
DEBUG - 2014-01-19 01:52:40 --> Form Validation Class Initialized
DEBUG - 2014-01-19 01:52:40 --> Model Class Initialized
DEBUG - 2014-01-19 01:52:40 --> Model Class Initialized
DEBUG - 2014-01-19 01:52:40 --> Controller Class Initialized
DEBUG - 2014-01-19 01:52:40 --> Model Class Initialized
DEBUG - 2014-01-19 01:52:40 --> Model Class Initialized
DEBUG - 2014-01-19 01:52:40 --> Model Class Initialized
DEBUG - 2014-01-19 01:52:40 --> File loaded: application/views/sprawa/dodaj.php
DEBUG - 2014-01-19 01:52:40 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 01:52:40 --> Final output sent to browser
DEBUG - 2014-01-19 01:52:40 --> Total execution time: 0.0962
DEBUG - 2014-01-19 01:54:24 --> Config Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Hooks Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Utf8 Class Initialized
DEBUG - 2014-01-19 01:54:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 01:54:24 --> URI Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Router Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Output Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Security Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Input Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 01:54:24 --> Language Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Loader Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Helper loaded: url_helper
DEBUG - 2014-01-19 01:54:24 --> Helper loaded: form_helper
DEBUG - 2014-01-19 01:54:24 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 01:54:24 --> Database Driver Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Session Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Helper loaded: string_helper
DEBUG - 2014-01-19 01:54:24 --> Session routines successfully run
DEBUG - 2014-01-19 01:54:24 --> User Agent Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Form Validation Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Model Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Model Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Controller Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Model Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Model Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Model Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-19 01:54:24 --> Config Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Hooks Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Utf8 Class Initialized
DEBUG - 2014-01-19 01:54:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 01:54:24 --> URI Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Router Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Output Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Security Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Input Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 01:54:24 --> Language Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Loader Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Helper loaded: url_helper
DEBUG - 2014-01-19 01:54:24 --> Helper loaded: form_helper
DEBUG - 2014-01-19 01:54:24 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 01:54:24 --> Database Driver Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Session Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Helper loaded: string_helper
DEBUG - 2014-01-19 01:54:24 --> Session routines successfully run
DEBUG - 2014-01-19 01:54:24 --> User Agent Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Form Validation Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Model Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Model Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Controller Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Model Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Model Class Initialized
DEBUG - 2014-01-19 01:54:24 --> Model Class Initialized
DEBUG - 2014-01-19 01:54:24 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 01:54:24 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 01:54:24 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 01:54:24 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 01:54:24 --> Final output sent to browser
DEBUG - 2014-01-19 01:54:24 --> Total execution time: 0.0599
DEBUG - 2014-01-19 01:59:21 --> Config Class Initialized
DEBUG - 2014-01-19 01:59:21 --> Hooks Class Initialized
DEBUG - 2014-01-19 01:59:21 --> Utf8 Class Initialized
DEBUG - 2014-01-19 01:59:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 01:59:21 --> URI Class Initialized
DEBUG - 2014-01-19 01:59:21 --> Router Class Initialized
DEBUG - 2014-01-19 01:59:21 --> Output Class Initialized
DEBUG - 2014-01-19 01:59:21 --> Security Class Initialized
DEBUG - 2014-01-19 01:59:21 --> Input Class Initialized
DEBUG - 2014-01-19 01:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 01:59:21 --> Language Class Initialized
DEBUG - 2014-01-19 01:59:21 --> Loader Class Initialized
DEBUG - 2014-01-19 01:59:21 --> Helper loaded: url_helper
DEBUG - 2014-01-19 01:59:21 --> Helper loaded: form_helper
DEBUG - 2014-01-19 01:59:21 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 01:59:21 --> Database Driver Class Initialized
DEBUG - 2014-01-19 01:59:21 --> Session Class Initialized
DEBUG - 2014-01-19 01:59:21 --> Helper loaded: string_helper
DEBUG - 2014-01-19 01:59:21 --> Session routines successfully run
DEBUG - 2014-01-19 01:59:21 --> User Agent Class Initialized
DEBUG - 2014-01-19 01:59:21 --> Form Validation Class Initialized
DEBUG - 2014-01-19 01:59:21 --> Model Class Initialized
DEBUG - 2014-01-19 01:59:21 --> Model Class Initialized
DEBUG - 2014-01-19 01:59:21 --> Controller Class Initialized
DEBUG - 2014-01-19 01:59:21 --> Model Class Initialized
DEBUG - 2014-01-19 01:59:21 --> Model Class Initialized
DEBUG - 2014-01-19 01:59:21 --> Model Class Initialized
DEBUG - 2014-01-19 01:59:21 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-19 01:59:21 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 01:59:21 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 01:59:21 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 01:59:21 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 01:59:21 --> Final output sent to browser
DEBUG - 2014-01-19 01:59:21 --> Total execution time: 0.0779
DEBUG - 2014-01-19 01:59:53 --> Config Class Initialized
DEBUG - 2014-01-19 01:59:53 --> Hooks Class Initialized
DEBUG - 2014-01-19 01:59:53 --> Utf8 Class Initialized
DEBUG - 2014-01-19 01:59:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 01:59:53 --> URI Class Initialized
DEBUG - 2014-01-19 01:59:53 --> Router Class Initialized
DEBUG - 2014-01-19 01:59:53 --> Output Class Initialized
DEBUG - 2014-01-19 01:59:53 --> Security Class Initialized
DEBUG - 2014-01-19 01:59:53 --> Input Class Initialized
DEBUG - 2014-01-19 01:59:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 01:59:53 --> Language Class Initialized
DEBUG - 2014-01-19 01:59:53 --> Loader Class Initialized
DEBUG - 2014-01-19 01:59:53 --> Helper loaded: url_helper
DEBUG - 2014-01-19 01:59:53 --> Helper loaded: form_helper
DEBUG - 2014-01-19 01:59:53 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 01:59:53 --> Database Driver Class Initialized
DEBUG - 2014-01-19 01:59:53 --> Session Class Initialized
DEBUG - 2014-01-19 01:59:53 --> Helper loaded: string_helper
DEBUG - 2014-01-19 01:59:53 --> Session routines successfully run
DEBUG - 2014-01-19 01:59:53 --> User Agent Class Initialized
DEBUG - 2014-01-19 01:59:53 --> Form Validation Class Initialized
DEBUG - 2014-01-19 01:59:53 --> Model Class Initialized
DEBUG - 2014-01-19 01:59:53 --> Model Class Initialized
DEBUG - 2014-01-19 01:59:53 --> Controller Class Initialized
DEBUG - 2014-01-19 01:59:53 --> Model Class Initialized
DEBUG - 2014-01-19 01:59:53 --> Model Class Initialized
DEBUG - 2014-01-19 01:59:53 --> Model Class Initialized
DEBUG - 2014-01-19 01:59:53 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-19 01:59:53 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 01:59:53 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 01:59:53 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 01:59:53 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 01:59:53 --> Final output sent to browser
DEBUG - 2014-01-19 01:59:53 --> Total execution time: 0.0704
DEBUG - 2014-01-19 02:02:08 --> Config Class Initialized
DEBUG - 2014-01-19 02:02:08 --> Hooks Class Initialized
DEBUG - 2014-01-19 02:02:08 --> Utf8 Class Initialized
DEBUG - 2014-01-19 02:02:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 02:02:08 --> URI Class Initialized
DEBUG - 2014-01-19 02:02:08 --> Router Class Initialized
DEBUG - 2014-01-19 02:02:08 --> Output Class Initialized
DEBUG - 2014-01-19 02:02:08 --> Security Class Initialized
DEBUG - 2014-01-19 02:02:08 --> Input Class Initialized
DEBUG - 2014-01-19 02:02:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 02:02:08 --> Language Class Initialized
DEBUG - 2014-01-19 02:02:08 --> Loader Class Initialized
DEBUG - 2014-01-19 02:02:08 --> Helper loaded: url_helper
DEBUG - 2014-01-19 02:02:08 --> Helper loaded: form_helper
DEBUG - 2014-01-19 02:02:08 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 02:02:08 --> Database Driver Class Initialized
DEBUG - 2014-01-19 02:02:08 --> Session Class Initialized
DEBUG - 2014-01-19 02:02:08 --> Helper loaded: string_helper
DEBUG - 2014-01-19 02:02:08 --> Session routines successfully run
DEBUG - 2014-01-19 02:02:08 --> User Agent Class Initialized
DEBUG - 2014-01-19 02:02:08 --> Form Validation Class Initialized
DEBUG - 2014-01-19 02:02:08 --> Model Class Initialized
DEBUG - 2014-01-19 02:02:08 --> Model Class Initialized
DEBUG - 2014-01-19 02:02:08 --> Controller Class Initialized
DEBUG - 2014-01-19 02:02:08 --> Model Class Initialized
DEBUG - 2014-01-19 02:02:08 --> Model Class Initialized
DEBUG - 2014-01-19 02:02:08 --> Model Class Initialized
DEBUG - 2014-01-19 02:02:08 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 02:02:08 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 02:02:08 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 02:02:08 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 02:02:08 --> Final output sent to browser
DEBUG - 2014-01-19 02:02:08 --> Total execution time: 0.0750
DEBUG - 2014-01-19 02:21:53 --> Config Class Initialized
DEBUG - 2014-01-19 02:21:53 --> Hooks Class Initialized
DEBUG - 2014-01-19 02:21:53 --> Utf8 Class Initialized
DEBUG - 2014-01-19 02:21:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 02:21:53 --> URI Class Initialized
DEBUG - 2014-01-19 02:21:53 --> Router Class Initialized
DEBUG - 2014-01-19 02:21:53 --> Output Class Initialized
DEBUG - 2014-01-19 02:21:53 --> Security Class Initialized
DEBUG - 2014-01-19 02:21:53 --> Input Class Initialized
DEBUG - 2014-01-19 02:21:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 02:21:53 --> Language Class Initialized
DEBUG - 2014-01-19 02:21:53 --> Loader Class Initialized
DEBUG - 2014-01-19 02:21:53 --> Helper loaded: url_helper
DEBUG - 2014-01-19 02:21:53 --> Helper loaded: form_helper
DEBUG - 2014-01-19 02:21:53 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 02:21:53 --> Database Driver Class Initialized
DEBUG - 2014-01-19 02:21:53 --> Session Class Initialized
DEBUG - 2014-01-19 02:21:53 --> Helper loaded: string_helper
DEBUG - 2014-01-19 02:21:53 --> Session routines successfully run
DEBUG - 2014-01-19 02:21:53 --> User Agent Class Initialized
DEBUG - 2014-01-19 02:21:53 --> Form Validation Class Initialized
DEBUG - 2014-01-19 02:21:53 --> Model Class Initialized
DEBUG - 2014-01-19 02:21:53 --> Model Class Initialized
DEBUG - 2014-01-19 02:21:53 --> Controller Class Initialized
DEBUG - 2014-01-19 02:21:53 --> Model Class Initialized
DEBUG - 2014-01-19 02:21:53 --> Model Class Initialized
DEBUG - 2014-01-19 02:21:53 --> Model Class Initialized
DEBUG - 2014-01-19 02:21:53 --> File loaded: application/views/sprawa/edytuj.php
DEBUG - 2014-01-19 02:21:53 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 02:21:53 --> Final output sent to browser
DEBUG - 2014-01-19 02:21:53 --> Total execution time: 0.0657
DEBUG - 2014-01-19 02:21:57 --> Config Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Hooks Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Utf8 Class Initialized
DEBUG - 2014-01-19 02:21:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 02:21:57 --> URI Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Router Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Output Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Security Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Input Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 02:21:57 --> Language Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Loader Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Helper loaded: url_helper
DEBUG - 2014-01-19 02:21:57 --> Helper loaded: form_helper
DEBUG - 2014-01-19 02:21:57 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 02:21:57 --> Database Driver Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Session Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Helper loaded: string_helper
DEBUG - 2014-01-19 02:21:57 --> Session routines successfully run
DEBUG - 2014-01-19 02:21:57 --> User Agent Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Form Validation Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Model Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Model Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Controller Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Model Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Model Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Model Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Language file loaded: language/polish/form_validation_lang.php
ERROR - 2014-01-19 02:21:57 --> Severity: Notice  --> Undefined index: id_users_w C:\wamp\www\Windykator1\application\models\sprawy.php 322
ERROR - 2014-01-19 02:21:57 --> Severity: Notice  --> Undefined index: id_users_w C:\wamp\www\Windykator1\application\models\sprawy.php 325
ERROR - 2014-01-19 02:21:57 --> Severity: Notice  --> Undefined index: id_users_w C:\wamp\www\Windykator1\application\models\sprawy.php 322
ERROR - 2014-01-19 02:21:57 --> Severity: Notice  --> Undefined index: id_users_w C:\wamp\www\Windykator1\application\models\sprawy.php 325
DEBUG - 2014-01-19 02:21:57 --> Config Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Hooks Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Utf8 Class Initialized
DEBUG - 2014-01-19 02:21:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 02:21:57 --> URI Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Router Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Output Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Security Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Input Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 02:21:57 --> Language Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Loader Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Helper loaded: url_helper
DEBUG - 2014-01-19 02:21:57 --> Helper loaded: form_helper
DEBUG - 2014-01-19 02:21:57 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 02:21:57 --> Database Driver Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Session Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Helper loaded: string_helper
DEBUG - 2014-01-19 02:21:57 --> Session routines successfully run
DEBUG - 2014-01-19 02:21:57 --> User Agent Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Form Validation Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Model Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Model Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Controller Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Model Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Model Class Initialized
DEBUG - 2014-01-19 02:21:57 --> Model Class Initialized
DEBUG - 2014-01-19 02:21:57 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 02:21:57 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 02:21:57 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 02:21:57 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 02:21:57 --> Final output sent to browser
DEBUG - 2014-01-19 02:21:57 --> Total execution time: 0.0721
DEBUG - 2014-01-19 02:24:07 --> Config Class Initialized
DEBUG - 2014-01-19 02:24:07 --> Hooks Class Initialized
DEBUG - 2014-01-19 02:24:07 --> Utf8 Class Initialized
DEBUG - 2014-01-19 02:24:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 02:24:07 --> URI Class Initialized
DEBUG - 2014-01-19 02:24:07 --> Router Class Initialized
DEBUG - 2014-01-19 02:24:07 --> Output Class Initialized
DEBUG - 2014-01-19 02:24:07 --> Security Class Initialized
DEBUG - 2014-01-19 02:24:07 --> Input Class Initialized
DEBUG - 2014-01-19 02:24:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 02:24:07 --> Language Class Initialized
DEBUG - 2014-01-19 02:24:07 --> Loader Class Initialized
DEBUG - 2014-01-19 02:24:07 --> Helper loaded: url_helper
DEBUG - 2014-01-19 02:24:07 --> Helper loaded: form_helper
DEBUG - 2014-01-19 02:24:07 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 02:24:07 --> Database Driver Class Initialized
DEBUG - 2014-01-19 02:24:07 --> Session Class Initialized
DEBUG - 2014-01-19 02:24:07 --> Helper loaded: string_helper
DEBUG - 2014-01-19 02:24:07 --> Session routines successfully run
DEBUG - 2014-01-19 02:24:07 --> User Agent Class Initialized
DEBUG - 2014-01-19 02:24:07 --> Form Validation Class Initialized
DEBUG - 2014-01-19 02:24:07 --> Model Class Initialized
DEBUG - 2014-01-19 02:24:07 --> Model Class Initialized
DEBUG - 2014-01-19 02:24:07 --> Controller Class Initialized
DEBUG - 2014-01-19 02:24:07 --> Model Class Initialized
DEBUG - 2014-01-19 02:24:07 --> Model Class Initialized
DEBUG - 2014-01-19 02:24:07 --> Model Class Initialized
DEBUG - 2014-01-19 02:24:07 --> File loaded: application/views/sprawa/edytuj.php
DEBUG - 2014-01-19 02:24:07 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 02:24:07 --> Final output sent to browser
DEBUG - 2014-01-19 02:24:07 --> Total execution time: 0.0819
DEBUG - 2014-01-19 02:25:25 --> Config Class Initialized
DEBUG - 2014-01-19 02:25:25 --> Hooks Class Initialized
DEBUG - 2014-01-19 02:25:25 --> Utf8 Class Initialized
DEBUG - 2014-01-19 02:25:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 02:25:25 --> URI Class Initialized
DEBUG - 2014-01-19 02:25:25 --> Router Class Initialized
DEBUG - 2014-01-19 02:25:25 --> Output Class Initialized
DEBUG - 2014-01-19 02:25:25 --> Security Class Initialized
DEBUG - 2014-01-19 02:25:25 --> Input Class Initialized
DEBUG - 2014-01-19 02:25:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 02:25:25 --> Language Class Initialized
DEBUG - 2014-01-19 02:25:25 --> Loader Class Initialized
DEBUG - 2014-01-19 02:25:26 --> Helper loaded: url_helper
DEBUG - 2014-01-19 02:25:26 --> Helper loaded: form_helper
DEBUG - 2014-01-19 02:25:26 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 02:25:26 --> Database Driver Class Initialized
DEBUG - 2014-01-19 02:25:26 --> Session Class Initialized
DEBUG - 2014-01-19 02:25:26 --> Helper loaded: string_helper
DEBUG - 2014-01-19 02:25:26 --> Session routines successfully run
DEBUG - 2014-01-19 02:25:26 --> User Agent Class Initialized
DEBUG - 2014-01-19 02:25:26 --> Form Validation Class Initialized
DEBUG - 2014-01-19 02:25:26 --> Model Class Initialized
DEBUG - 2014-01-19 02:25:26 --> Model Class Initialized
DEBUG - 2014-01-19 02:25:26 --> Controller Class Initialized
DEBUG - 2014-01-19 02:25:26 --> Model Class Initialized
DEBUG - 2014-01-19 02:25:26 --> Model Class Initialized
DEBUG - 2014-01-19 02:25:26 --> Model Class Initialized
DEBUG - 2014-01-19 02:25:26 --> Language file loaded: language/polish/form_validation_lang.php
ERROR - 2014-01-19 02:25:26 --> Severity: Notice  --> Undefined index: organ_egzekucyjny C:\wamp\www\Windykator1\application\views\sprawa\edytuj.php 162
ERROR - 2014-01-19 02:25:26 --> Severity: Notice  --> Undefined index: data_tytulu C:\wamp\www\Windykator1\application\views\sprawa\edytuj.php 177
ERROR - 2014-01-19 02:25:26 --> Severity: Notice  --> Undefined index: tytul_wydanyPrzez C:\wamp\www\Windykator1\application\views\sprawa\edytuj.php 184
ERROR - 2014-01-19 02:25:26 --> Severity: Notice  --> Undefined index: organ_egzekucyjny C:\wamp\www\Windykator1\application\views\sprawa\edytuj.php 162
ERROR - 2014-01-19 02:25:26 --> Severity: Notice  --> Undefined index: data_tytulu C:\wamp\www\Windykator1\application\views\sprawa\edytuj.php 177
ERROR - 2014-01-19 02:25:26 --> Severity: Notice  --> Undefined index: tytul_wydanyPrzez C:\wamp\www\Windykator1\application\views\sprawa\edytuj.php 184
DEBUG - 2014-01-19 02:25:26 --> File loaded: application/views/sprawa/edytuj.php
DEBUG - 2014-01-19 02:25:26 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 02:25:26 --> Final output sent to browser
DEBUG - 2014-01-19 02:25:26 --> Total execution time: 0.0857
DEBUG - 2014-01-19 02:26:42 --> Config Class Initialized
DEBUG - 2014-01-19 02:26:42 --> Hooks Class Initialized
DEBUG - 2014-01-19 02:26:42 --> Utf8 Class Initialized
DEBUG - 2014-01-19 02:26:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 02:26:42 --> URI Class Initialized
DEBUG - 2014-01-19 02:26:42 --> Router Class Initialized
DEBUG - 2014-01-19 02:26:42 --> Output Class Initialized
DEBUG - 2014-01-19 02:26:42 --> Security Class Initialized
DEBUG - 2014-01-19 02:26:42 --> Input Class Initialized
DEBUG - 2014-01-19 02:26:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 02:26:42 --> Language Class Initialized
DEBUG - 2014-01-19 02:26:42 --> Loader Class Initialized
DEBUG - 2014-01-19 02:26:42 --> Helper loaded: url_helper
DEBUG - 2014-01-19 02:26:42 --> Helper loaded: form_helper
DEBUG - 2014-01-19 02:26:42 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 02:26:42 --> Database Driver Class Initialized
DEBUG - 2014-01-19 02:26:42 --> Session Class Initialized
DEBUG - 2014-01-19 02:26:42 --> Helper loaded: string_helper
DEBUG - 2014-01-19 02:26:42 --> Session routines successfully run
DEBUG - 2014-01-19 02:26:42 --> User Agent Class Initialized
DEBUG - 2014-01-19 02:26:42 --> Form Validation Class Initialized
DEBUG - 2014-01-19 02:26:42 --> Model Class Initialized
DEBUG - 2014-01-19 02:26:42 --> Model Class Initialized
DEBUG - 2014-01-19 02:26:42 --> Controller Class Initialized
DEBUG - 2014-01-19 02:26:42 --> Model Class Initialized
DEBUG - 2014-01-19 02:26:42 --> Model Class Initialized
DEBUG - 2014-01-19 02:26:42 --> Model Class Initialized
DEBUG - 2014-01-19 02:26:42 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-19 02:26:42 --> File loaded: application/views/sprawa/edytuj.php
DEBUG - 2014-01-19 02:26:42 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 02:26:42 --> Final output sent to browser
DEBUG - 2014-01-19 02:26:42 --> Total execution time: 0.1080
DEBUG - 2014-01-19 02:28:49 --> Config Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Hooks Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Utf8 Class Initialized
DEBUG - 2014-01-19 02:28:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 02:28:49 --> URI Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Router Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Output Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Security Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Input Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 02:28:49 --> Language Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Loader Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Helper loaded: url_helper
DEBUG - 2014-01-19 02:28:49 --> Helper loaded: form_helper
DEBUG - 2014-01-19 02:28:49 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 02:28:49 --> Database Driver Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Session Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Helper loaded: string_helper
DEBUG - 2014-01-19 02:28:49 --> Session routines successfully run
DEBUG - 2014-01-19 02:28:49 --> User Agent Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Form Validation Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Model Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Model Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Controller Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Model Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Model Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Model Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Language file loaded: language/polish/form_validation_lang.php
ERROR - 2014-01-19 02:28:49 --> Severity: Notice  --> Undefined index: id_users_w C:\wamp\www\Windykator1\application\models\sprawy.php 322
ERROR - 2014-01-19 02:28:49 --> Severity: Notice  --> Undefined index: id_users_w C:\wamp\www\Windykator1\application\models\sprawy.php 325
ERROR - 2014-01-19 02:28:49 --> Severity: Notice  --> Undefined index: id_users_w C:\wamp\www\Windykator1\application\models\sprawy.php 322
ERROR - 2014-01-19 02:28:49 --> Severity: Notice  --> Undefined index: id_users_w C:\wamp\www\Windykator1\application\models\sprawy.php 325
DEBUG - 2014-01-19 02:28:49 --> Config Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Hooks Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Utf8 Class Initialized
DEBUG - 2014-01-19 02:28:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 02:28:49 --> URI Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Router Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Output Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Security Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Input Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 02:28:49 --> Language Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Loader Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Helper loaded: url_helper
DEBUG - 2014-01-19 02:28:49 --> Helper loaded: form_helper
DEBUG - 2014-01-19 02:28:49 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 02:28:49 --> Database Driver Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Session Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Helper loaded: string_helper
DEBUG - 2014-01-19 02:28:49 --> Session routines successfully run
DEBUG - 2014-01-19 02:28:49 --> User Agent Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Form Validation Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Model Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Model Class Initialized
DEBUG - 2014-01-19 02:28:49 --> Controller Class Initialized
DEBUG - 2014-01-19 02:28:50 --> Model Class Initialized
DEBUG - 2014-01-19 02:28:50 --> Model Class Initialized
DEBUG - 2014-01-19 02:28:50 --> Model Class Initialized
DEBUG - 2014-01-19 02:28:50 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 02:28:50 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 02:28:50 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 02:28:50 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 02:28:50 --> Final output sent to browser
DEBUG - 2014-01-19 02:28:50 --> Total execution time: 0.0608
DEBUG - 2014-01-19 02:30:28 --> Config Class Initialized
DEBUG - 2014-01-19 02:30:28 --> Hooks Class Initialized
DEBUG - 2014-01-19 02:30:28 --> Utf8 Class Initialized
DEBUG - 2014-01-19 02:30:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 02:30:28 --> URI Class Initialized
DEBUG - 2014-01-19 02:30:28 --> Router Class Initialized
DEBUG - 2014-01-19 02:30:28 --> Output Class Initialized
DEBUG - 2014-01-19 02:30:28 --> Security Class Initialized
DEBUG - 2014-01-19 02:30:28 --> Input Class Initialized
DEBUG - 2014-01-19 02:30:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 02:30:28 --> Language Class Initialized
DEBUG - 2014-01-19 02:30:28 --> Loader Class Initialized
DEBUG - 2014-01-19 02:30:28 --> Helper loaded: url_helper
DEBUG - 2014-01-19 02:30:28 --> Helper loaded: form_helper
DEBUG - 2014-01-19 02:30:28 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 02:30:28 --> Database Driver Class Initialized
DEBUG - 2014-01-19 02:30:28 --> Session Class Initialized
DEBUG - 2014-01-19 02:30:28 --> Helper loaded: string_helper
DEBUG - 2014-01-19 02:30:28 --> Session routines successfully run
DEBUG - 2014-01-19 02:30:28 --> User Agent Class Initialized
DEBUG - 2014-01-19 02:30:28 --> Form Validation Class Initialized
DEBUG - 2014-01-19 02:30:28 --> Model Class Initialized
DEBUG - 2014-01-19 02:30:28 --> Model Class Initialized
DEBUG - 2014-01-19 02:30:28 --> Controller Class Initialized
DEBUG - 2014-01-19 02:30:28 --> Model Class Initialized
DEBUG - 2014-01-19 02:30:28 --> Model Class Initialized
DEBUG - 2014-01-19 02:30:28 --> Model Class Initialized
DEBUG - 2014-01-19 02:30:28 --> File loaded: application/views/sprawa/edytuj.php
DEBUG - 2014-01-19 02:30:28 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 02:30:28 --> Final output sent to browser
DEBUG - 2014-01-19 02:30:28 --> Total execution time: 0.0798
DEBUG - 2014-01-19 02:30:32 --> Config Class Initialized
DEBUG - 2014-01-19 02:30:32 --> Hooks Class Initialized
DEBUG - 2014-01-19 02:30:32 --> Utf8 Class Initialized
DEBUG - 2014-01-19 02:30:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 02:30:32 --> URI Class Initialized
DEBUG - 2014-01-19 02:30:32 --> Router Class Initialized
DEBUG - 2014-01-19 02:30:32 --> Output Class Initialized
DEBUG - 2014-01-19 02:30:32 --> Security Class Initialized
DEBUG - 2014-01-19 02:30:32 --> Input Class Initialized
DEBUG - 2014-01-19 02:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 02:30:32 --> Language Class Initialized
DEBUG - 2014-01-19 02:30:32 --> Loader Class Initialized
DEBUG - 2014-01-19 02:30:32 --> Helper loaded: url_helper
DEBUG - 2014-01-19 02:30:32 --> Helper loaded: form_helper
DEBUG - 2014-01-19 02:30:32 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 02:30:32 --> Database Driver Class Initialized
DEBUG - 2014-01-19 02:30:32 --> Session Class Initialized
DEBUG - 2014-01-19 02:30:32 --> Helper loaded: string_helper
DEBUG - 2014-01-19 02:30:32 --> Session routines successfully run
DEBUG - 2014-01-19 02:30:32 --> User Agent Class Initialized
DEBUG - 2014-01-19 02:30:32 --> Form Validation Class Initialized
DEBUG - 2014-01-19 02:30:32 --> Model Class Initialized
DEBUG - 2014-01-19 02:30:32 --> Model Class Initialized
DEBUG - 2014-01-19 02:30:32 --> Controller Class Initialized
DEBUG - 2014-01-19 02:30:32 --> Model Class Initialized
DEBUG - 2014-01-19 02:30:32 --> Model Class Initialized
DEBUG - 2014-01-19 02:30:32 --> Model Class Initialized
DEBUG - 2014-01-19 02:30:32 --> Model Class Initialized
DEBUG - 2014-01-19 02:30:32 --> File loaded: application/views/wplata/lista.php
DEBUG - 2014-01-19 02:30:32 --> File loaded: application/views/sprawa/szczegoly.php
DEBUG - 2014-01-19 02:30:32 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 02:30:32 --> Final output sent to browser
DEBUG - 2014-01-19 02:30:32 --> Total execution time: 0.0756
DEBUG - 2014-01-19 02:30:51 --> Config Class Initialized
DEBUG - 2014-01-19 02:30:51 --> Hooks Class Initialized
DEBUG - 2014-01-19 02:30:51 --> Utf8 Class Initialized
DEBUG - 2014-01-19 02:30:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 02:30:51 --> URI Class Initialized
DEBUG - 2014-01-19 02:30:51 --> Router Class Initialized
DEBUG - 2014-01-19 02:30:51 --> Output Class Initialized
DEBUG - 2014-01-19 02:30:51 --> Security Class Initialized
DEBUG - 2014-01-19 02:30:51 --> Input Class Initialized
DEBUG - 2014-01-19 02:30:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 02:30:51 --> Language Class Initialized
DEBUG - 2014-01-19 02:30:51 --> Loader Class Initialized
DEBUG - 2014-01-19 02:30:51 --> Helper loaded: url_helper
DEBUG - 2014-01-19 02:30:51 --> Helper loaded: form_helper
DEBUG - 2014-01-19 02:30:51 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 02:30:51 --> Database Driver Class Initialized
DEBUG - 2014-01-19 02:30:51 --> Session Class Initialized
DEBUG - 2014-01-19 02:30:51 --> Helper loaded: string_helper
DEBUG - 2014-01-19 02:30:51 --> Session routines successfully run
DEBUG - 2014-01-19 02:30:51 --> User Agent Class Initialized
DEBUG - 2014-01-19 02:30:51 --> Form Validation Class Initialized
DEBUG - 2014-01-19 02:30:51 --> Model Class Initialized
DEBUG - 2014-01-19 02:30:51 --> Model Class Initialized
DEBUG - 2014-01-19 02:30:51 --> Controller Class Initialized
DEBUG - 2014-01-19 02:30:51 --> Model Class Initialized
DEBUG - 2014-01-19 02:30:51 --> File loaded: application/views/wplata/szczegoly.php
DEBUG - 2014-01-19 02:30:51 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 02:30:51 --> Final output sent to browser
DEBUG - 2014-01-19 02:30:51 --> Total execution time: 0.1520
DEBUG - 2014-01-19 02:31:33 --> Config Class Initialized
DEBUG - 2014-01-19 02:31:33 --> Hooks Class Initialized
DEBUG - 2014-01-19 02:31:33 --> Utf8 Class Initialized
DEBUG - 2014-01-19 02:31:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 02:31:33 --> URI Class Initialized
DEBUG - 2014-01-19 02:31:33 --> Router Class Initialized
DEBUG - 2014-01-19 02:31:33 --> Output Class Initialized
DEBUG - 2014-01-19 02:31:33 --> Security Class Initialized
DEBUG - 2014-01-19 02:31:33 --> Input Class Initialized
DEBUG - 2014-01-19 02:31:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 02:31:33 --> Language Class Initialized
DEBUG - 2014-01-19 02:31:33 --> Loader Class Initialized
DEBUG - 2014-01-19 02:31:33 --> Helper loaded: url_helper
DEBUG - 2014-01-19 02:31:33 --> Helper loaded: form_helper
DEBUG - 2014-01-19 02:31:33 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 02:31:33 --> Database Driver Class Initialized
DEBUG - 2014-01-19 02:31:33 --> Session Class Initialized
DEBUG - 2014-01-19 02:31:33 --> Helper loaded: string_helper
DEBUG - 2014-01-19 02:31:33 --> Session routines successfully run
DEBUG - 2014-01-19 02:31:33 --> User Agent Class Initialized
DEBUG - 2014-01-19 02:31:33 --> Form Validation Class Initialized
DEBUG - 2014-01-19 02:31:33 --> Model Class Initialized
DEBUG - 2014-01-19 02:31:33 --> Model Class Initialized
DEBUG - 2014-01-19 02:31:33 --> Controller Class Initialized
DEBUG - 2014-01-19 02:31:33 --> Model Class Initialized
DEBUG - 2014-01-19 02:31:33 --> Model Class Initialized
DEBUG - 2014-01-19 02:31:33 --> Model Class Initialized
DEBUG - 2014-01-19 02:31:33 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 02:31:33 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 02:31:33 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 02:31:33 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 02:31:33 --> Final output sent to browser
DEBUG - 2014-01-19 02:31:33 --> Total execution time: 0.0802
DEBUG - 2014-01-19 02:31:35 --> Config Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Hooks Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Utf8 Class Initialized
DEBUG - 2014-01-19 02:31:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 02:31:35 --> URI Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Router Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Output Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Security Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Input Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 02:31:35 --> Language Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Loader Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Helper loaded: url_helper
DEBUG - 2014-01-19 02:31:35 --> Helper loaded: form_helper
DEBUG - 2014-01-19 02:31:35 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 02:31:35 --> Database Driver Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Session Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Helper loaded: string_helper
DEBUG - 2014-01-19 02:31:35 --> Session routines successfully run
DEBUG - 2014-01-19 02:31:35 --> User Agent Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Form Validation Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Model Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Model Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Controller Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Model Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Model Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Model Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-19 02:31:35 --> Config Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Hooks Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Utf8 Class Initialized
DEBUG - 2014-01-19 02:31:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 02:31:35 --> URI Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Router Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Output Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Security Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Input Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 02:31:35 --> Language Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Loader Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Helper loaded: url_helper
DEBUG - 2014-01-19 02:31:35 --> Helper loaded: form_helper
DEBUG - 2014-01-19 02:31:35 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 02:31:35 --> Database Driver Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Session Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Helper loaded: string_helper
DEBUG - 2014-01-19 02:31:35 --> Session routines successfully run
DEBUG - 2014-01-19 02:31:35 --> User Agent Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Form Validation Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Model Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Model Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Controller Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Model Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Model Class Initialized
DEBUG - 2014-01-19 02:31:35 --> Model Class Initialized
DEBUG - 2014-01-19 02:31:35 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 02:31:35 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 02:31:35 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 02:31:35 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 02:31:35 --> Final output sent to browser
DEBUG - 2014-01-19 02:31:35 --> Total execution time: 0.0536
DEBUG - 2014-01-19 02:36:35 --> Config Class Initialized
DEBUG - 2014-01-19 02:36:35 --> Hooks Class Initialized
DEBUG - 2014-01-19 02:36:35 --> Utf8 Class Initialized
DEBUG - 2014-01-19 02:36:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 02:36:35 --> URI Class Initialized
DEBUG - 2014-01-19 02:36:35 --> Router Class Initialized
DEBUG - 2014-01-19 02:36:35 --> Output Class Initialized
DEBUG - 2014-01-19 02:36:35 --> Security Class Initialized
DEBUG - 2014-01-19 02:36:35 --> Input Class Initialized
DEBUG - 2014-01-19 02:36:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 02:36:35 --> Language Class Initialized
DEBUG - 2014-01-19 02:36:35 --> Loader Class Initialized
DEBUG - 2014-01-19 02:36:35 --> Helper loaded: url_helper
DEBUG - 2014-01-19 02:36:35 --> Helper loaded: form_helper
DEBUG - 2014-01-19 02:36:35 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 02:36:35 --> Database Driver Class Initialized
DEBUG - 2014-01-19 02:36:35 --> Session Class Initialized
DEBUG - 2014-01-19 02:36:35 --> Helper loaded: string_helper
DEBUG - 2014-01-19 02:36:35 --> Session routines successfully run
DEBUG - 2014-01-19 02:36:35 --> User Agent Class Initialized
DEBUG - 2014-01-19 02:36:35 --> Form Validation Class Initialized
DEBUG - 2014-01-19 02:36:35 --> Model Class Initialized
DEBUG - 2014-01-19 02:36:35 --> Model Class Initialized
DEBUG - 2014-01-19 02:36:35 --> Controller Class Initialized
DEBUG - 2014-01-19 02:36:35 --> Model Class Initialized
DEBUG - 2014-01-19 02:36:35 --> Model Class Initialized
DEBUG - 2014-01-19 02:36:35 --> Model Class Initialized
DEBUG - 2014-01-19 02:36:35 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 02:36:35 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 02:36:35 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 02:36:35 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 02:36:35 --> Final output sent to browser
DEBUG - 2014-01-19 02:36:35 --> Total execution time: 0.0715
DEBUG - 2014-01-19 02:36:37 --> Config Class Initialized
DEBUG - 2014-01-19 02:36:37 --> Hooks Class Initialized
DEBUG - 2014-01-19 02:36:37 --> Utf8 Class Initialized
DEBUG - 2014-01-19 02:36:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 02:36:38 --> URI Class Initialized
DEBUG - 2014-01-19 02:36:38 --> Router Class Initialized
DEBUG - 2014-01-19 02:36:38 --> Output Class Initialized
DEBUG - 2014-01-19 02:36:38 --> Security Class Initialized
DEBUG - 2014-01-19 02:36:38 --> Input Class Initialized
DEBUG - 2014-01-19 02:36:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 02:36:38 --> Language Class Initialized
DEBUG - 2014-01-19 02:36:38 --> Loader Class Initialized
DEBUG - 2014-01-19 02:36:38 --> Helper loaded: url_helper
DEBUG - 2014-01-19 02:36:38 --> Helper loaded: form_helper
DEBUG - 2014-01-19 02:36:38 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 02:36:38 --> Database Driver Class Initialized
DEBUG - 2014-01-19 02:36:38 --> Session Class Initialized
DEBUG - 2014-01-19 02:36:38 --> Helper loaded: string_helper
DEBUG - 2014-01-19 02:36:38 --> Session routines successfully run
DEBUG - 2014-01-19 02:36:38 --> User Agent Class Initialized
DEBUG - 2014-01-19 02:36:38 --> Form Validation Class Initialized
DEBUG - 2014-01-19 02:36:38 --> Model Class Initialized
DEBUG - 2014-01-19 02:36:38 --> Model Class Initialized
DEBUG - 2014-01-19 02:36:38 --> Controller Class Initialized
DEBUG - 2014-01-19 02:36:38 --> Model Class Initialized
DEBUG - 2014-01-19 02:36:38 --> Model Class Initialized
DEBUG - 2014-01-19 02:36:38 --> Model Class Initialized
DEBUG - 2014-01-19 02:36:38 --> File loaded: application/views/sprawa/dodaj.php
DEBUG - 2014-01-19 02:36:38 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 02:36:38 --> Final output sent to browser
DEBUG - 2014-01-19 02:36:38 --> Total execution time: 0.0807
DEBUG - 2014-01-19 02:38:59 --> Config Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Hooks Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Utf8 Class Initialized
DEBUG - 2014-01-19 02:38:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 02:38:59 --> URI Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Router Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Output Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Security Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Input Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 02:38:59 --> Language Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Loader Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Helper loaded: url_helper
DEBUG - 2014-01-19 02:38:59 --> Helper loaded: form_helper
DEBUG - 2014-01-19 02:38:59 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 02:38:59 --> Database Driver Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Session Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Helper loaded: string_helper
DEBUG - 2014-01-19 02:38:59 --> Session routines successfully run
DEBUG - 2014-01-19 02:38:59 --> User Agent Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Form Validation Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Model Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Model Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Controller Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Model Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Model Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Model Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-19 02:38:59 --> Config Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Hooks Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Utf8 Class Initialized
DEBUG - 2014-01-19 02:38:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 02:38:59 --> URI Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Router Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Output Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Security Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Input Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 02:38:59 --> Language Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Loader Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Helper loaded: url_helper
DEBUG - 2014-01-19 02:38:59 --> Helper loaded: form_helper
DEBUG - 2014-01-19 02:38:59 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 02:38:59 --> Database Driver Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Session Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Helper loaded: string_helper
DEBUG - 2014-01-19 02:38:59 --> Session routines successfully run
DEBUG - 2014-01-19 02:38:59 --> User Agent Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Form Validation Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Model Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Model Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Controller Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Model Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Model Class Initialized
DEBUG - 2014-01-19 02:38:59 --> Model Class Initialized
DEBUG - 2014-01-19 02:38:59 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 02:38:59 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 02:38:59 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 02:38:59 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 02:38:59 --> Final output sent to browser
DEBUG - 2014-01-19 02:38:59 --> Total execution time: 0.0795
DEBUG - 2014-01-19 02:47:00 --> Config Class Initialized
DEBUG - 2014-01-19 02:47:00 --> Hooks Class Initialized
DEBUG - 2014-01-19 02:47:00 --> Utf8 Class Initialized
DEBUG - 2014-01-19 02:47:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 02:47:00 --> URI Class Initialized
DEBUG - 2014-01-19 02:47:00 --> Router Class Initialized
DEBUG - 2014-01-19 02:47:00 --> Output Class Initialized
DEBUG - 2014-01-19 02:47:00 --> Security Class Initialized
DEBUG - 2014-01-19 02:47:00 --> Input Class Initialized
DEBUG - 2014-01-19 02:47:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 02:47:00 --> Language Class Initialized
DEBUG - 2014-01-19 02:47:00 --> Loader Class Initialized
DEBUG - 2014-01-19 02:47:00 --> Helper loaded: url_helper
DEBUG - 2014-01-19 02:47:00 --> Helper loaded: form_helper
DEBUG - 2014-01-19 02:47:00 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 02:47:00 --> Database Driver Class Initialized
DEBUG - 2014-01-19 02:47:00 --> Session Class Initialized
DEBUG - 2014-01-19 02:47:00 --> Helper loaded: string_helper
DEBUG - 2014-01-19 02:47:00 --> Session routines successfully run
DEBUG - 2014-01-19 02:47:00 --> User Agent Class Initialized
DEBUG - 2014-01-19 02:47:00 --> Form Validation Class Initialized
DEBUG - 2014-01-19 02:47:00 --> Model Class Initialized
DEBUG - 2014-01-19 02:47:00 --> Model Class Initialized
DEBUG - 2014-01-19 02:47:00 --> Controller Class Initialized
DEBUG - 2014-01-19 02:47:00 --> Model Class Initialized
DEBUG - 2014-01-19 02:47:00 --> Model Class Initialized
DEBUG - 2014-01-19 02:47:00 --> Model Class Initialized
DEBUG - 2014-01-19 02:47:00 --> File loaded: application/views/sprawa/edytuj.php
DEBUG - 2014-01-19 02:47:00 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 02:47:00 --> Final output sent to browser
DEBUG - 2014-01-19 02:47:00 --> Total execution time: 0.0781
DEBUG - 2014-01-19 02:47:05 --> Config Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Hooks Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Utf8 Class Initialized
DEBUG - 2014-01-19 02:47:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 02:47:05 --> URI Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Router Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Output Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Security Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Input Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 02:47:05 --> Language Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Loader Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Helper loaded: url_helper
DEBUG - 2014-01-19 02:47:05 --> Helper loaded: form_helper
DEBUG - 2014-01-19 02:47:05 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 02:47:05 --> Database Driver Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Session Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Helper loaded: string_helper
DEBUG - 2014-01-19 02:47:05 --> Session routines successfully run
DEBUG - 2014-01-19 02:47:05 --> User Agent Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Form Validation Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Model Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Model Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Controller Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Model Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Model Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Model Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-19 02:47:05 --> Config Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Hooks Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Utf8 Class Initialized
DEBUG - 2014-01-19 02:47:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 02:47:05 --> URI Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Router Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Output Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Security Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Input Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 02:47:05 --> Language Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Loader Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Helper loaded: url_helper
DEBUG - 2014-01-19 02:47:05 --> Helper loaded: form_helper
DEBUG - 2014-01-19 02:47:05 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 02:47:05 --> Database Driver Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Session Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Helper loaded: string_helper
DEBUG - 2014-01-19 02:47:05 --> Session routines successfully run
DEBUG - 2014-01-19 02:47:05 --> User Agent Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Form Validation Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Model Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Model Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Controller Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Model Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Model Class Initialized
DEBUG - 2014-01-19 02:47:05 --> Model Class Initialized
DEBUG - 2014-01-19 02:47:05 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 02:47:05 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 02:47:05 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 02:47:05 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 02:47:05 --> Final output sent to browser
DEBUG - 2014-01-19 02:47:05 --> Total execution time: 0.0549
DEBUG - 2014-01-19 02:48:15 --> Config Class Initialized
DEBUG - 2014-01-19 02:48:15 --> Hooks Class Initialized
DEBUG - 2014-01-19 02:48:15 --> Utf8 Class Initialized
DEBUG - 2014-01-19 02:48:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 02:48:15 --> URI Class Initialized
DEBUG - 2014-01-19 02:48:15 --> Router Class Initialized
DEBUG - 2014-01-19 02:48:15 --> Output Class Initialized
DEBUG - 2014-01-19 02:48:15 --> Security Class Initialized
DEBUG - 2014-01-19 02:48:15 --> Input Class Initialized
DEBUG - 2014-01-19 02:48:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 02:48:15 --> Language Class Initialized
DEBUG - 2014-01-19 02:48:15 --> Loader Class Initialized
DEBUG - 2014-01-19 02:48:15 --> Helper loaded: url_helper
DEBUG - 2014-01-19 02:48:15 --> Helper loaded: form_helper
DEBUG - 2014-01-19 02:48:15 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 02:48:15 --> Database Driver Class Initialized
DEBUG - 2014-01-19 02:48:15 --> Session Class Initialized
DEBUG - 2014-01-19 02:48:15 --> Helper loaded: string_helper
DEBUG - 2014-01-19 02:48:15 --> Session routines successfully run
DEBUG - 2014-01-19 02:48:15 --> User Agent Class Initialized
DEBUG - 2014-01-19 02:48:15 --> Form Validation Class Initialized
DEBUG - 2014-01-19 02:48:15 --> Model Class Initialized
DEBUG - 2014-01-19 02:48:15 --> Model Class Initialized
DEBUG - 2014-01-19 02:48:15 --> Controller Class Initialized
DEBUG - 2014-01-19 02:48:15 --> Model Class Initialized
DEBUG - 2014-01-19 02:48:15 --> Model Class Initialized
DEBUG - 2014-01-19 02:48:15 --> Model Class Initialized
DEBUG - 2014-01-19 02:48:15 --> File loaded: application/views/sprawa/edytuj.php
DEBUG - 2014-01-19 02:48:15 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 02:48:15 --> Final output sent to browser
DEBUG - 2014-01-19 02:48:15 --> Total execution time: 0.0795
DEBUG - 2014-01-19 08:52:31 --> Config Class Initialized
DEBUG - 2014-01-19 08:52:31 --> Hooks Class Initialized
DEBUG - 2014-01-19 08:52:31 --> Utf8 Class Initialized
DEBUG - 2014-01-19 08:52:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 08:52:31 --> URI Class Initialized
DEBUG - 2014-01-19 08:52:31 --> Router Class Initialized
DEBUG - 2014-01-19 08:52:31 --> No URI present. Default controller set.
DEBUG - 2014-01-19 08:52:31 --> Output Class Initialized
DEBUG - 2014-01-19 08:52:31 --> Security Class Initialized
DEBUG - 2014-01-19 08:52:31 --> Input Class Initialized
DEBUG - 2014-01-19 08:52:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 08:52:31 --> Language Class Initialized
DEBUG - 2014-01-19 08:52:31 --> Loader Class Initialized
DEBUG - 2014-01-19 08:52:31 --> Helper loaded: url_helper
DEBUG - 2014-01-19 08:52:31 --> Helper loaded: form_helper
DEBUG - 2014-01-19 08:52:31 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 08:52:31 --> Database Driver Class Initialized
DEBUG - 2014-01-19 08:52:31 --> Session Class Initialized
DEBUG - 2014-01-19 08:52:31 --> Helper loaded: string_helper
DEBUG - 2014-01-19 08:52:31 --> A session cookie was not found.
DEBUG - 2014-01-19 08:52:31 --> Session routines successfully run
DEBUG - 2014-01-19 08:52:31 --> User Agent Class Initialized
DEBUG - 2014-01-19 08:52:31 --> Form Validation Class Initialized
DEBUG - 2014-01-19 08:52:31 --> Model Class Initialized
DEBUG - 2014-01-19 08:52:31 --> Model Class Initialized
DEBUG - 2014-01-19 08:52:31 --> Controller Class Initialized
DEBUG - 2014-01-19 08:52:31 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-19 08:52:31 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 08:52:31 --> Final output sent to browser
DEBUG - 2014-01-19 08:52:31 --> Total execution time: 0.1057
DEBUG - 2014-01-19 08:52:35 --> Config Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Hooks Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Utf8 Class Initialized
DEBUG - 2014-01-19 08:52:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 08:52:35 --> URI Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Router Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Output Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Security Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Input Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 08:52:35 --> Language Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Loader Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Helper loaded: url_helper
DEBUG - 2014-01-19 08:52:35 --> Helper loaded: form_helper
DEBUG - 2014-01-19 08:52:35 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 08:52:35 --> Database Driver Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Session Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Helper loaded: string_helper
DEBUG - 2014-01-19 08:52:35 --> Session routines successfully run
DEBUG - 2014-01-19 08:52:35 --> User Agent Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Form Validation Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Model Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Model Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Controller Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-19 08:52:35 --> Config Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Hooks Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Utf8 Class Initialized
DEBUG - 2014-01-19 08:52:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 08:52:35 --> URI Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Router Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Output Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Security Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Input Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 08:52:35 --> Language Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Loader Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Helper loaded: url_helper
DEBUG - 2014-01-19 08:52:35 --> Helper loaded: form_helper
DEBUG - 2014-01-19 08:52:35 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 08:52:35 --> Database Driver Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Session Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Helper loaded: string_helper
DEBUG - 2014-01-19 08:52:35 --> Session routines successfully run
DEBUG - 2014-01-19 08:52:35 --> User Agent Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Form Validation Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Model Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Model Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Controller Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Model Class Initialized
DEBUG - 2014-01-19 08:52:35 --> Model Class Initialized
DEBUG - 2014-01-19 08:52:35 --> File loaded: application/views/wniosek/lista.php
DEBUG - 2014-01-19 08:52:35 --> File loaded: application/views/user/aktualnosci.php
DEBUG - 2014-01-19 08:52:35 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 08:52:35 --> Final output sent to browser
DEBUG - 2014-01-19 08:52:35 --> Total execution time: 0.1789
DEBUG - 2014-01-19 08:52:39 --> Config Class Initialized
DEBUG - 2014-01-19 08:52:39 --> Hooks Class Initialized
DEBUG - 2014-01-19 08:52:39 --> Utf8 Class Initialized
DEBUG - 2014-01-19 08:52:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 08:52:39 --> URI Class Initialized
DEBUG - 2014-01-19 08:52:39 --> Router Class Initialized
DEBUG - 2014-01-19 08:52:39 --> Output Class Initialized
DEBUG - 2014-01-19 08:52:39 --> Security Class Initialized
DEBUG - 2014-01-19 08:52:39 --> Input Class Initialized
DEBUG - 2014-01-19 08:52:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 08:52:39 --> Language Class Initialized
DEBUG - 2014-01-19 08:52:39 --> Loader Class Initialized
DEBUG - 2014-01-19 08:52:40 --> Helper loaded: url_helper
DEBUG - 2014-01-19 08:52:40 --> Helper loaded: form_helper
DEBUG - 2014-01-19 08:52:40 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 08:52:40 --> Database Driver Class Initialized
DEBUG - 2014-01-19 08:52:40 --> Session Class Initialized
DEBUG - 2014-01-19 08:52:40 --> Helper loaded: string_helper
DEBUG - 2014-01-19 08:52:40 --> Session routines successfully run
DEBUG - 2014-01-19 08:52:40 --> User Agent Class Initialized
DEBUG - 2014-01-19 08:52:40 --> Form Validation Class Initialized
DEBUG - 2014-01-19 08:52:40 --> Model Class Initialized
DEBUG - 2014-01-19 08:52:40 --> Model Class Initialized
DEBUG - 2014-01-19 08:52:40 --> Controller Class Initialized
DEBUG - 2014-01-19 08:52:40 --> Model Class Initialized
DEBUG - 2014-01-19 08:52:40 --> Model Class Initialized
DEBUG - 2014-01-19 08:52:40 --> Model Class Initialized
DEBUG - 2014-01-19 08:52:40 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 08:52:40 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 08:52:40 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 08:52:40 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 08:52:40 --> Final output sent to browser
DEBUG - 2014-01-19 08:52:40 --> Total execution time: 0.1080
DEBUG - 2014-01-19 08:52:43 --> Config Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Hooks Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Utf8 Class Initialized
DEBUG - 2014-01-19 08:52:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 08:52:43 --> URI Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Router Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Output Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Security Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Input Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 08:52:43 --> Language Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Loader Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Helper loaded: url_helper
DEBUG - 2014-01-19 08:52:43 --> Helper loaded: form_helper
DEBUG - 2014-01-19 08:52:43 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 08:52:43 --> Database Driver Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Session Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Helper loaded: string_helper
DEBUG - 2014-01-19 08:52:43 --> Session routines successfully run
DEBUG - 2014-01-19 08:52:43 --> User Agent Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Form Validation Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Model Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Model Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Controller Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Model Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Model Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Model Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-19 08:52:43 --> Config Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Hooks Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Utf8 Class Initialized
DEBUG - 2014-01-19 08:52:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 08:52:43 --> URI Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Router Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Output Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Security Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Input Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 08:52:43 --> Language Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Loader Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Helper loaded: url_helper
DEBUG - 2014-01-19 08:52:43 --> Helper loaded: form_helper
DEBUG - 2014-01-19 08:52:43 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 08:52:43 --> Database Driver Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Session Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Helper loaded: string_helper
DEBUG - 2014-01-19 08:52:43 --> Session routines successfully run
DEBUG - 2014-01-19 08:52:43 --> User Agent Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Form Validation Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Model Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Model Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Controller Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Model Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Model Class Initialized
DEBUG - 2014-01-19 08:52:43 --> Model Class Initialized
DEBUG - 2014-01-19 08:52:43 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 08:52:43 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 08:52:43 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 08:52:43 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 08:52:43 --> Final output sent to browser
DEBUG - 2014-01-19 08:52:43 --> Total execution time: 0.0599
DEBUG - 2014-01-19 08:52:52 --> Config Class Initialized
DEBUG - 2014-01-19 08:52:52 --> Hooks Class Initialized
DEBUG - 2014-01-19 08:52:52 --> Utf8 Class Initialized
DEBUG - 2014-01-19 08:52:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 08:52:52 --> URI Class Initialized
DEBUG - 2014-01-19 08:52:52 --> Router Class Initialized
DEBUG - 2014-01-19 08:52:52 --> Output Class Initialized
DEBUG - 2014-01-19 08:52:52 --> Security Class Initialized
DEBUG - 2014-01-19 08:52:52 --> Input Class Initialized
DEBUG - 2014-01-19 08:52:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 08:52:52 --> Language Class Initialized
DEBUG - 2014-01-19 08:52:52 --> Loader Class Initialized
DEBUG - 2014-01-19 08:52:52 --> Helper loaded: url_helper
DEBUG - 2014-01-19 08:52:52 --> Helper loaded: form_helper
DEBUG - 2014-01-19 08:52:52 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 08:52:52 --> Database Driver Class Initialized
DEBUG - 2014-01-19 08:52:52 --> Session Class Initialized
DEBUG - 2014-01-19 08:52:52 --> Helper loaded: string_helper
DEBUG - 2014-01-19 08:52:52 --> Session routines successfully run
DEBUG - 2014-01-19 08:52:52 --> User Agent Class Initialized
DEBUG - 2014-01-19 08:52:52 --> Form Validation Class Initialized
DEBUG - 2014-01-19 08:52:52 --> Model Class Initialized
DEBUG - 2014-01-19 08:52:52 --> Model Class Initialized
DEBUG - 2014-01-19 08:52:52 --> Controller Class Initialized
DEBUG - 2014-01-19 08:52:52 --> Model Class Initialized
DEBUG - 2014-01-19 08:52:52 --> Model Class Initialized
DEBUG - 2014-01-19 08:52:52 --> Model Class Initialized
DEBUG - 2014-01-19 08:52:52 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-19 08:52:52 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 08:52:52 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 08:52:52 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 08:52:52 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 08:52:52 --> Final output sent to browser
DEBUG - 2014-01-19 08:52:52 --> Total execution time: 0.0682
DEBUG - 2014-01-19 08:55:05 --> Config Class Initialized
DEBUG - 2014-01-19 08:55:05 --> Hooks Class Initialized
DEBUG - 2014-01-19 08:55:05 --> Utf8 Class Initialized
DEBUG - 2014-01-19 08:55:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 08:55:05 --> URI Class Initialized
DEBUG - 2014-01-19 08:55:05 --> Router Class Initialized
DEBUG - 2014-01-19 08:55:05 --> Output Class Initialized
DEBUG - 2014-01-19 08:55:05 --> Security Class Initialized
DEBUG - 2014-01-19 08:55:05 --> Input Class Initialized
DEBUG - 2014-01-19 08:55:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 08:55:05 --> Language Class Initialized
DEBUG - 2014-01-19 08:55:05 --> Loader Class Initialized
DEBUG - 2014-01-19 08:55:05 --> Helper loaded: url_helper
DEBUG - 2014-01-19 08:55:05 --> Helper loaded: form_helper
DEBUG - 2014-01-19 08:55:05 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 08:55:05 --> Database Driver Class Initialized
DEBUG - 2014-01-19 08:55:05 --> Session Class Initialized
DEBUG - 2014-01-19 08:55:05 --> Helper loaded: string_helper
DEBUG - 2014-01-19 08:55:05 --> Session routines successfully run
DEBUG - 2014-01-19 08:55:05 --> User Agent Class Initialized
DEBUG - 2014-01-19 08:55:05 --> Form Validation Class Initialized
DEBUG - 2014-01-19 08:55:05 --> Model Class Initialized
DEBUG - 2014-01-19 08:55:05 --> Model Class Initialized
DEBUG - 2014-01-19 08:55:05 --> Controller Class Initialized
DEBUG - 2014-01-19 08:55:05 --> Model Class Initialized
DEBUG - 2014-01-19 08:55:05 --> Model Class Initialized
DEBUG - 2014-01-19 08:55:05 --> Model Class Initialized
DEBUG - 2014-01-19 08:55:05 --> File loaded: application/views/sprawa/edytuj.php
DEBUG - 2014-01-19 08:55:05 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 08:55:05 --> Final output sent to browser
DEBUG - 2014-01-19 08:55:05 --> Total execution time: 0.0952
DEBUG - 2014-01-19 08:55:38 --> Config Class Initialized
DEBUG - 2014-01-19 08:55:38 --> Hooks Class Initialized
DEBUG - 2014-01-19 08:55:38 --> Utf8 Class Initialized
DEBUG - 2014-01-19 08:55:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 08:55:38 --> URI Class Initialized
DEBUG - 2014-01-19 08:55:38 --> Router Class Initialized
DEBUG - 2014-01-19 08:55:38 --> Output Class Initialized
DEBUG - 2014-01-19 08:55:38 --> Security Class Initialized
DEBUG - 2014-01-19 08:55:38 --> Input Class Initialized
DEBUG - 2014-01-19 08:55:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 08:55:38 --> Language Class Initialized
DEBUG - 2014-01-19 08:55:38 --> Loader Class Initialized
DEBUG - 2014-01-19 08:55:38 --> Helper loaded: url_helper
DEBUG - 2014-01-19 08:55:38 --> Helper loaded: form_helper
DEBUG - 2014-01-19 08:55:38 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 08:55:38 --> Database Driver Class Initialized
DEBUG - 2014-01-19 08:55:38 --> Session Class Initialized
DEBUG - 2014-01-19 08:55:38 --> Helper loaded: string_helper
DEBUG - 2014-01-19 08:55:38 --> Session routines successfully run
DEBUG - 2014-01-19 08:55:38 --> User Agent Class Initialized
DEBUG - 2014-01-19 08:55:38 --> Form Validation Class Initialized
DEBUG - 2014-01-19 08:55:38 --> Model Class Initialized
DEBUG - 2014-01-19 08:55:38 --> Model Class Initialized
DEBUG - 2014-01-19 08:55:38 --> Controller Class Initialized
DEBUG - 2014-01-19 08:55:38 --> Model Class Initialized
DEBUG - 2014-01-19 08:55:38 --> Model Class Initialized
DEBUG - 2014-01-19 08:55:38 --> Model Class Initialized
DEBUG - 2014-01-19 08:55:38 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 08:55:38 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 08:55:38 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 08:55:38 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 08:55:38 --> Final output sent to browser
DEBUG - 2014-01-19 08:55:38 --> Total execution time: 0.0881
DEBUG - 2014-01-19 08:55:40 --> Config Class Initialized
DEBUG - 2014-01-19 08:55:40 --> Hooks Class Initialized
DEBUG - 2014-01-19 08:55:40 --> Utf8 Class Initialized
DEBUG - 2014-01-19 08:55:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 08:55:40 --> URI Class Initialized
DEBUG - 2014-01-19 08:55:40 --> Router Class Initialized
DEBUG - 2014-01-19 08:55:40 --> Output Class Initialized
DEBUG - 2014-01-19 08:55:40 --> Security Class Initialized
DEBUG - 2014-01-19 08:55:40 --> Input Class Initialized
DEBUG - 2014-01-19 08:55:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 08:55:40 --> Language Class Initialized
DEBUG - 2014-01-19 08:55:40 --> Loader Class Initialized
DEBUG - 2014-01-19 08:55:40 --> Helper loaded: url_helper
DEBUG - 2014-01-19 08:55:40 --> Helper loaded: form_helper
DEBUG - 2014-01-19 08:55:40 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 08:55:40 --> Database Driver Class Initialized
DEBUG - 2014-01-19 08:55:40 --> Session Class Initialized
DEBUG - 2014-01-19 08:55:40 --> Helper loaded: string_helper
DEBUG - 2014-01-19 08:55:40 --> Session routines successfully run
DEBUG - 2014-01-19 08:55:40 --> User Agent Class Initialized
DEBUG - 2014-01-19 08:55:40 --> Form Validation Class Initialized
DEBUG - 2014-01-19 08:55:40 --> Model Class Initialized
DEBUG - 2014-01-19 08:55:40 --> Model Class Initialized
DEBUG - 2014-01-19 08:55:40 --> Controller Class Initialized
DEBUG - 2014-01-19 08:55:40 --> Model Class Initialized
DEBUG - 2014-01-19 08:55:40 --> Model Class Initialized
DEBUG - 2014-01-19 08:55:40 --> Model Class Initialized
DEBUG - 2014-01-19 08:55:40 --> Model Class Initialized
DEBUG - 2014-01-19 08:55:40 --> File loaded: application/views/wplata/lista.php
DEBUG - 2014-01-19 08:55:40 --> File loaded: application/views/sprawa/szczegoly.php
DEBUG - 2014-01-19 08:55:40 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 08:55:40 --> Final output sent to browser
DEBUG - 2014-01-19 08:55:40 --> Total execution time: 0.0984
DEBUG - 2014-01-19 08:58:52 --> Config Class Initialized
DEBUG - 2014-01-19 08:58:52 --> Hooks Class Initialized
DEBUG - 2014-01-19 08:58:52 --> Utf8 Class Initialized
DEBUG - 2014-01-19 08:58:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 08:58:52 --> URI Class Initialized
DEBUG - 2014-01-19 08:58:52 --> Router Class Initialized
DEBUG - 2014-01-19 08:58:52 --> Output Class Initialized
DEBUG - 2014-01-19 08:58:52 --> Security Class Initialized
DEBUG - 2014-01-19 08:58:52 --> Input Class Initialized
DEBUG - 2014-01-19 08:58:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 08:58:52 --> Language Class Initialized
DEBUG - 2014-01-19 08:58:52 --> Loader Class Initialized
DEBUG - 2014-01-19 08:58:52 --> Helper loaded: url_helper
DEBUG - 2014-01-19 08:58:52 --> Helper loaded: form_helper
DEBUG - 2014-01-19 08:58:52 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 08:58:52 --> Database Driver Class Initialized
DEBUG - 2014-01-19 08:58:52 --> Session Class Initialized
DEBUG - 2014-01-19 08:58:52 --> Helper loaded: string_helper
DEBUG - 2014-01-19 08:58:52 --> Session routines successfully run
DEBUG - 2014-01-19 08:58:52 --> User Agent Class Initialized
DEBUG - 2014-01-19 08:58:52 --> Form Validation Class Initialized
DEBUG - 2014-01-19 08:58:52 --> Model Class Initialized
DEBUG - 2014-01-19 08:58:52 --> Model Class Initialized
DEBUG - 2014-01-19 08:58:52 --> Controller Class Initialized
DEBUG - 2014-01-19 08:58:52 --> Model Class Initialized
DEBUG - 2014-01-19 08:58:52 --> Model Class Initialized
DEBUG - 2014-01-19 08:58:52 --> Model Class Initialized
DEBUG - 2014-01-19 08:58:53 --> Config Class Initialized
DEBUG - 2014-01-19 08:58:53 --> Hooks Class Initialized
DEBUG - 2014-01-19 08:58:53 --> Utf8 Class Initialized
DEBUG - 2014-01-19 08:58:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 08:58:53 --> URI Class Initialized
DEBUG - 2014-01-19 08:58:53 --> Router Class Initialized
DEBUG - 2014-01-19 08:58:53 --> Output Class Initialized
DEBUG - 2014-01-19 08:58:53 --> Security Class Initialized
DEBUG - 2014-01-19 08:58:53 --> Input Class Initialized
DEBUG - 2014-01-19 08:58:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 08:58:53 --> Language Class Initialized
DEBUG - 2014-01-19 08:58:53 --> Loader Class Initialized
DEBUG - 2014-01-19 08:58:53 --> Helper loaded: url_helper
DEBUG - 2014-01-19 08:58:53 --> Helper loaded: form_helper
DEBUG - 2014-01-19 08:58:53 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 08:58:53 --> Database Driver Class Initialized
DEBUG - 2014-01-19 08:58:53 --> Session Class Initialized
DEBUG - 2014-01-19 08:58:53 --> Helper loaded: string_helper
DEBUG - 2014-01-19 08:58:53 --> A session cookie was not found.
DEBUG - 2014-01-19 08:58:53 --> Session routines successfully run
DEBUG - 2014-01-19 08:58:53 --> User Agent Class Initialized
DEBUG - 2014-01-19 08:58:53 --> Form Validation Class Initialized
DEBUG - 2014-01-19 08:58:53 --> Model Class Initialized
DEBUG - 2014-01-19 08:58:53 --> Model Class Initialized
DEBUG - 2014-01-19 08:58:53 --> Controller Class Initialized
DEBUG - 2014-01-19 08:58:53 --> Model Class Initialized
DEBUG - 2014-01-19 08:58:53 --> Model Class Initialized
DEBUG - 2014-01-19 08:58:53 --> Model Class Initialized
DEBUG - 2014-01-19 08:58:53 --> File loaded: application/views/formularz/kartaWierzyciela.php
DEBUG - 2014-01-19 08:58:53 --> File loaded: application/views/formularz/layoutWewnetrzny.php
DEBUG - 2014-01-19 08:58:53 --> Final output sent to browser
DEBUG - 2014-01-19 08:58:53 --> Total execution time: 0.1112
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: BODY C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: BODY>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined offset: -1 C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1150
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: DIV C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: ID>>CONTAINER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1003
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: DIV>>ID>>CONTAINER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: DIV C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: ID>>CONTAINER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1003
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: DIV>>ID>>CONTAINER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: DIV C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: ID>>HEADER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1003
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: DIV>>ID>>HEADER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: DIV C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: ID>>HEADER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1003
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: DIV>>ID>>HEADER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: direction C:\wamp\www\Windykator1\MPDF57\mpdf.php 18502
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: direction C:\wamp\www\Windykator1\MPDF57\mpdf.php 18502
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: DIV C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: CLASS>>CONTENT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CONTENT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: CLASS>>CONTENT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CONTENT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: DIV C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: DIV>>ID>>KARTAWIERZYCIELA C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: ID>>KARTAWIERZYCIELA C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1003
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: DIV>>ID>>KARTAWIERZYCIELA C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P>>CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P>>CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TABLE C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: CLASS>>UCZESTNICYW C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TABLE>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TABLE C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: CLASS>>UCZESTNICYW C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TABLE>>CLASS>>UCZESTNICYW C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TABLE>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined variable: miwnon C:\wamp\www\Windykator1\MPDF57\mpdf.php 23847
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined variable: mawnon C:\wamp\www\Windykator1\MPDF57\mpdf.php 23866
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined variable: mawnon C:\wamp\www\Windykator1\MPDF57\mpdf.php 23867
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TABLE C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TABLE>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TABLE C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TABLE>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined offset: 4 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined offset: 5 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined offset: 6 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined offset: 7 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P>>CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P>>CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: z-index C:\wamp\www\Windykator1\MPDF57\mpdf.php 2464
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: z-index C:\wamp\www\Windykator1\MPDF57\mpdf.php 2464
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: z-index C:\wamp\www\Windykator1\MPDF57\mpdf.php 2464
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: OL C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: OL>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined offset: -1 C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1130
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:53 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: direction C:\wamp\www\Windykator1\MPDF57\mpdf.php 18502
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: direction C:\wamp\www\Windykator1\MPDF57\mpdf.php 18502
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined index: direction C:\wamp\www\Windykator1\MPDF57\mpdf.php 18502
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined property: mPDF::$hasOC C:\wamp\www\Windykator1\MPDF57\mpdf.php 27505
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined property: mPDF::$hasOC C:\wamp\www\Windykator1\MPDF57\mpdf.php 27608
ERROR - 2014-01-19 08:58:54 --> Severity: Notice  --> Undefined property: mPDF::$hasOC C:\wamp\www\Windykator1\MPDF57\mpdf.php 9158
DEBUG - 2014-01-19 08:58:54 --> Final output sent to browser
DEBUG - 2014-01-19 08:58:54 --> Total execution time: 1.7935
DEBUG - 2014-01-19 09:27:30 --> Config Class Initialized
DEBUG - 2014-01-19 09:27:30 --> Hooks Class Initialized
DEBUG - 2014-01-19 09:27:30 --> Utf8 Class Initialized
DEBUG - 2014-01-19 09:27:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 09:27:30 --> URI Class Initialized
DEBUG - 2014-01-19 09:27:30 --> Router Class Initialized
DEBUG - 2014-01-19 09:27:30 --> Output Class Initialized
DEBUG - 2014-01-19 09:27:30 --> Security Class Initialized
DEBUG - 2014-01-19 09:27:30 --> Input Class Initialized
DEBUG - 2014-01-19 09:27:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 09:27:30 --> Language Class Initialized
DEBUG - 2014-01-19 09:27:30 --> Loader Class Initialized
DEBUG - 2014-01-19 09:27:30 --> Helper loaded: url_helper
DEBUG - 2014-01-19 09:27:30 --> Helper loaded: form_helper
DEBUG - 2014-01-19 09:27:30 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 09:27:30 --> Database Driver Class Initialized
DEBUG - 2014-01-19 09:27:30 --> Session Class Initialized
DEBUG - 2014-01-19 09:27:30 --> Helper loaded: string_helper
DEBUG - 2014-01-19 09:27:30 --> Session routines successfully run
DEBUG - 2014-01-19 09:27:30 --> User Agent Class Initialized
DEBUG - 2014-01-19 09:27:30 --> Form Validation Class Initialized
DEBUG - 2014-01-19 09:27:30 --> Model Class Initialized
DEBUG - 2014-01-19 09:27:30 --> Model Class Initialized
DEBUG - 2014-01-19 09:27:30 --> Controller Class Initialized
DEBUG - 2014-01-19 09:27:30 --> Model Class Initialized
DEBUG - 2014-01-19 09:27:30 --> Model Class Initialized
DEBUG - 2014-01-19 09:27:30 --> Model Class Initialized
DEBUG - 2014-01-19 09:27:30 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 09:27:30 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 09:27:30 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 09:27:30 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 09:27:30 --> Final output sent to browser
DEBUG - 2014-01-19 09:27:30 --> Total execution time: 0.0599
DEBUG - 2014-01-19 09:27:32 --> Config Class Initialized
DEBUG - 2014-01-19 09:27:32 --> Hooks Class Initialized
DEBUG - 2014-01-19 09:27:32 --> Utf8 Class Initialized
DEBUG - 2014-01-19 09:27:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 09:27:32 --> URI Class Initialized
DEBUG - 2014-01-19 09:27:32 --> Router Class Initialized
DEBUG - 2014-01-19 09:27:32 --> Output Class Initialized
DEBUG - 2014-01-19 09:27:32 --> Security Class Initialized
DEBUG - 2014-01-19 09:27:32 --> Input Class Initialized
DEBUG - 2014-01-19 09:27:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 09:27:32 --> Language Class Initialized
DEBUG - 2014-01-19 09:27:32 --> Loader Class Initialized
DEBUG - 2014-01-19 09:27:32 --> Helper loaded: url_helper
DEBUG - 2014-01-19 09:27:32 --> Helper loaded: form_helper
DEBUG - 2014-01-19 09:27:32 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 09:27:32 --> Database Driver Class Initialized
DEBUG - 2014-01-19 09:27:32 --> Session Class Initialized
DEBUG - 2014-01-19 09:27:32 --> Helper loaded: string_helper
DEBUG - 2014-01-19 09:27:32 --> Session routines successfully run
DEBUG - 2014-01-19 09:27:32 --> User Agent Class Initialized
DEBUG - 2014-01-19 09:27:32 --> Form Validation Class Initialized
DEBUG - 2014-01-19 09:27:32 --> Model Class Initialized
DEBUG - 2014-01-19 09:27:32 --> Model Class Initialized
DEBUG - 2014-01-19 09:27:32 --> Controller Class Initialized
DEBUG - 2014-01-19 09:27:32 --> Model Class Initialized
DEBUG - 2014-01-19 09:27:32 --> Model Class Initialized
DEBUG - 2014-01-19 09:27:32 --> Model Class Initialized
DEBUG - 2014-01-19 09:27:32 --> File loaded: application/views/sprawa/edytuj.php
DEBUG - 2014-01-19 09:27:32 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 09:27:32 --> Final output sent to browser
DEBUG - 2014-01-19 09:27:32 --> Total execution time: 0.0833
DEBUG - 2014-01-19 09:28:18 --> Config Class Initialized
DEBUG - 2014-01-19 09:28:18 --> Hooks Class Initialized
DEBUG - 2014-01-19 09:28:18 --> Utf8 Class Initialized
DEBUG - 2014-01-19 09:28:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 09:28:18 --> URI Class Initialized
DEBUG - 2014-01-19 09:28:18 --> Router Class Initialized
DEBUG - 2014-01-19 09:28:18 --> Output Class Initialized
DEBUG - 2014-01-19 09:28:18 --> Security Class Initialized
DEBUG - 2014-01-19 09:28:18 --> Input Class Initialized
DEBUG - 2014-01-19 09:28:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 09:28:18 --> Language Class Initialized
DEBUG - 2014-01-19 09:28:19 --> Loader Class Initialized
DEBUG - 2014-01-19 09:28:19 --> Helper loaded: url_helper
DEBUG - 2014-01-19 09:28:19 --> Helper loaded: form_helper
DEBUG - 2014-01-19 09:28:19 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 09:28:19 --> Database Driver Class Initialized
DEBUG - 2014-01-19 09:28:19 --> Session Class Initialized
DEBUG - 2014-01-19 09:28:19 --> Helper loaded: string_helper
DEBUG - 2014-01-19 09:28:19 --> Session routines successfully run
DEBUG - 2014-01-19 09:28:19 --> User Agent Class Initialized
DEBUG - 2014-01-19 09:28:19 --> Form Validation Class Initialized
DEBUG - 2014-01-19 09:28:19 --> Model Class Initialized
DEBUG - 2014-01-19 09:28:19 --> Model Class Initialized
DEBUG - 2014-01-19 09:28:19 --> Controller Class Initialized
DEBUG - 2014-01-19 09:28:19 --> Model Class Initialized
DEBUG - 2014-01-19 09:28:19 --> Model Class Initialized
DEBUG - 2014-01-19 09:28:19 --> Model Class Initialized
DEBUG - 2014-01-19 09:28:19 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 09:28:19 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 09:28:19 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 09:28:19 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 09:28:19 --> Final output sent to browser
DEBUG - 2014-01-19 09:28:19 --> Total execution time: 0.0606
DEBUG - 2014-01-19 09:28:22 --> Config Class Initialized
DEBUG - 2014-01-19 09:28:22 --> Hooks Class Initialized
DEBUG - 2014-01-19 09:28:22 --> Utf8 Class Initialized
DEBUG - 2014-01-19 09:28:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 09:28:22 --> URI Class Initialized
DEBUG - 2014-01-19 09:28:22 --> Router Class Initialized
DEBUG - 2014-01-19 09:28:22 --> Output Class Initialized
DEBUG - 2014-01-19 09:28:22 --> Security Class Initialized
DEBUG - 2014-01-19 09:28:22 --> Input Class Initialized
DEBUG - 2014-01-19 09:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 09:28:22 --> Language Class Initialized
DEBUG - 2014-01-19 09:28:22 --> Loader Class Initialized
DEBUG - 2014-01-19 09:28:22 --> Helper loaded: url_helper
DEBUG - 2014-01-19 09:28:22 --> Helper loaded: form_helper
DEBUG - 2014-01-19 09:28:22 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 09:28:22 --> Database Driver Class Initialized
DEBUG - 2014-01-19 09:28:22 --> Session Class Initialized
DEBUG - 2014-01-19 09:28:22 --> Helper loaded: string_helper
DEBUG - 2014-01-19 09:28:22 --> Session routines successfully run
DEBUG - 2014-01-19 09:28:22 --> User Agent Class Initialized
DEBUG - 2014-01-19 09:28:22 --> Form Validation Class Initialized
DEBUG - 2014-01-19 09:28:22 --> Model Class Initialized
DEBUG - 2014-01-19 09:28:22 --> Model Class Initialized
DEBUG - 2014-01-19 09:28:22 --> Controller Class Initialized
DEBUG - 2014-01-19 09:28:22 --> Model Class Initialized
DEBUG - 2014-01-19 09:28:22 --> Model Class Initialized
DEBUG - 2014-01-19 09:28:22 --> Model Class Initialized
DEBUG - 2014-01-19 09:28:22 --> File loaded: application/views/sprawa/edytuj.php
DEBUG - 2014-01-19 09:28:22 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 09:28:22 --> Final output sent to browser
DEBUG - 2014-01-19 09:28:22 --> Total execution time: 0.0838
DEBUG - 2014-01-19 09:29:00 --> Config Class Initialized
DEBUG - 2014-01-19 09:29:00 --> Hooks Class Initialized
DEBUG - 2014-01-19 09:29:00 --> Utf8 Class Initialized
DEBUG - 2014-01-19 09:29:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 09:29:00 --> URI Class Initialized
DEBUG - 2014-01-19 09:29:00 --> Router Class Initialized
DEBUG - 2014-01-19 09:29:00 --> Output Class Initialized
DEBUG - 2014-01-19 09:29:00 --> Security Class Initialized
DEBUG - 2014-01-19 09:29:00 --> Input Class Initialized
DEBUG - 2014-01-19 09:29:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 09:29:00 --> Language Class Initialized
DEBUG - 2014-01-19 09:29:00 --> Loader Class Initialized
DEBUG - 2014-01-19 09:29:00 --> Helper loaded: url_helper
DEBUG - 2014-01-19 09:29:00 --> Helper loaded: form_helper
DEBUG - 2014-01-19 09:29:00 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 09:29:00 --> Database Driver Class Initialized
DEBUG - 2014-01-19 09:29:00 --> Session Class Initialized
DEBUG - 2014-01-19 09:29:00 --> Helper loaded: string_helper
DEBUG - 2014-01-19 09:29:00 --> Session routines successfully run
DEBUG - 2014-01-19 09:29:00 --> User Agent Class Initialized
DEBUG - 2014-01-19 09:29:00 --> Form Validation Class Initialized
DEBUG - 2014-01-19 09:29:00 --> Model Class Initialized
DEBUG - 2014-01-19 09:29:00 --> Model Class Initialized
DEBUG - 2014-01-19 09:29:00 --> Controller Class Initialized
DEBUG - 2014-01-19 09:29:00 --> Model Class Initialized
DEBUG - 2014-01-19 09:29:00 --> Model Class Initialized
DEBUG - 2014-01-19 09:29:00 --> Model Class Initialized
DEBUG - 2014-01-19 09:29:00 --> Language file loaded: language/polish/form_validation_lang.php
ERROR - 2014-01-19 09:29:00 --> Severity: Notice  --> Undefined index: organ_egzekucyjny C:\wamp\www\Windykator1\application\views\sprawa\edytuj.php 162
ERROR - 2014-01-19 09:29:00 --> Severity: Notice  --> Undefined index: data_tytulu C:\wamp\www\Windykator1\application\views\sprawa\edytuj.php 177
ERROR - 2014-01-19 09:29:00 --> Severity: Notice  --> Undefined index: tytul_wydanyPrzez C:\wamp\www\Windykator1\application\views\sprawa\edytuj.php 184
DEBUG - 2014-01-19 09:29:00 --> File loaded: application/views/sprawa/edytuj.php
DEBUG - 2014-01-19 09:29:00 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 09:29:00 --> Final output sent to browser
DEBUG - 2014-01-19 09:29:00 --> Total execution time: 0.0936
DEBUG - 2014-01-19 10:46:50 --> Config Class Initialized
DEBUG - 2014-01-19 10:46:50 --> Hooks Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Utf8 Class Initialized
DEBUG - 2014-01-19 10:46:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 10:46:51 --> URI Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Router Class Initialized
DEBUG - 2014-01-19 10:46:51 --> No URI present. Default controller set.
DEBUG - 2014-01-19 10:46:51 --> Output Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Security Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Input Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 10:46:51 --> Language Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Loader Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Helper loaded: url_helper
DEBUG - 2014-01-19 10:46:51 --> Helper loaded: form_helper
DEBUG - 2014-01-19 10:46:51 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 10:46:51 --> Database Driver Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Session Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Helper loaded: string_helper
DEBUG - 2014-01-19 10:46:51 --> Session routines successfully run
DEBUG - 2014-01-19 10:46:51 --> User Agent Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Form Validation Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Model Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Model Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Controller Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Config Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Hooks Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Utf8 Class Initialized
DEBUG - 2014-01-19 10:46:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 10:46:51 --> URI Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Router Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Output Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Security Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Input Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 10:46:51 --> Language Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Loader Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Helper loaded: url_helper
DEBUG - 2014-01-19 10:46:51 --> Helper loaded: form_helper
DEBUG - 2014-01-19 10:46:51 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 10:46:51 --> Database Driver Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Session Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Helper loaded: string_helper
DEBUG - 2014-01-19 10:46:51 --> Session routines successfully run
DEBUG - 2014-01-19 10:46:51 --> User Agent Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Form Validation Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Model Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Model Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Controller Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Model Class Initialized
DEBUG - 2014-01-19 10:46:51 --> Model Class Initialized
DEBUG - 2014-01-19 10:46:51 --> File loaded: application/views/wniosek/lista.php
DEBUG - 2014-01-19 10:46:51 --> File loaded: application/views/user/aktualnosci.php
DEBUG - 2014-01-19 10:46:51 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 10:46:51 --> Final output sent to browser
DEBUG - 2014-01-19 10:46:51 --> Total execution time: 0.0683
DEBUG - 2014-01-19 10:46:57 --> Config Class Initialized
DEBUG - 2014-01-19 10:46:57 --> Hooks Class Initialized
DEBUG - 2014-01-19 10:46:57 --> Utf8 Class Initialized
DEBUG - 2014-01-19 10:46:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 10:46:57 --> URI Class Initialized
DEBUG - 2014-01-19 10:46:57 --> Router Class Initialized
DEBUG - 2014-01-19 10:46:57 --> Output Class Initialized
DEBUG - 2014-01-19 10:46:57 --> Security Class Initialized
DEBUG - 2014-01-19 10:46:57 --> Input Class Initialized
DEBUG - 2014-01-19 10:46:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 10:46:57 --> Language Class Initialized
DEBUG - 2014-01-19 10:46:57 --> Loader Class Initialized
DEBUG - 2014-01-19 10:46:57 --> Helper loaded: url_helper
DEBUG - 2014-01-19 10:46:57 --> Helper loaded: form_helper
DEBUG - 2014-01-19 10:46:57 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 10:46:57 --> Database Driver Class Initialized
DEBUG - 2014-01-19 10:46:57 --> Session Class Initialized
DEBUG - 2014-01-19 10:46:57 --> Helper loaded: string_helper
DEBUG - 2014-01-19 10:46:57 --> Session routines successfully run
DEBUG - 2014-01-19 10:46:57 --> User Agent Class Initialized
DEBUG - 2014-01-19 10:46:57 --> Form Validation Class Initialized
DEBUG - 2014-01-19 10:46:57 --> Model Class Initialized
DEBUG - 2014-01-19 10:46:57 --> Model Class Initialized
DEBUG - 2014-01-19 10:46:57 --> Controller Class Initialized
DEBUG - 2014-01-19 10:46:57 --> Model Class Initialized
DEBUG - 2014-01-19 10:46:57 --> Model Class Initialized
DEBUG - 2014-01-19 10:46:57 --> Model Class Initialized
DEBUG - 2014-01-19 10:46:57 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 10:46:57 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 10:46:57 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 10:46:57 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 10:46:57 --> Final output sent to browser
DEBUG - 2014-01-19 10:46:57 --> Total execution time: 0.0782
DEBUG - 2014-01-19 10:46:59 --> Config Class Initialized
DEBUG - 2014-01-19 10:46:59 --> Hooks Class Initialized
DEBUG - 2014-01-19 10:46:59 --> Utf8 Class Initialized
DEBUG - 2014-01-19 10:46:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 10:46:59 --> URI Class Initialized
DEBUG - 2014-01-19 10:46:59 --> Router Class Initialized
DEBUG - 2014-01-19 10:46:59 --> Output Class Initialized
DEBUG - 2014-01-19 10:46:59 --> Security Class Initialized
DEBUG - 2014-01-19 10:46:59 --> Input Class Initialized
DEBUG - 2014-01-19 10:46:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 10:46:59 --> Language Class Initialized
DEBUG - 2014-01-19 10:46:59 --> Loader Class Initialized
DEBUG - 2014-01-19 10:46:59 --> Helper loaded: url_helper
DEBUG - 2014-01-19 10:46:59 --> Helper loaded: form_helper
DEBUG - 2014-01-19 10:46:59 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 10:46:59 --> Database Driver Class Initialized
DEBUG - 2014-01-19 10:46:59 --> Session Class Initialized
DEBUG - 2014-01-19 10:46:59 --> Helper loaded: string_helper
DEBUG - 2014-01-19 10:46:59 --> Session routines successfully run
DEBUG - 2014-01-19 10:46:59 --> User Agent Class Initialized
DEBUG - 2014-01-19 10:46:59 --> Form Validation Class Initialized
DEBUG - 2014-01-19 10:46:59 --> Model Class Initialized
DEBUG - 2014-01-19 10:46:59 --> Model Class Initialized
DEBUG - 2014-01-19 10:46:59 --> Controller Class Initialized
DEBUG - 2014-01-19 10:46:59 --> Model Class Initialized
DEBUG - 2014-01-19 10:46:59 --> Model Class Initialized
DEBUG - 2014-01-19 10:46:59 --> Model Class Initialized
DEBUG - 2014-01-19 10:46:59 --> File loaded: application/views/sprawa/edytuj.php
DEBUG - 2014-01-19 10:46:59 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 10:46:59 --> Final output sent to browser
DEBUG - 2014-01-19 10:46:59 --> Total execution time: 0.0752
DEBUG - 2014-01-19 10:47:05 --> Config Class Initialized
DEBUG - 2014-01-19 10:47:05 --> Hooks Class Initialized
DEBUG - 2014-01-19 10:47:05 --> Utf8 Class Initialized
DEBUG - 2014-01-19 10:47:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 10:47:05 --> URI Class Initialized
DEBUG - 2014-01-19 10:47:05 --> Router Class Initialized
DEBUG - 2014-01-19 10:47:05 --> Output Class Initialized
DEBUG - 2014-01-19 10:47:05 --> Security Class Initialized
DEBUG - 2014-01-19 10:47:05 --> Input Class Initialized
DEBUG - 2014-01-19 10:47:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 10:47:05 --> Language Class Initialized
DEBUG - 2014-01-19 10:47:05 --> Loader Class Initialized
DEBUG - 2014-01-19 10:47:05 --> Helper loaded: url_helper
DEBUG - 2014-01-19 10:47:05 --> Helper loaded: form_helper
DEBUG - 2014-01-19 10:47:05 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 10:47:05 --> Database Driver Class Initialized
DEBUG - 2014-01-19 10:47:05 --> Session Class Initialized
DEBUG - 2014-01-19 10:47:05 --> Helper loaded: string_helper
DEBUG - 2014-01-19 10:47:05 --> Session routines successfully run
DEBUG - 2014-01-19 10:47:05 --> User Agent Class Initialized
DEBUG - 2014-01-19 10:47:05 --> Form Validation Class Initialized
DEBUG - 2014-01-19 10:47:05 --> Model Class Initialized
DEBUG - 2014-01-19 10:47:05 --> Model Class Initialized
DEBUG - 2014-01-19 10:47:05 --> Controller Class Initialized
DEBUG - 2014-01-19 10:47:05 --> Model Class Initialized
DEBUG - 2014-01-19 10:47:05 --> Model Class Initialized
DEBUG - 2014-01-19 10:47:05 --> Model Class Initialized
DEBUG - 2014-01-19 10:47:05 --> Language file loaded: language/polish/form_validation_lang.php
ERROR - 2014-01-19 10:47:05 --> Severity: Notice  --> Undefined index: organ_egzekucyjny C:\wamp\www\Windykator1\application\views\sprawa\edytuj.php 162
ERROR - 2014-01-19 10:47:05 --> Severity: Notice  --> Undefined index: data_tytulu C:\wamp\www\Windykator1\application\views\sprawa\edytuj.php 177
ERROR - 2014-01-19 10:47:05 --> Severity: Notice  --> Undefined index: tytul_wydanyPrzez C:\wamp\www\Windykator1\application\views\sprawa\edytuj.php 184
DEBUG - 2014-01-19 10:47:05 --> File loaded: application/views/sprawa/edytuj.php
DEBUG - 2014-01-19 10:47:05 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 10:47:05 --> Final output sent to browser
DEBUG - 2014-01-19 10:47:05 --> Total execution time: 0.0929
DEBUG - 2014-01-19 10:47:43 --> Config Class Initialized
DEBUG - 2014-01-19 10:47:43 --> Hooks Class Initialized
DEBUG - 2014-01-19 10:47:43 --> Utf8 Class Initialized
DEBUG - 2014-01-19 10:47:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 10:47:43 --> URI Class Initialized
DEBUG - 2014-01-19 10:47:43 --> Router Class Initialized
DEBUG - 2014-01-19 10:47:43 --> Output Class Initialized
DEBUG - 2014-01-19 10:47:43 --> Security Class Initialized
DEBUG - 2014-01-19 10:47:43 --> Input Class Initialized
DEBUG - 2014-01-19 10:47:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 10:47:43 --> Language Class Initialized
DEBUG - 2014-01-19 10:47:43 --> Loader Class Initialized
DEBUG - 2014-01-19 10:47:43 --> Helper loaded: url_helper
DEBUG - 2014-01-19 10:47:43 --> Helper loaded: form_helper
DEBUG - 2014-01-19 10:47:43 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 10:47:43 --> Database Driver Class Initialized
DEBUG - 2014-01-19 10:47:43 --> Session Class Initialized
DEBUG - 2014-01-19 10:47:43 --> Helper loaded: string_helper
DEBUG - 2014-01-19 10:47:43 --> Session routines successfully run
DEBUG - 2014-01-19 10:47:43 --> User Agent Class Initialized
DEBUG - 2014-01-19 10:47:43 --> Form Validation Class Initialized
DEBUG - 2014-01-19 10:47:43 --> Model Class Initialized
DEBUG - 2014-01-19 10:47:43 --> Model Class Initialized
DEBUG - 2014-01-19 10:47:43 --> Controller Class Initialized
DEBUG - 2014-01-19 10:47:43 --> Config Class Initialized
DEBUG - 2014-01-19 10:47:43 --> Hooks Class Initialized
DEBUG - 2014-01-19 10:47:43 --> Utf8 Class Initialized
DEBUG - 2014-01-19 10:47:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 10:47:43 --> URI Class Initialized
DEBUG - 2014-01-19 10:47:43 --> Router Class Initialized
DEBUG - 2014-01-19 10:47:43 --> No URI present. Default controller set.
DEBUG - 2014-01-19 10:47:43 --> Output Class Initialized
DEBUG - 2014-01-19 10:47:43 --> Security Class Initialized
DEBUG - 2014-01-19 10:47:43 --> Input Class Initialized
DEBUG - 2014-01-19 10:47:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 10:47:43 --> Language Class Initialized
DEBUG - 2014-01-19 10:47:43 --> Loader Class Initialized
DEBUG - 2014-01-19 10:47:43 --> Helper loaded: url_helper
DEBUG - 2014-01-19 10:47:43 --> Helper loaded: form_helper
DEBUG - 2014-01-19 10:47:43 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 10:47:43 --> Database Driver Class Initialized
DEBUG - 2014-01-19 10:47:43 --> Session Class Initialized
DEBUG - 2014-01-19 10:47:43 --> Helper loaded: string_helper
DEBUG - 2014-01-19 10:47:43 --> Session routines successfully run
DEBUG - 2014-01-19 10:47:43 --> User Agent Class Initialized
DEBUG - 2014-01-19 10:47:43 --> Form Validation Class Initialized
DEBUG - 2014-01-19 10:47:43 --> Model Class Initialized
DEBUG - 2014-01-19 10:47:44 --> Model Class Initialized
DEBUG - 2014-01-19 10:47:44 --> Controller Class Initialized
DEBUG - 2014-01-19 10:47:44 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-19 10:47:44 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 10:47:44 --> Final output sent to browser
DEBUG - 2014-01-19 10:47:44 --> Total execution time: 0.0515
DEBUG - 2014-01-19 15:55:06 --> Config Class Initialized
DEBUG - 2014-01-19 15:55:06 --> Hooks Class Initialized
DEBUG - 2014-01-19 15:55:06 --> Utf8 Class Initialized
DEBUG - 2014-01-19 15:55:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 15:55:06 --> URI Class Initialized
DEBUG - 2014-01-19 15:55:06 --> Router Class Initialized
DEBUG - 2014-01-19 15:55:06 --> No URI present. Default controller set.
DEBUG - 2014-01-19 15:55:06 --> Output Class Initialized
DEBUG - 2014-01-19 15:55:06 --> Security Class Initialized
DEBUG - 2014-01-19 15:55:06 --> Input Class Initialized
DEBUG - 2014-01-19 15:55:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 15:55:06 --> Language Class Initialized
DEBUG - 2014-01-19 15:55:06 --> Loader Class Initialized
DEBUG - 2014-01-19 15:55:06 --> Helper loaded: url_helper
DEBUG - 2014-01-19 15:55:06 --> Helper loaded: form_helper
DEBUG - 2014-01-19 15:55:06 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 15:55:06 --> Database Driver Class Initialized
DEBUG - 2014-01-19 15:55:06 --> Session Class Initialized
DEBUG - 2014-01-19 15:55:06 --> Helper loaded: string_helper
DEBUG - 2014-01-19 15:55:06 --> A session cookie was not found.
DEBUG - 2014-01-19 15:55:06 --> Session routines successfully run
DEBUG - 2014-01-19 15:55:06 --> User Agent Class Initialized
DEBUG - 2014-01-19 15:55:06 --> Form Validation Class Initialized
DEBUG - 2014-01-19 15:55:06 --> Model Class Initialized
DEBUG - 2014-01-19 15:55:06 --> Model Class Initialized
DEBUG - 2014-01-19 15:55:06 --> Controller Class Initialized
DEBUG - 2014-01-19 15:55:06 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-19 15:55:06 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 15:55:06 --> Final output sent to browser
DEBUG - 2014-01-19 15:55:06 --> Total execution time: 0.0878
DEBUG - 2014-01-19 15:55:10 --> Config Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Hooks Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Utf8 Class Initialized
DEBUG - 2014-01-19 15:55:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 15:55:10 --> URI Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Router Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Output Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Security Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Input Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 15:55:10 --> Language Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Loader Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Helper loaded: url_helper
DEBUG - 2014-01-19 15:55:10 --> Helper loaded: form_helper
DEBUG - 2014-01-19 15:55:10 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 15:55:10 --> Database Driver Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Session Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Helper loaded: string_helper
DEBUG - 2014-01-19 15:55:10 --> Session routines successfully run
DEBUG - 2014-01-19 15:55:10 --> User Agent Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Form Validation Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Model Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Model Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Controller Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-19 15:55:10 --> Config Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Hooks Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Utf8 Class Initialized
DEBUG - 2014-01-19 15:55:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 15:55:10 --> URI Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Router Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Output Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Security Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Input Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 15:55:10 --> Language Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Loader Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Helper loaded: url_helper
DEBUG - 2014-01-19 15:55:10 --> Helper loaded: form_helper
DEBUG - 2014-01-19 15:55:10 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 15:55:10 --> Database Driver Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Session Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Helper loaded: string_helper
DEBUG - 2014-01-19 15:55:10 --> Session routines successfully run
DEBUG - 2014-01-19 15:55:10 --> User Agent Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Form Validation Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Model Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Model Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Controller Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Model Class Initialized
DEBUG - 2014-01-19 15:55:10 --> Model Class Initialized
DEBUG - 2014-01-19 15:55:10 --> File loaded: application/views/wniosek/lista.php
DEBUG - 2014-01-19 15:55:10 --> File loaded: application/views/user/aktualnosci.php
DEBUG - 2014-01-19 15:55:10 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 15:55:10 --> Final output sent to browser
DEBUG - 2014-01-19 15:55:10 --> Total execution time: 0.1968
DEBUG - 2014-01-19 15:55:12 --> Config Class Initialized
DEBUG - 2014-01-19 15:55:12 --> Hooks Class Initialized
DEBUG - 2014-01-19 15:55:12 --> Utf8 Class Initialized
DEBUG - 2014-01-19 15:55:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 15:55:12 --> URI Class Initialized
DEBUG - 2014-01-19 15:55:12 --> Router Class Initialized
DEBUG - 2014-01-19 15:55:12 --> Output Class Initialized
DEBUG - 2014-01-19 15:55:12 --> Security Class Initialized
DEBUG - 2014-01-19 15:55:12 --> Input Class Initialized
DEBUG - 2014-01-19 15:55:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 15:55:12 --> Language Class Initialized
DEBUG - 2014-01-19 15:55:12 --> Loader Class Initialized
DEBUG - 2014-01-19 15:55:12 --> Helper loaded: url_helper
DEBUG - 2014-01-19 15:55:12 --> Helper loaded: form_helper
DEBUG - 2014-01-19 15:55:12 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 15:55:12 --> Database Driver Class Initialized
DEBUG - 2014-01-19 15:55:12 --> Session Class Initialized
DEBUG - 2014-01-19 15:55:12 --> Helper loaded: string_helper
DEBUG - 2014-01-19 15:55:12 --> Session routines successfully run
DEBUG - 2014-01-19 15:55:12 --> User Agent Class Initialized
DEBUG - 2014-01-19 15:55:12 --> Form Validation Class Initialized
DEBUG - 2014-01-19 15:55:12 --> Model Class Initialized
DEBUG - 2014-01-19 15:55:12 --> Model Class Initialized
DEBUG - 2014-01-19 15:55:12 --> Controller Class Initialized
DEBUG - 2014-01-19 15:55:12 --> Model Class Initialized
DEBUG - 2014-01-19 15:55:12 --> Model Class Initialized
DEBUG - 2014-01-19 15:55:12 --> Model Class Initialized
DEBUG - 2014-01-19 15:55:12 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 15:55:12 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 15:55:12 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 15:55:12 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 15:55:12 --> Final output sent to browser
DEBUG - 2014-01-19 15:55:12 --> Total execution time: 0.0795
DEBUG - 2014-01-19 15:55:14 --> Config Class Initialized
DEBUG - 2014-01-19 15:55:14 --> Hooks Class Initialized
DEBUG - 2014-01-19 15:55:14 --> Utf8 Class Initialized
DEBUG - 2014-01-19 15:55:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 15:55:14 --> URI Class Initialized
DEBUG - 2014-01-19 15:55:14 --> Router Class Initialized
DEBUG - 2014-01-19 15:55:14 --> Output Class Initialized
DEBUG - 2014-01-19 15:55:14 --> Security Class Initialized
DEBUG - 2014-01-19 15:55:14 --> Input Class Initialized
DEBUG - 2014-01-19 15:55:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 15:55:14 --> Language Class Initialized
DEBUG - 2014-01-19 15:55:14 --> Loader Class Initialized
DEBUG - 2014-01-19 15:55:14 --> Helper loaded: url_helper
DEBUG - 2014-01-19 15:55:14 --> Helper loaded: form_helper
DEBUG - 2014-01-19 15:55:14 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 15:55:14 --> Database Driver Class Initialized
DEBUG - 2014-01-19 15:55:14 --> Session Class Initialized
DEBUG - 2014-01-19 15:55:14 --> Helper loaded: string_helper
DEBUG - 2014-01-19 15:55:14 --> Session routines successfully run
DEBUG - 2014-01-19 15:55:14 --> User Agent Class Initialized
DEBUG - 2014-01-19 15:55:14 --> Form Validation Class Initialized
DEBUG - 2014-01-19 15:55:14 --> Model Class Initialized
DEBUG - 2014-01-19 15:55:14 --> Model Class Initialized
DEBUG - 2014-01-19 15:55:14 --> Controller Class Initialized
DEBUG - 2014-01-19 15:55:14 --> Model Class Initialized
DEBUG - 2014-01-19 15:55:14 --> Model Class Initialized
DEBUG - 2014-01-19 15:55:14 --> Model Class Initialized
DEBUG - 2014-01-19 15:55:14 --> File loaded: application/views/sprawa/edytuj.php
DEBUG - 2014-01-19 15:55:14 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 15:55:14 --> Final output sent to browser
DEBUG - 2014-01-19 15:55:14 --> Total execution time: 0.1133
DEBUG - 2014-01-19 15:55:22 --> Config Class Initialized
DEBUG - 2014-01-19 15:55:22 --> Hooks Class Initialized
DEBUG - 2014-01-19 15:55:22 --> Utf8 Class Initialized
DEBUG - 2014-01-19 15:55:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 15:55:22 --> URI Class Initialized
DEBUG - 2014-01-19 15:55:22 --> Router Class Initialized
DEBUG - 2014-01-19 15:55:22 --> Output Class Initialized
DEBUG - 2014-01-19 15:55:22 --> Security Class Initialized
DEBUG - 2014-01-19 15:55:22 --> Input Class Initialized
DEBUG - 2014-01-19 15:55:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 15:55:22 --> Language Class Initialized
DEBUG - 2014-01-19 15:55:22 --> Loader Class Initialized
DEBUG - 2014-01-19 15:55:22 --> Helper loaded: url_helper
DEBUG - 2014-01-19 15:55:22 --> Helper loaded: form_helper
DEBUG - 2014-01-19 15:55:22 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 15:55:22 --> Database Driver Class Initialized
DEBUG - 2014-01-19 15:55:22 --> Session Class Initialized
DEBUG - 2014-01-19 15:55:22 --> Helper loaded: string_helper
DEBUG - 2014-01-19 15:55:22 --> Session routines successfully run
DEBUG - 2014-01-19 15:55:22 --> User Agent Class Initialized
DEBUG - 2014-01-19 15:55:22 --> Form Validation Class Initialized
DEBUG - 2014-01-19 15:55:22 --> Model Class Initialized
DEBUG - 2014-01-19 15:55:22 --> Model Class Initialized
DEBUG - 2014-01-19 15:55:22 --> Controller Class Initialized
DEBUG - 2014-01-19 15:55:22 --> Model Class Initialized
DEBUG - 2014-01-19 15:55:22 --> Model Class Initialized
DEBUG - 2014-01-19 15:55:22 --> Model Class Initialized
DEBUG - 2014-01-19 15:55:22 --> Language file loaded: language/polish/form_validation_lang.php
ERROR - 2014-01-19 15:55:22 --> Severity: Notice  --> Undefined index: organ_egzekucyjny C:\wamp\www\Windykator1\application\views\sprawa\edytuj.php 162
ERROR - 2014-01-19 15:55:22 --> Severity: Notice  --> Undefined index: data_tytulu C:\wamp\www\Windykator1\application\views\sprawa\edytuj.php 177
ERROR - 2014-01-19 15:55:22 --> Severity: Notice  --> Undefined index: tytul_wydanyPrzez C:\wamp\www\Windykator1\application\views\sprawa\edytuj.php 184
DEBUG - 2014-01-19 15:55:22 --> File loaded: application/views/sprawa/edytuj.php
DEBUG - 2014-01-19 15:55:22 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 15:55:22 --> Final output sent to browser
DEBUG - 2014-01-19 15:55:22 --> Total execution time: 0.0858
DEBUG - 2014-01-19 16:02:52 --> Config Class Initialized
DEBUG - 2014-01-19 16:02:52 --> Hooks Class Initialized
DEBUG - 2014-01-19 16:02:52 --> Utf8 Class Initialized
DEBUG - 2014-01-19 16:02:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 16:02:52 --> URI Class Initialized
DEBUG - 2014-01-19 16:02:52 --> Router Class Initialized
DEBUG - 2014-01-19 16:02:52 --> Output Class Initialized
DEBUG - 2014-01-19 16:02:52 --> Security Class Initialized
DEBUG - 2014-01-19 16:02:52 --> Input Class Initialized
DEBUG - 2014-01-19 16:02:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 16:02:52 --> Language Class Initialized
DEBUG - 2014-01-19 16:02:52 --> Loader Class Initialized
DEBUG - 2014-01-19 16:02:52 --> Helper loaded: url_helper
DEBUG - 2014-01-19 16:02:52 --> Helper loaded: form_helper
DEBUG - 2014-01-19 16:02:52 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 16:02:52 --> Database Driver Class Initialized
DEBUG - 2014-01-19 16:02:52 --> Session Class Initialized
DEBUG - 2014-01-19 16:02:52 --> Helper loaded: string_helper
DEBUG - 2014-01-19 16:02:52 --> Session routines successfully run
DEBUG - 2014-01-19 16:02:52 --> User Agent Class Initialized
DEBUG - 2014-01-19 16:02:53 --> Form Validation Class Initialized
DEBUG - 2014-01-19 16:02:53 --> Model Class Initialized
DEBUG - 2014-01-19 16:02:53 --> Model Class Initialized
DEBUG - 2014-01-19 16:02:53 --> Controller Class Initialized
DEBUG - 2014-01-19 16:02:53 --> Model Class Initialized
DEBUG - 2014-01-19 16:02:53 --> Model Class Initialized
DEBUG - 2014-01-19 16:02:53 --> Model Class Initialized
DEBUG - 2014-01-19 16:02:53 --> Language file loaded: language/polish/form_validation_lang.php
ERROR - 2014-01-19 16:02:53 --> Severity: Notice  --> Undefined index: organ_egzekucyjny C:\wamp\www\Windykator1\application\views\sprawa\edytuj.php 162
ERROR - 2014-01-19 16:02:53 --> Severity: Notice  --> Undefined index: data_tytulu C:\wamp\www\Windykator1\application\views\sprawa\edytuj.php 176
ERROR - 2014-01-19 16:02:53 --> Severity: Notice  --> Undefined index: tytul_wydanyPrzez C:\wamp\www\Windykator1\application\views\sprawa\edytuj.php 182
DEBUG - 2014-01-19 16:02:53 --> File loaded: application/views/sprawa/edytuj.php
DEBUG - 2014-01-19 16:02:53 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 16:02:53 --> Final output sent to browser
DEBUG - 2014-01-19 16:02:53 --> Total execution time: 0.0769
DEBUG - 2014-01-19 16:03:07 --> Config Class Initialized
DEBUG - 2014-01-19 16:03:07 --> Hooks Class Initialized
DEBUG - 2014-01-19 16:03:07 --> Utf8 Class Initialized
DEBUG - 2014-01-19 16:03:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 16:03:07 --> URI Class Initialized
DEBUG - 2014-01-19 16:03:07 --> Router Class Initialized
DEBUG - 2014-01-19 16:03:07 --> Output Class Initialized
DEBUG - 2014-01-19 16:03:07 --> Security Class Initialized
DEBUG - 2014-01-19 16:03:07 --> Input Class Initialized
DEBUG - 2014-01-19 16:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 16:03:07 --> Language Class Initialized
DEBUG - 2014-01-19 16:03:07 --> Loader Class Initialized
DEBUG - 2014-01-19 16:03:07 --> Helper loaded: url_helper
DEBUG - 2014-01-19 16:03:07 --> Helper loaded: form_helper
DEBUG - 2014-01-19 16:03:07 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 16:03:07 --> Database Driver Class Initialized
DEBUG - 2014-01-19 16:03:07 --> Session Class Initialized
DEBUG - 2014-01-19 16:03:07 --> Helper loaded: string_helper
DEBUG - 2014-01-19 16:03:07 --> Session routines successfully run
DEBUG - 2014-01-19 16:03:07 --> User Agent Class Initialized
DEBUG - 2014-01-19 16:03:07 --> Form Validation Class Initialized
DEBUG - 2014-01-19 16:03:07 --> Model Class Initialized
DEBUG - 2014-01-19 16:03:07 --> Model Class Initialized
DEBUG - 2014-01-19 16:03:07 --> Controller Class Initialized
DEBUG - 2014-01-19 16:03:07 --> Model Class Initialized
DEBUG - 2014-01-19 16:03:07 --> Model Class Initialized
DEBUG - 2014-01-19 16:03:07 --> Model Class Initialized
DEBUG - 2014-01-19 16:03:07 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 16:03:07 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 16:03:07 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 16:03:07 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 16:03:07 --> Final output sent to browser
DEBUG - 2014-01-19 16:03:07 --> Total execution time: 0.0746
DEBUG - 2014-01-19 16:03:11 --> Config Class Initialized
DEBUG - 2014-01-19 16:03:11 --> Hooks Class Initialized
DEBUG - 2014-01-19 16:03:11 --> Utf8 Class Initialized
DEBUG - 2014-01-19 16:03:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 16:03:11 --> URI Class Initialized
DEBUG - 2014-01-19 16:03:11 --> Router Class Initialized
DEBUG - 2014-01-19 16:03:11 --> Output Class Initialized
DEBUG - 2014-01-19 16:03:11 --> Security Class Initialized
DEBUG - 2014-01-19 16:03:11 --> Input Class Initialized
DEBUG - 2014-01-19 16:03:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 16:03:11 --> Language Class Initialized
DEBUG - 2014-01-19 16:03:11 --> Loader Class Initialized
DEBUG - 2014-01-19 16:03:11 --> Helper loaded: url_helper
DEBUG - 2014-01-19 16:03:11 --> Helper loaded: form_helper
DEBUG - 2014-01-19 16:03:11 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 16:03:11 --> Database Driver Class Initialized
DEBUG - 2014-01-19 16:03:11 --> Session Class Initialized
DEBUG - 2014-01-19 16:03:11 --> Helper loaded: string_helper
DEBUG - 2014-01-19 16:03:11 --> Session routines successfully run
DEBUG - 2014-01-19 16:03:11 --> User Agent Class Initialized
DEBUG - 2014-01-19 16:03:11 --> Form Validation Class Initialized
DEBUG - 2014-01-19 16:03:11 --> Model Class Initialized
DEBUG - 2014-01-19 16:03:11 --> Model Class Initialized
DEBUG - 2014-01-19 16:03:11 --> Controller Class Initialized
DEBUG - 2014-01-19 16:03:11 --> Model Class Initialized
DEBUG - 2014-01-19 16:03:11 --> Model Class Initialized
DEBUG - 2014-01-19 16:03:11 --> Model Class Initialized
DEBUG - 2014-01-19 16:03:11 --> File loaded: application/views/sprawa/edytuj.php
DEBUG - 2014-01-19 16:03:11 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 16:03:11 --> Final output sent to browser
DEBUG - 2014-01-19 16:03:11 --> Total execution time: 0.0775
DEBUG - 2014-01-19 16:03:15 --> Config Class Initialized
DEBUG - 2014-01-19 16:03:15 --> Hooks Class Initialized
DEBUG - 2014-01-19 16:03:15 --> Utf8 Class Initialized
DEBUG - 2014-01-19 16:03:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 16:03:15 --> URI Class Initialized
DEBUG - 2014-01-19 16:03:15 --> Router Class Initialized
DEBUG - 2014-01-19 16:03:15 --> Output Class Initialized
DEBUG - 2014-01-19 16:03:15 --> Security Class Initialized
DEBUG - 2014-01-19 16:03:15 --> Input Class Initialized
DEBUG - 2014-01-19 16:03:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 16:03:15 --> Language Class Initialized
DEBUG - 2014-01-19 16:03:15 --> Loader Class Initialized
DEBUG - 2014-01-19 16:03:15 --> Helper loaded: url_helper
DEBUG - 2014-01-19 16:03:15 --> Helper loaded: form_helper
DEBUG - 2014-01-19 16:03:15 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 16:03:15 --> Database Driver Class Initialized
DEBUG - 2014-01-19 16:03:15 --> Session Class Initialized
DEBUG - 2014-01-19 16:03:15 --> Helper loaded: string_helper
DEBUG - 2014-01-19 16:03:15 --> Session routines successfully run
DEBUG - 2014-01-19 16:03:15 --> User Agent Class Initialized
DEBUG - 2014-01-19 16:03:15 --> Form Validation Class Initialized
DEBUG - 2014-01-19 16:03:15 --> Model Class Initialized
DEBUG - 2014-01-19 16:03:15 --> Model Class Initialized
DEBUG - 2014-01-19 16:03:15 --> Controller Class Initialized
DEBUG - 2014-01-19 16:03:15 --> Model Class Initialized
DEBUG - 2014-01-19 16:03:15 --> Model Class Initialized
DEBUG - 2014-01-19 16:03:15 --> Model Class Initialized
DEBUG - 2014-01-19 16:03:15 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-19 16:03:15 --> File loaded: application/views/sprawa/edytuj.php
DEBUG - 2014-01-19 16:03:15 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 16:03:15 --> Final output sent to browser
DEBUG - 2014-01-19 16:03:15 --> Total execution time: 0.0961
DEBUG - 2014-01-19 16:03:42 --> Config Class Initialized
DEBUG - 2014-01-19 16:03:42 --> Hooks Class Initialized
DEBUG - 2014-01-19 16:03:42 --> Utf8 Class Initialized
DEBUG - 2014-01-19 16:03:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 16:03:42 --> URI Class Initialized
DEBUG - 2014-01-19 16:03:42 --> Router Class Initialized
DEBUG - 2014-01-19 16:03:42 --> Output Class Initialized
DEBUG - 2014-01-19 16:03:42 --> Security Class Initialized
DEBUG - 2014-01-19 16:03:42 --> Input Class Initialized
DEBUG - 2014-01-19 16:03:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 16:03:42 --> Language Class Initialized
DEBUG - 2014-01-19 16:03:42 --> Loader Class Initialized
DEBUG - 2014-01-19 16:03:42 --> Helper loaded: url_helper
DEBUG - 2014-01-19 16:03:42 --> Helper loaded: form_helper
DEBUG - 2014-01-19 16:03:42 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 16:03:42 --> Database Driver Class Initialized
DEBUG - 2014-01-19 16:03:42 --> Session Class Initialized
DEBUG - 2014-01-19 16:03:42 --> Helper loaded: string_helper
DEBUG - 2014-01-19 16:03:42 --> Session routines successfully run
DEBUG - 2014-01-19 16:03:42 --> User Agent Class Initialized
DEBUG - 2014-01-19 16:03:42 --> Form Validation Class Initialized
DEBUG - 2014-01-19 16:03:42 --> Model Class Initialized
DEBUG - 2014-01-19 16:03:42 --> Model Class Initialized
DEBUG - 2014-01-19 16:03:42 --> Controller Class Initialized
DEBUG - 2014-01-19 16:03:42 --> Config Class Initialized
DEBUG - 2014-01-19 16:03:42 --> Hooks Class Initialized
DEBUG - 2014-01-19 16:03:42 --> Utf8 Class Initialized
DEBUG - 2014-01-19 16:03:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 16:03:42 --> URI Class Initialized
DEBUG - 2014-01-19 16:03:42 --> Router Class Initialized
DEBUG - 2014-01-19 16:03:42 --> No URI present. Default controller set.
DEBUG - 2014-01-19 16:03:42 --> Output Class Initialized
DEBUG - 2014-01-19 16:03:42 --> Security Class Initialized
DEBUG - 2014-01-19 16:03:42 --> Input Class Initialized
DEBUG - 2014-01-19 16:03:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 16:03:42 --> Language Class Initialized
DEBUG - 2014-01-19 16:03:42 --> Loader Class Initialized
DEBUG - 2014-01-19 16:03:42 --> Helper loaded: url_helper
DEBUG - 2014-01-19 16:03:42 --> Helper loaded: form_helper
DEBUG - 2014-01-19 16:03:42 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 16:03:42 --> Database Driver Class Initialized
DEBUG - 2014-01-19 16:03:42 --> Session Class Initialized
DEBUG - 2014-01-19 16:03:42 --> Helper loaded: string_helper
DEBUG - 2014-01-19 16:03:42 --> Session routines successfully run
DEBUG - 2014-01-19 16:03:42 --> User Agent Class Initialized
DEBUG - 2014-01-19 16:03:42 --> Form Validation Class Initialized
DEBUG - 2014-01-19 16:03:42 --> Model Class Initialized
DEBUG - 2014-01-19 16:03:42 --> Model Class Initialized
DEBUG - 2014-01-19 16:03:42 --> Controller Class Initialized
DEBUG - 2014-01-19 16:03:42 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-19 16:03:42 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 16:03:42 --> Final output sent to browser
DEBUG - 2014-01-19 16:03:42 --> Total execution time: 0.0518
DEBUG - 2014-01-19 22:45:24 --> Config Class Initialized
DEBUG - 2014-01-19 22:45:24 --> Hooks Class Initialized
DEBUG - 2014-01-19 22:45:24 --> Utf8 Class Initialized
DEBUG - 2014-01-19 22:45:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 22:45:24 --> URI Class Initialized
DEBUG - 2014-01-19 22:45:24 --> Router Class Initialized
DEBUG - 2014-01-19 22:45:24 --> No URI present. Default controller set.
DEBUG - 2014-01-19 22:45:24 --> Output Class Initialized
DEBUG - 2014-01-19 22:45:24 --> Security Class Initialized
DEBUG - 2014-01-19 22:45:24 --> Input Class Initialized
DEBUG - 2014-01-19 22:45:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 22:45:24 --> Language Class Initialized
DEBUG - 2014-01-19 22:45:24 --> Loader Class Initialized
DEBUG - 2014-01-19 22:45:24 --> Helper loaded: url_helper
DEBUG - 2014-01-19 22:45:24 --> Helper loaded: form_helper
DEBUG - 2014-01-19 22:45:24 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 22:45:24 --> Database Driver Class Initialized
DEBUG - 2014-01-19 22:45:24 --> Session Class Initialized
DEBUG - 2014-01-19 22:45:24 --> Helper loaded: string_helper
DEBUG - 2014-01-19 22:45:24 --> A session cookie was not found.
DEBUG - 2014-01-19 22:45:24 --> Session routines successfully run
DEBUG - 2014-01-19 22:45:24 --> User Agent Class Initialized
DEBUG - 2014-01-19 22:45:24 --> Form Validation Class Initialized
DEBUG - 2014-01-19 22:45:24 --> Model Class Initialized
DEBUG - 2014-01-19 22:45:24 --> Model Class Initialized
DEBUG - 2014-01-19 22:45:24 --> Controller Class Initialized
DEBUG - 2014-01-19 22:45:24 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-19 22:45:24 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 22:45:24 --> Final output sent to browser
DEBUG - 2014-01-19 22:45:24 --> Total execution time: 0.0878
DEBUG - 2014-01-19 22:45:28 --> Config Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Hooks Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Utf8 Class Initialized
DEBUG - 2014-01-19 22:45:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 22:45:28 --> URI Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Router Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Output Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Security Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Input Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 22:45:28 --> Language Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Loader Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Helper loaded: url_helper
DEBUG - 2014-01-19 22:45:28 --> Helper loaded: form_helper
DEBUG - 2014-01-19 22:45:28 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 22:45:28 --> Database Driver Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Session Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Helper loaded: string_helper
DEBUG - 2014-01-19 22:45:28 --> Session routines successfully run
DEBUG - 2014-01-19 22:45:28 --> User Agent Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Form Validation Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Model Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Model Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Controller Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-19 22:45:28 --> Config Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Hooks Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Utf8 Class Initialized
DEBUG - 2014-01-19 22:45:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 22:45:28 --> URI Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Router Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Output Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Security Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Input Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 22:45:28 --> Language Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Loader Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Helper loaded: url_helper
DEBUG - 2014-01-19 22:45:28 --> Helper loaded: form_helper
DEBUG - 2014-01-19 22:45:28 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 22:45:28 --> Database Driver Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Session Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Helper loaded: string_helper
DEBUG - 2014-01-19 22:45:28 --> Session routines successfully run
DEBUG - 2014-01-19 22:45:28 --> User Agent Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Form Validation Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Model Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Model Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Controller Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Model Class Initialized
DEBUG - 2014-01-19 22:45:28 --> Model Class Initialized
DEBUG - 2014-01-19 22:45:28 --> File loaded: application/views/wniosek/lista.php
DEBUG - 2014-01-19 22:45:28 --> File loaded: application/views/user/aktualnosci.php
DEBUG - 2014-01-19 22:45:28 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 22:45:28 --> Final output sent to browser
DEBUG - 2014-01-19 22:45:28 --> Total execution time: 0.1840
DEBUG - 2014-01-19 22:45:31 --> Config Class Initialized
DEBUG - 2014-01-19 22:45:31 --> Hooks Class Initialized
DEBUG - 2014-01-19 22:45:31 --> Utf8 Class Initialized
DEBUG - 2014-01-19 22:45:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 22:45:31 --> URI Class Initialized
DEBUG - 2014-01-19 22:45:31 --> Router Class Initialized
DEBUG - 2014-01-19 22:45:31 --> Output Class Initialized
DEBUG - 2014-01-19 22:45:31 --> Security Class Initialized
DEBUG - 2014-01-19 22:45:31 --> Input Class Initialized
DEBUG - 2014-01-19 22:45:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 22:45:31 --> Language Class Initialized
DEBUG - 2014-01-19 22:45:31 --> Loader Class Initialized
DEBUG - 2014-01-19 22:45:31 --> Helper loaded: url_helper
DEBUG - 2014-01-19 22:45:31 --> Helper loaded: form_helper
DEBUG - 2014-01-19 22:45:31 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 22:45:31 --> Database Driver Class Initialized
DEBUG - 2014-01-19 22:45:31 --> Session Class Initialized
DEBUG - 2014-01-19 22:45:31 --> Helper loaded: string_helper
DEBUG - 2014-01-19 22:45:31 --> Session routines successfully run
DEBUG - 2014-01-19 22:45:31 --> User Agent Class Initialized
DEBUG - 2014-01-19 22:45:31 --> Form Validation Class Initialized
DEBUG - 2014-01-19 22:45:31 --> Model Class Initialized
DEBUG - 2014-01-19 22:45:31 --> Model Class Initialized
DEBUG - 2014-01-19 22:45:31 --> Controller Class Initialized
DEBUG - 2014-01-19 22:45:31 --> Model Class Initialized
DEBUG - 2014-01-19 22:45:31 --> Model Class Initialized
DEBUG - 2014-01-19 22:45:31 --> Model Class Initialized
DEBUG - 2014-01-19 22:45:31 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-19 22:45:31 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-19 22:45:31 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-19 22:45:31 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 22:45:31 --> Final output sent to browser
DEBUG - 2014-01-19 22:45:31 --> Total execution time: 0.0970
DEBUG - 2014-01-19 22:45:42 --> Config Class Initialized
DEBUG - 2014-01-19 22:45:42 --> Hooks Class Initialized
DEBUG - 2014-01-19 22:45:42 --> Utf8 Class Initialized
DEBUG - 2014-01-19 22:45:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 22:45:42 --> URI Class Initialized
DEBUG - 2014-01-19 22:45:42 --> Router Class Initialized
DEBUG - 2014-01-19 22:45:42 --> Output Class Initialized
DEBUG - 2014-01-19 22:45:42 --> Security Class Initialized
DEBUG - 2014-01-19 22:45:42 --> Input Class Initialized
DEBUG - 2014-01-19 22:45:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 22:45:42 --> Language Class Initialized
DEBUG - 2014-01-19 22:45:42 --> Loader Class Initialized
DEBUG - 2014-01-19 22:45:42 --> Helper loaded: url_helper
DEBUG - 2014-01-19 22:45:42 --> Helper loaded: form_helper
DEBUG - 2014-01-19 22:45:42 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 22:45:42 --> Database Driver Class Initialized
DEBUG - 2014-01-19 22:45:42 --> Session Class Initialized
DEBUG - 2014-01-19 22:45:42 --> Helper loaded: string_helper
DEBUG - 2014-01-19 22:45:42 --> Session routines successfully run
DEBUG - 2014-01-19 22:45:42 --> User Agent Class Initialized
DEBUG - 2014-01-19 22:45:42 --> Form Validation Class Initialized
DEBUG - 2014-01-19 22:45:42 --> Model Class Initialized
DEBUG - 2014-01-19 22:45:42 --> Model Class Initialized
DEBUG - 2014-01-19 22:45:42 --> Controller Class Initialized
DEBUG - 2014-01-19 22:45:42 --> Model Class Initialized
DEBUG - 2014-01-19 22:45:42 --> Model Class Initialized
DEBUG - 2014-01-19 22:45:42 --> Model Class Initialized
DEBUG - 2014-01-19 22:45:42 --> Model Class Initialized
DEBUG - 2014-01-19 22:45:42 --> File loaded: application/views/wplata/lista.php
DEBUG - 2014-01-19 22:45:42 --> File loaded: application/views/sprawa/szczegoly.php
DEBUG - 2014-01-19 22:45:42 --> File loaded: application/views/index.php
DEBUG - 2014-01-19 22:45:42 --> Final output sent to browser
DEBUG - 2014-01-19 22:45:42 --> Total execution time: 0.1507
DEBUG - 2014-01-19 22:45:47 --> Config Class Initialized
DEBUG - 2014-01-19 22:45:47 --> Hooks Class Initialized
DEBUG - 2014-01-19 22:45:47 --> Utf8 Class Initialized
DEBUG - 2014-01-19 22:45:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 22:45:47 --> URI Class Initialized
DEBUG - 2014-01-19 22:45:47 --> Router Class Initialized
DEBUG - 2014-01-19 22:45:47 --> Output Class Initialized
DEBUG - 2014-01-19 22:45:47 --> Security Class Initialized
DEBUG - 2014-01-19 22:45:47 --> Input Class Initialized
DEBUG - 2014-01-19 22:45:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 22:45:47 --> Language Class Initialized
DEBUG - 2014-01-19 22:45:47 --> Loader Class Initialized
DEBUG - 2014-01-19 22:45:47 --> Helper loaded: url_helper
DEBUG - 2014-01-19 22:45:47 --> Helper loaded: form_helper
DEBUG - 2014-01-19 22:45:47 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 22:45:47 --> Database Driver Class Initialized
DEBUG - 2014-01-19 22:45:47 --> Session Class Initialized
DEBUG - 2014-01-19 22:45:47 --> Helper loaded: string_helper
DEBUG - 2014-01-19 22:45:47 --> Session routines successfully run
DEBUG - 2014-01-19 22:45:47 --> User Agent Class Initialized
DEBUG - 2014-01-19 22:45:47 --> Form Validation Class Initialized
DEBUG - 2014-01-19 22:45:47 --> Model Class Initialized
DEBUG - 2014-01-19 22:45:47 --> Model Class Initialized
DEBUG - 2014-01-19 22:45:47 --> Controller Class Initialized
DEBUG - 2014-01-19 22:45:47 --> Model Class Initialized
DEBUG - 2014-01-19 22:45:47 --> Model Class Initialized
DEBUG - 2014-01-19 22:45:47 --> Model Class Initialized
DEBUG - 2014-01-19 22:45:48 --> Config Class Initialized
DEBUG - 2014-01-19 22:45:48 --> Hooks Class Initialized
DEBUG - 2014-01-19 22:45:48 --> Utf8 Class Initialized
DEBUG - 2014-01-19 22:45:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-19 22:45:48 --> URI Class Initialized
DEBUG - 2014-01-19 22:45:48 --> Router Class Initialized
DEBUG - 2014-01-19 22:45:48 --> Output Class Initialized
DEBUG - 2014-01-19 22:45:48 --> Security Class Initialized
DEBUG - 2014-01-19 22:45:48 --> Input Class Initialized
DEBUG - 2014-01-19 22:45:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-19 22:45:48 --> Language Class Initialized
DEBUG - 2014-01-19 22:45:48 --> Loader Class Initialized
DEBUG - 2014-01-19 22:45:48 --> Helper loaded: url_helper
DEBUG - 2014-01-19 22:45:48 --> Helper loaded: form_helper
DEBUG - 2014-01-19 22:45:48 --> Helper loaded: custom_helper
DEBUG - 2014-01-19 22:45:48 --> Database Driver Class Initialized
DEBUG - 2014-01-19 22:45:48 --> Session Class Initialized
DEBUG - 2014-01-19 22:45:48 --> Helper loaded: string_helper
DEBUG - 2014-01-19 22:45:48 --> A session cookie was not found.
DEBUG - 2014-01-19 22:45:48 --> Session routines successfully run
DEBUG - 2014-01-19 22:45:48 --> User Agent Class Initialized
DEBUG - 2014-01-19 22:45:48 --> Form Validation Class Initialized
DEBUG - 2014-01-19 22:45:48 --> Model Class Initialized
DEBUG - 2014-01-19 22:45:48 --> Model Class Initialized
DEBUG - 2014-01-19 22:45:48 --> Controller Class Initialized
DEBUG - 2014-01-19 22:45:48 --> Model Class Initialized
DEBUG - 2014-01-19 22:45:48 --> Model Class Initialized
DEBUG - 2014-01-19 22:45:48 --> Model Class Initialized
DEBUG - 2014-01-19 22:45:48 --> File loaded: application/views/formularz/planPodzialu.php
DEBUG - 2014-01-19 22:45:48 --> File loaded: application/views/formularz/layoutWewnetrzny.php
DEBUG - 2014-01-19 22:45:48 --> Final output sent to browser
DEBUG - 2014-01-19 22:45:48 --> Total execution time: 0.1619
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: BODY C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: BODY>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined offset: -1 C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1150
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: DIV C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: ID>>CONTAINER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1003
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: DIV>>ID>>CONTAINER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: DIV C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: ID>>CONTAINER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1003
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: DIV>>ID>>CONTAINER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: DIV C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: ID>>HEADER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1003
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: DIV>>ID>>HEADER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: DIV C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: ID>>HEADER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1003
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: DIV>>ID>>HEADER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: direction C:\wamp\www\Windykator1\MPDF57\mpdf.php 18502
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: direction C:\wamp\www\Windykator1\MPDF57\mpdf.php 18502
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: DIV C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: CLASS>>CONTENT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CONTENT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: CLASS>>CONTENT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CONTENT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: DIV C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: DIV>>ID>>PLANPODZIALU C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: ID>>PLANPODZIALU C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1003
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: DIV>>ID>>PLANPODZIALU C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P>>CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P>>CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P>>CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P>>CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P>>CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TABLE C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TABLE>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TABLE C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TABLE>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TR>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TR>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TR>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TR>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:48 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: CLASS>>NO_BORDER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>CLASS>>NO_BORDER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: CLASS>>NO_BORDER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>CLASS>>NO_BORDER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined variable: pre C:\wamp\www\Windykator1\MPDF57\mpdf.php 12604
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined variable: post C:\wamp\www\Windykator1\MPDF57\mpdf.php 12604
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined variable: prelength C:\wamp\www\Windykator1\MPDF57\mpdf.php 12604
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined offset: 4 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined offset: 5 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined offset: 6 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined offset: 7 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined offset: 8 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined offset: 9 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined offset: 10 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined offset: 11 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:49 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: P>>CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: P>>CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: z-index C:\wamp\www\Windykator1\MPDF57\mpdf.php 2464
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: z-index C:\wamp\www\Windykator1\MPDF57\mpdf.php 2464
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: z-index C:\wamp\www\Windykator1\MPDF57\mpdf.php 2464
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: OL C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: OL>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: OL C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: OL>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: OL C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: OL>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: OL C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: OL>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI>>CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI>>CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: OL C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: OL>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: OL C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: OL>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: direction C:\wamp\www\Windykator1\MPDF57\mpdf.php 18502
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: direction C:\wamp\www\Windykator1\MPDF57\mpdf.php 18502
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined index: direction C:\wamp\www\Windykator1\MPDF57\mpdf.php 18502
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined property: mPDF::$hasOC C:\wamp\www\Windykator1\MPDF57\mpdf.php 27505
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined property: mPDF::$hasOC C:\wamp\www\Windykator1\MPDF57\mpdf.php 27608
ERROR - 2014-01-19 22:45:51 --> Severity: Notice  --> Undefined property: mPDF::$hasOC C:\wamp\www\Windykator1\MPDF57\mpdf.php 9158
DEBUG - 2014-01-19 22:45:51 --> Final output sent to browser
DEBUG - 2014-01-19 22:45:51 --> Total execution time: 3.8930
