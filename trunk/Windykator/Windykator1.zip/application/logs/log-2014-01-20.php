<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-01-20 00:08:16 --> Config Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Hooks Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Utf8 Class Initialized
DEBUG - 2014-01-20 00:08:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 00:08:16 --> URI Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Router Class Initialized
DEBUG - 2014-01-20 00:08:16 --> No URI present. Default controller set.
DEBUG - 2014-01-20 00:08:16 --> Output Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Security Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Input Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 00:08:16 --> Language Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Loader Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Helper loaded: url_helper
DEBUG - 2014-01-20 00:08:16 --> Helper loaded: form_helper
DEBUG - 2014-01-20 00:08:16 --> Helper loaded: custom_helper
DEBUG - 2014-01-20 00:08:16 --> Database Driver Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Session Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Helper loaded: string_helper
DEBUG - 2014-01-20 00:08:16 --> Session routines successfully run
DEBUG - 2014-01-20 00:08:16 --> User Agent Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Form Validation Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Controller Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Config Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Hooks Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Utf8 Class Initialized
DEBUG - 2014-01-20 00:08:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 00:08:16 --> URI Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Router Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Output Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Security Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Input Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 00:08:16 --> Language Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Loader Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Helper loaded: url_helper
DEBUG - 2014-01-20 00:08:16 --> Helper loaded: form_helper
DEBUG - 2014-01-20 00:08:16 --> Helper loaded: custom_helper
DEBUG - 2014-01-20 00:08:16 --> Database Driver Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Session Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Helper loaded: string_helper
DEBUG - 2014-01-20 00:08:16 --> Session routines successfully run
DEBUG - 2014-01-20 00:08:16 --> User Agent Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Form Validation Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Controller Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:16 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:16 --> File loaded: application/views/wniosek/lista.php
DEBUG - 2014-01-20 00:08:16 --> File loaded: application/views/user/aktualnosci.php
DEBUG - 2014-01-20 00:08:16 --> File loaded: application/views/index.php
DEBUG - 2014-01-20 00:08:16 --> Final output sent to browser
DEBUG - 2014-01-20 00:08:16 --> Total execution time: 0.3305
DEBUG - 2014-01-20 00:08:26 --> Config Class Initialized
DEBUG - 2014-01-20 00:08:26 --> Hooks Class Initialized
DEBUG - 2014-01-20 00:08:26 --> Utf8 Class Initialized
DEBUG - 2014-01-20 00:08:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 00:08:26 --> URI Class Initialized
DEBUG - 2014-01-20 00:08:26 --> Router Class Initialized
DEBUG - 2014-01-20 00:08:26 --> Output Class Initialized
DEBUG - 2014-01-20 00:08:26 --> Security Class Initialized
DEBUG - 2014-01-20 00:08:26 --> Input Class Initialized
DEBUG - 2014-01-20 00:08:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 00:08:26 --> Language Class Initialized
DEBUG - 2014-01-20 00:08:26 --> Loader Class Initialized
DEBUG - 2014-01-20 00:08:26 --> Helper loaded: url_helper
DEBUG - 2014-01-20 00:08:26 --> Helper loaded: form_helper
DEBUG - 2014-01-20 00:08:26 --> Helper loaded: custom_helper
DEBUG - 2014-01-20 00:08:26 --> Database Driver Class Initialized
DEBUG - 2014-01-20 00:08:26 --> Session Class Initialized
DEBUG - 2014-01-20 00:08:26 --> Helper loaded: string_helper
DEBUG - 2014-01-20 00:08:26 --> Session routines successfully run
DEBUG - 2014-01-20 00:08:26 --> User Agent Class Initialized
DEBUG - 2014-01-20 00:08:26 --> Form Validation Class Initialized
DEBUG - 2014-01-20 00:08:26 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:26 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:26 --> Controller Class Initialized
DEBUG - 2014-01-20 00:08:26 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:26 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:26 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:26 --> File loaded: application/views/sprawa/szukaj.php
DEBUG - 2014-01-20 00:08:26 --> File loaded: application/views/sprawa/lista.php
DEBUG - 2014-01-20 00:08:26 --> File loaded: application/views/sprawa/zarzadzanie.php
DEBUG - 2014-01-20 00:08:26 --> File loaded: application/views/index.php
DEBUG - 2014-01-20 00:08:26 --> Final output sent to browser
DEBUG - 2014-01-20 00:08:26 --> Total execution time: 0.0860
DEBUG - 2014-01-20 00:08:36 --> Config Class Initialized
DEBUG - 2014-01-20 00:08:36 --> Hooks Class Initialized
DEBUG - 2014-01-20 00:08:36 --> Utf8 Class Initialized
DEBUG - 2014-01-20 00:08:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 00:08:36 --> URI Class Initialized
DEBUG - 2014-01-20 00:08:36 --> Router Class Initialized
DEBUG - 2014-01-20 00:08:36 --> Output Class Initialized
DEBUG - 2014-01-20 00:08:36 --> Security Class Initialized
DEBUG - 2014-01-20 00:08:36 --> Input Class Initialized
DEBUG - 2014-01-20 00:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 00:08:36 --> Language Class Initialized
DEBUG - 2014-01-20 00:08:36 --> Loader Class Initialized
DEBUG - 2014-01-20 00:08:36 --> Helper loaded: url_helper
DEBUG - 2014-01-20 00:08:36 --> Helper loaded: form_helper
DEBUG - 2014-01-20 00:08:36 --> Helper loaded: custom_helper
DEBUG - 2014-01-20 00:08:36 --> Database Driver Class Initialized
DEBUG - 2014-01-20 00:08:36 --> Session Class Initialized
DEBUG - 2014-01-20 00:08:36 --> Helper loaded: string_helper
DEBUG - 2014-01-20 00:08:36 --> Session routines successfully run
DEBUG - 2014-01-20 00:08:36 --> User Agent Class Initialized
DEBUG - 2014-01-20 00:08:36 --> Form Validation Class Initialized
DEBUG - 2014-01-20 00:08:36 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:36 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:36 --> Controller Class Initialized
DEBUG - 2014-01-20 00:08:36 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:36 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:36 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:36 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:36 --> File loaded: application/views/wplata/lista.php
DEBUG - 2014-01-20 00:08:36 --> File loaded: application/views/sprawa/szczegoly.php
DEBUG - 2014-01-20 00:08:36 --> File loaded: application/views/index.php
DEBUG - 2014-01-20 00:08:36 --> Final output sent to browser
DEBUG - 2014-01-20 00:08:36 --> Total execution time: 0.1126
DEBUG - 2014-01-20 00:08:42 --> Config Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Hooks Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Utf8 Class Initialized
DEBUG - 2014-01-20 00:08:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 00:08:42 --> URI Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Router Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Output Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Security Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Input Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 00:08:42 --> Language Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Loader Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Helper loaded: url_helper
DEBUG - 2014-01-20 00:08:42 --> Helper loaded: form_helper
DEBUG - 2014-01-20 00:08:42 --> Helper loaded: custom_helper
DEBUG - 2014-01-20 00:08:42 --> Database Driver Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Session Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Helper loaded: string_helper
DEBUG - 2014-01-20 00:08:42 --> Session routines successfully run
DEBUG - 2014-01-20 00:08:42 --> User Agent Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Form Validation Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Controller Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Config Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Hooks Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Utf8 Class Initialized
DEBUG - 2014-01-20 00:08:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 00:08:42 --> URI Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Router Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Output Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Security Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Input Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 00:08:42 --> Language Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Loader Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Helper loaded: url_helper
DEBUG - 2014-01-20 00:08:42 --> Helper loaded: form_helper
DEBUG - 2014-01-20 00:08:42 --> Helper loaded: custom_helper
DEBUG - 2014-01-20 00:08:42 --> Database Driver Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Session Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Helper loaded: string_helper
DEBUG - 2014-01-20 00:08:42 --> A session cookie was not found.
DEBUG - 2014-01-20 00:08:42 --> Session routines successfully run
DEBUG - 2014-01-20 00:08:42 --> User Agent Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Form Validation Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Controller Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:42 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:42 --> File loaded: application/views/formularz/kartaWierzyciela.php
DEBUG - 2014-01-20 00:08:42 --> File loaded: application/views/formularz/layoutWewnetrzny.php
DEBUG - 2014-01-20 00:08:42 --> Final output sent to browser
DEBUG - 2014-01-20 00:08:42 --> Total execution time: 0.1527
ERROR - 2014-01-20 00:08:42 --> Severity: Notice  --> Undefined index: BODY C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:42 --> Severity: Notice  --> Undefined index: BODY>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:42 --> Severity: Notice  --> Undefined offset: -1 C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1150
ERROR - 2014-01-20 00:08:42 --> Severity: Notice  --> Undefined index: DIV C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:42 --> Severity: Notice  --> Undefined index: ID>>CONTAINER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1003
ERROR - 2014-01-20 00:08:42 --> Severity: Notice  --> Undefined index: DIV>>ID>>CONTAINER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:42 --> Severity: Notice  --> Undefined index: DIV C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:42 --> Severity: Notice  --> Undefined index: ID>>CONTAINER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1003
ERROR - 2014-01-20 00:08:42 --> Severity: Notice  --> Undefined index: DIV>>ID>>CONTAINER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: DIV C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: ID>>HEADER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1003
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: DIV>>ID>>HEADER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: DIV C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: ID>>HEADER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1003
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: DIV>>ID>>HEADER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: direction C:\wamp\www\Windykator1\MPDF57\mpdf.php 18502
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: direction C:\wamp\www\Windykator1\MPDF57\mpdf.php 18502
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: DIV C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: CLASS>>CONTENT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CONTENT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: CLASS>>CONTENT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CONTENT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: DIV C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: DIV>>ID>>KARTAWIERZYCIELA C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: ID>>KARTAWIERZYCIELA C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1003
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: DIV>>ID>>KARTAWIERZYCIELA C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P>>CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P>>CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TABLE C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: CLASS>>UCZESTNICYW C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TABLE>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TABLE C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: CLASS>>UCZESTNICYW C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TABLE>>CLASS>>UCZESTNICYW C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TABLE>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined variable: miwnon C:\wamp\www\Windykator1\MPDF57\mpdf.php 23847
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined variable: mawnon C:\wamp\www\Windykator1\MPDF57\mpdf.php 23866
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined variable: mawnon C:\wamp\www\Windykator1\MPDF57\mpdf.php 23867
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TABLE C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TABLE>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TABLE C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TABLE>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined offset: 4 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined offset: 5 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined offset: 6 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined offset: 7 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P>>CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P>>CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: z-index C:\wamp\www\Windykator1\MPDF57\mpdf.php 2464
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: z-index C:\wamp\www\Windykator1\MPDF57\mpdf.php 2464
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: z-index C:\wamp\www\Windykator1\MPDF57\mpdf.php 2464
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: OL C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: OL>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined offset: -1 C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1130
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: direction C:\wamp\www\Windykator1\MPDF57\mpdf.php 18502
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: direction C:\wamp\www\Windykator1\MPDF57\mpdf.php 18502
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined index: direction C:\wamp\www\Windykator1\MPDF57\mpdf.php 18502
ERROR - 2014-01-20 00:08:43 --> Severity: Notice  --> Undefined property: mPDF::$hasOC C:\wamp\www\Windykator1\MPDF57\mpdf.php 27505
ERROR - 2014-01-20 00:08:44 --> Severity: Notice  --> Undefined property: mPDF::$hasOC C:\wamp\www\Windykator1\MPDF57\mpdf.php 27608
ERROR - 2014-01-20 00:08:44 --> Severity: Notice  --> Undefined property: mPDF::$hasOC C:\wamp\www\Windykator1\MPDF57\mpdf.php 9158
DEBUG - 2014-01-20 00:08:44 --> Final output sent to browser
DEBUG - 2014-01-20 00:08:44 --> Total execution time: 1.8621
DEBUG - 2014-01-20 00:08:50 --> Config Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Hooks Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Utf8 Class Initialized
DEBUG - 2014-01-20 00:08:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 00:08:50 --> URI Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Router Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Output Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Security Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Input Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 00:08:50 --> Language Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Loader Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Helper loaded: url_helper
DEBUG - 2014-01-20 00:08:50 --> Helper loaded: form_helper
DEBUG - 2014-01-20 00:08:50 --> Helper loaded: custom_helper
DEBUG - 2014-01-20 00:08:50 --> Database Driver Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Session Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Helper loaded: string_helper
DEBUG - 2014-01-20 00:08:50 --> Session routines successfully run
DEBUG - 2014-01-20 00:08:50 --> User Agent Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Form Validation Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Controller Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Config Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Hooks Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Utf8 Class Initialized
DEBUG - 2014-01-20 00:08:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 00:08:50 --> URI Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Router Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Output Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Security Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Input Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 00:08:50 --> Language Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Loader Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Helper loaded: url_helper
DEBUG - 2014-01-20 00:08:50 --> Helper loaded: form_helper
DEBUG - 2014-01-20 00:08:50 --> Helper loaded: custom_helper
DEBUG - 2014-01-20 00:08:50 --> Database Driver Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Session Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Helper loaded: string_helper
DEBUG - 2014-01-20 00:08:50 --> A session cookie was not found.
DEBUG - 2014-01-20 00:08:50 --> Session routines successfully run
DEBUG - 2014-01-20 00:08:50 --> User Agent Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Form Validation Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Controller Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:50 --> Model Class Initialized
DEBUG - 2014-01-20 00:08:50 --> File loaded: application/views/formularz/kartaWierzyciela.php
DEBUG - 2014-01-20 00:08:50 --> File loaded: application/views/formularz/layoutWewnetrzny.php
DEBUG - 2014-01-20 00:08:50 --> Final output sent to browser
DEBUG - 2014-01-20 00:08:50 --> Total execution time: 0.0628
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: BODY C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: BODY>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined offset: -1 C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1150
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: DIV C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: ID>>CONTAINER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1003
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: DIV>>ID>>CONTAINER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: DIV C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: ID>>CONTAINER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1003
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: DIV>>ID>>CONTAINER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: DIV C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: ID>>HEADER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1003
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: DIV>>ID>>HEADER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: DIV C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: ID>>HEADER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1003
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: DIV>>ID>>HEADER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: direction C:\wamp\www\Windykator1\MPDF57\mpdf.php 18502
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: direction C:\wamp\www\Windykator1\MPDF57\mpdf.php 18502
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: DIV C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: CLASS>>CONTENT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CONTENT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: CLASS>>CONTENT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CONTENT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: DIV C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: DIV>>ID>>KARTAWIERZYCIELA C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: ID>>KARTAWIERZYCIELA C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1003
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: DIV>>ID>>KARTAWIERZYCIELA C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P>>CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P>>CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TABLE C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: CLASS>>UCZESTNICYW C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TABLE>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TABLE C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: CLASS>>UCZESTNICYW C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TABLE>>CLASS>>UCZESTNICYW C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TABLE>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined variable: miwnon C:\wamp\www\Windykator1\MPDF57\mpdf.php 23847
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined variable: mawnon C:\wamp\www\Windykator1\MPDF57\mpdf.php 23866
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined variable: mawnon C:\wamp\www\Windykator1\MPDF57\mpdf.php 23867
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TABLE C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TABLE>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TABLE C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TABLE>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined offset: 4 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined offset: 5 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined offset: 6 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined offset: 7 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P>>CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P>>CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: z-index C:\wamp\www\Windykator1\MPDF57\mpdf.php 2464
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: z-index C:\wamp\www\Windykator1\MPDF57\mpdf.php 2464
ERROR - 2014-01-20 00:08:50 --> Severity: Notice  --> Undefined index: z-index C:\wamp\www\Windykator1\MPDF57\mpdf.php 2464
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: OL C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: OL>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined offset: -1 C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1130
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: direction C:\wamp\www\Windykator1\MPDF57\mpdf.php 18502
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: direction C:\wamp\www\Windykator1\MPDF57\mpdf.php 18502
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined index: direction C:\wamp\www\Windykator1\MPDF57\mpdf.php 18502
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined property: mPDF::$hasOC C:\wamp\www\Windykator1\MPDF57\mpdf.php 27505
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined property: mPDF::$hasOC C:\wamp\www\Windykator1\MPDF57\mpdf.php 27608
ERROR - 2014-01-20 00:08:51 --> Severity: Notice  --> Undefined property: mPDF::$hasOC C:\wamp\www\Windykator1\MPDF57\mpdf.php 9158
DEBUG - 2014-01-20 00:08:51 --> Final output sent to browser
DEBUG - 2014-01-20 00:08:51 --> Total execution time: 1.0215
DEBUG - 2014-01-20 00:11:10 --> Config Class Initialized
DEBUG - 2014-01-20 00:11:10 --> Hooks Class Initialized
DEBUG - 2014-01-20 00:11:10 --> Utf8 Class Initialized
DEBUG - 2014-01-20 00:11:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 00:11:10 --> URI Class Initialized
DEBUG - 2014-01-20 00:11:10 --> Router Class Initialized
DEBUG - 2014-01-20 00:11:10 --> Output Class Initialized
DEBUG - 2014-01-20 00:11:10 --> Security Class Initialized
DEBUG - 2014-01-20 00:11:10 --> Input Class Initialized
DEBUG - 2014-01-20 00:11:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 00:11:10 --> Language Class Initialized
DEBUG - 2014-01-20 00:11:10 --> Loader Class Initialized
DEBUG - 2014-01-20 00:11:10 --> Helper loaded: url_helper
DEBUG - 2014-01-20 00:11:10 --> Helper loaded: form_helper
DEBUG - 2014-01-20 00:11:10 --> Helper loaded: custom_helper
DEBUG - 2014-01-20 00:11:10 --> Database Driver Class Initialized
DEBUG - 2014-01-20 00:11:10 --> Session Class Initialized
DEBUG - 2014-01-20 00:11:10 --> Helper loaded: string_helper
DEBUG - 2014-01-20 00:11:10 --> Session routines successfully run
DEBUG - 2014-01-20 00:11:10 --> User Agent Class Initialized
DEBUG - 2014-01-20 00:11:10 --> Form Validation Class Initialized
DEBUG - 2014-01-20 00:11:10 --> Model Class Initialized
DEBUG - 2014-01-20 00:11:10 --> Model Class Initialized
DEBUG - 2014-01-20 00:11:10 --> Controller Class Initialized
DEBUG - 2014-01-20 00:11:10 --> Config Class Initialized
DEBUG - 2014-01-20 00:11:10 --> Hooks Class Initialized
DEBUG - 2014-01-20 00:11:10 --> Utf8 Class Initialized
DEBUG - 2014-01-20 00:11:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 00:11:10 --> URI Class Initialized
DEBUG - 2014-01-20 00:11:10 --> Router Class Initialized
DEBUG - 2014-01-20 00:11:10 --> No URI present. Default controller set.
DEBUG - 2014-01-20 00:11:10 --> Output Class Initialized
DEBUG - 2014-01-20 00:11:10 --> Security Class Initialized
DEBUG - 2014-01-20 00:11:10 --> Input Class Initialized
DEBUG - 2014-01-20 00:11:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 00:11:10 --> Language Class Initialized
DEBUG - 2014-01-20 00:11:10 --> Loader Class Initialized
DEBUG - 2014-01-20 00:11:10 --> Helper loaded: url_helper
DEBUG - 2014-01-20 00:11:10 --> Helper loaded: form_helper
DEBUG - 2014-01-20 00:11:10 --> Helper loaded: custom_helper
DEBUG - 2014-01-20 00:11:10 --> Database Driver Class Initialized
DEBUG - 2014-01-20 00:11:10 --> Session Class Initialized
DEBUG - 2014-01-20 00:11:10 --> Helper loaded: string_helper
DEBUG - 2014-01-20 00:11:10 --> Session routines successfully run
DEBUG - 2014-01-20 00:11:10 --> User Agent Class Initialized
DEBUG - 2014-01-20 00:11:10 --> Form Validation Class Initialized
DEBUG - 2014-01-20 00:11:10 --> Model Class Initialized
DEBUG - 2014-01-20 00:11:10 --> Model Class Initialized
DEBUG - 2014-01-20 00:11:10 --> Controller Class Initialized
DEBUG - 2014-01-20 00:11:10 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-20 00:11:10 --> File loaded: application/views/index.php
DEBUG - 2014-01-20 00:11:10 --> Final output sent to browser
DEBUG - 2014-01-20 00:11:10 --> Total execution time: 0.0462
DEBUG - 2014-01-20 02:23:49 --> Config Class Initialized
DEBUG - 2014-01-20 02:23:49 --> Hooks Class Initialized
DEBUG - 2014-01-20 02:23:49 --> Utf8 Class Initialized
DEBUG - 2014-01-20 02:23:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 02:23:49 --> URI Class Initialized
DEBUG - 2014-01-20 02:23:49 --> Router Class Initialized
DEBUG - 2014-01-20 02:23:49 --> No URI present. Default controller set.
DEBUG - 2014-01-20 02:23:49 --> Output Class Initialized
DEBUG - 2014-01-20 02:23:49 --> Security Class Initialized
DEBUG - 2014-01-20 02:23:49 --> Input Class Initialized
DEBUG - 2014-01-20 02:23:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 02:23:49 --> Language Class Initialized
DEBUG - 2014-01-20 02:23:49 --> Loader Class Initialized
DEBUG - 2014-01-20 02:23:49 --> Helper loaded: url_helper
DEBUG - 2014-01-20 02:23:49 --> Helper loaded: form_helper
DEBUG - 2014-01-20 02:23:49 --> Helper loaded: custom_helper
DEBUG - 2014-01-20 02:23:49 --> Database Driver Class Initialized
DEBUG - 2014-01-20 02:23:49 --> Session Class Initialized
DEBUG - 2014-01-20 02:23:49 --> Helper loaded: string_helper
DEBUG - 2014-01-20 02:23:49 --> A session cookie was not found.
DEBUG - 2014-01-20 02:23:49 --> Session routines successfully run
DEBUG - 2014-01-20 02:23:49 --> User Agent Class Initialized
DEBUG - 2014-01-20 02:23:49 --> Form Validation Class Initialized
DEBUG - 2014-01-20 02:23:49 --> Model Class Initialized
DEBUG - 2014-01-20 02:23:49 --> Model Class Initialized
DEBUG - 2014-01-20 02:23:49 --> Controller Class Initialized
DEBUG - 2014-01-20 02:23:49 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-20 02:23:49 --> File loaded: application/views/index.php
DEBUG - 2014-01-20 02:23:49 --> Final output sent to browser
DEBUG - 2014-01-20 02:23:49 --> Total execution time: 0.0787
DEBUG - 2014-01-20 02:23:52 --> Config Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Hooks Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Utf8 Class Initialized
DEBUG - 2014-01-20 02:23:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 02:23:52 --> URI Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Router Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Output Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Security Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Input Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 02:23:52 --> Language Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Loader Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Helper loaded: url_helper
DEBUG - 2014-01-20 02:23:52 --> Helper loaded: form_helper
DEBUG - 2014-01-20 02:23:52 --> Helper loaded: custom_helper
DEBUG - 2014-01-20 02:23:52 --> Database Driver Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Session Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Helper loaded: string_helper
DEBUG - 2014-01-20 02:23:52 --> Session routines successfully run
DEBUG - 2014-01-20 02:23:52 --> User Agent Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Form Validation Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Model Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Model Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Controller Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-20 02:23:52 --> Config Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Hooks Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Utf8 Class Initialized
DEBUG - 2014-01-20 02:23:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 02:23:52 --> URI Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Router Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Output Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Security Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Input Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 02:23:52 --> Language Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Loader Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Helper loaded: url_helper
DEBUG - 2014-01-20 02:23:52 --> Helper loaded: form_helper
DEBUG - 2014-01-20 02:23:52 --> Helper loaded: custom_helper
DEBUG - 2014-01-20 02:23:52 --> Database Driver Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Session Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Helper loaded: string_helper
DEBUG - 2014-01-20 02:23:52 --> Session routines successfully run
DEBUG - 2014-01-20 02:23:52 --> User Agent Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Form Validation Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Model Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Model Class Initialized
DEBUG - 2014-01-20 02:23:52 --> Controller Class Initialized
DEBUG - 2014-01-20 02:23:52 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-20 02:23:52 --> File loaded: application/views/index.php
DEBUG - 2014-01-20 02:23:52 --> Final output sent to browser
DEBUG - 2014-01-20 02:23:52 --> Total execution time: 0.0570
DEBUG - 2014-01-20 02:23:59 --> Config Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Hooks Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Utf8 Class Initialized
DEBUG - 2014-01-20 02:23:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 02:23:59 --> URI Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Router Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Output Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Security Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Input Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 02:23:59 --> Language Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Loader Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Helper loaded: url_helper
DEBUG - 2014-01-20 02:23:59 --> Helper loaded: form_helper
DEBUG - 2014-01-20 02:23:59 --> Helper loaded: custom_helper
DEBUG - 2014-01-20 02:23:59 --> Database Driver Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Session Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Helper loaded: string_helper
DEBUG - 2014-01-20 02:23:59 --> Session routines successfully run
DEBUG - 2014-01-20 02:23:59 --> User Agent Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Form Validation Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Model Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Model Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Controller Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-20 02:23:59 --> Config Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Hooks Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Utf8 Class Initialized
DEBUG - 2014-01-20 02:23:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 02:23:59 --> URI Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Router Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Output Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Security Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Input Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 02:23:59 --> Language Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Loader Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Helper loaded: url_helper
DEBUG - 2014-01-20 02:23:59 --> Helper loaded: form_helper
DEBUG - 2014-01-20 02:23:59 --> Helper loaded: custom_helper
DEBUG - 2014-01-20 02:23:59 --> Database Driver Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Session Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Helper loaded: string_helper
DEBUG - 2014-01-20 02:23:59 --> Session routines successfully run
DEBUG - 2014-01-20 02:23:59 --> User Agent Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Form Validation Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Model Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Model Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Controller Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Model Class Initialized
DEBUG - 2014-01-20 02:23:59 --> Model Class Initialized
DEBUG - 2014-01-20 02:23:59 --> File loaded: application/views/wniosek/lista.php
DEBUG - 2014-01-20 02:23:59 --> File loaded: application/views/user/aktualnosci.php
DEBUG - 2014-01-20 02:23:59 --> File loaded: application/views/index.php
DEBUG - 2014-01-20 02:23:59 --> Final output sent to browser
DEBUG - 2014-01-20 02:23:59 --> Total execution time: 0.0738
DEBUG - 2014-01-20 02:24:06 --> Config Class Initialized
DEBUG - 2014-01-20 02:24:06 --> Hooks Class Initialized
DEBUG - 2014-01-20 02:24:06 --> Utf8 Class Initialized
DEBUG - 2014-01-20 02:24:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 02:24:06 --> URI Class Initialized
DEBUG - 2014-01-20 02:24:06 --> Router Class Initialized
DEBUG - 2014-01-20 02:24:06 --> Output Class Initialized
DEBUG - 2014-01-20 02:24:06 --> Security Class Initialized
DEBUG - 2014-01-20 02:24:06 --> Input Class Initialized
DEBUG - 2014-01-20 02:24:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 02:24:06 --> Language Class Initialized
DEBUG - 2014-01-20 02:24:06 --> Loader Class Initialized
DEBUG - 2014-01-20 02:24:06 --> Helper loaded: url_helper
DEBUG - 2014-01-20 02:24:06 --> Helper loaded: form_helper
DEBUG - 2014-01-20 02:24:06 --> Helper loaded: custom_helper
DEBUG - 2014-01-20 02:24:06 --> Database Driver Class Initialized
DEBUG - 2014-01-20 02:24:06 --> Session Class Initialized
DEBUG - 2014-01-20 02:24:06 --> Helper loaded: string_helper
DEBUG - 2014-01-20 02:24:06 --> Session routines successfully run
DEBUG - 2014-01-20 02:24:06 --> User Agent Class Initialized
DEBUG - 2014-01-20 02:24:06 --> Form Validation Class Initialized
DEBUG - 2014-01-20 02:24:06 --> Model Class Initialized
DEBUG - 2014-01-20 02:24:06 --> Model Class Initialized
DEBUG - 2014-01-20 02:24:06 --> Controller Class Initialized
DEBUG - 2014-01-20 02:24:06 --> Config Class Initialized
DEBUG - 2014-01-20 02:24:06 --> Hooks Class Initialized
DEBUG - 2014-01-20 02:24:06 --> Utf8 Class Initialized
DEBUG - 2014-01-20 02:24:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 02:24:06 --> URI Class Initialized
DEBUG - 2014-01-20 02:24:06 --> Router Class Initialized
DEBUG - 2014-01-20 02:24:06 --> No URI present. Default controller set.
DEBUG - 2014-01-20 02:24:06 --> Output Class Initialized
DEBUG - 2014-01-20 02:24:06 --> Security Class Initialized
DEBUG - 2014-01-20 02:24:06 --> Input Class Initialized
DEBUG - 2014-01-20 02:24:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 02:24:06 --> Language Class Initialized
DEBUG - 2014-01-20 02:24:06 --> Loader Class Initialized
DEBUG - 2014-01-20 02:24:06 --> Helper loaded: url_helper
DEBUG - 2014-01-20 02:24:06 --> Helper loaded: form_helper
DEBUG - 2014-01-20 02:24:06 --> Helper loaded: custom_helper
DEBUG - 2014-01-20 02:24:06 --> Database Driver Class Initialized
DEBUG - 2014-01-20 02:24:06 --> Session Class Initialized
DEBUG - 2014-01-20 02:24:06 --> Helper loaded: string_helper
DEBUG - 2014-01-20 02:24:06 --> Session routines successfully run
DEBUG - 2014-01-20 02:24:06 --> User Agent Class Initialized
DEBUG - 2014-01-20 02:24:06 --> Form Validation Class Initialized
DEBUG - 2014-01-20 02:24:06 --> Model Class Initialized
DEBUG - 2014-01-20 02:24:06 --> Model Class Initialized
DEBUG - 2014-01-20 02:24:06 --> Controller Class Initialized
DEBUG - 2014-01-20 02:24:06 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-20 02:24:06 --> File loaded: application/views/index.php
DEBUG - 2014-01-20 02:24:06 --> Final output sent to browser
DEBUG - 2014-01-20 02:24:06 --> Total execution time: 0.0461
DEBUG - 2014-01-20 07:58:53 --> Config Class Initialized
DEBUG - 2014-01-20 07:58:53 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:58:53 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:58:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:58:53 --> URI Class Initialized
DEBUG - 2014-01-20 07:58:53 --> Router Class Initialized
DEBUG - 2014-01-20 07:58:53 --> No URI present. Default controller set.
DEBUG - 2014-01-20 07:58:53 --> Output Class Initialized
DEBUG - 2014-01-20 07:58:53 --> Security Class Initialized
DEBUG - 2014-01-20 07:58:53 --> Input Class Initialized
DEBUG - 2014-01-20 07:58:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:58:53 --> Language Class Initialized
DEBUG - 2014-01-20 07:58:53 --> Loader Class Initialized
DEBUG - 2014-01-20 07:58:53 --> Helper loaded: url_helper
DEBUG - 2014-01-20 07:58:53 --> Helper loaded: form_helper
DEBUG - 2014-01-20 07:58:53 --> Helper loaded: custom_helper
DEBUG - 2014-01-20 07:58:53 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:58:53 --> Session Class Initialized
DEBUG - 2014-01-20 07:58:53 --> Helper loaded: string_helper
DEBUG - 2014-01-20 07:58:53 --> A session cookie was not found.
DEBUG - 2014-01-20 07:58:53 --> Session routines successfully run
DEBUG - 2014-01-20 07:58:53 --> User Agent Class Initialized
DEBUG - 2014-01-20 07:58:53 --> Form Validation Class Initialized
DEBUG - 2014-01-20 07:58:53 --> Model Class Initialized
DEBUG - 2014-01-20 07:58:53 --> Model Class Initialized
DEBUG - 2014-01-20 07:58:53 --> Controller Class Initialized
DEBUG - 2014-01-20 07:58:53 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-20 07:58:53 --> File loaded: application/views/index.php
DEBUG - 2014-01-20 07:58:53 --> Final output sent to browser
DEBUG - 2014-01-20 07:58:53 --> Total execution time: 0.0760
DEBUG - 2014-01-20 07:59:01 --> Config Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:59:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:59:01 --> URI Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Router Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Output Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Security Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Input Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:59:01 --> Language Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Loader Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Helper loaded: url_helper
DEBUG - 2014-01-20 07:59:01 --> Helper loaded: form_helper
DEBUG - 2014-01-20 07:59:01 --> Helper loaded: custom_helper
DEBUG - 2014-01-20 07:59:01 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Session Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Helper loaded: string_helper
DEBUG - 2014-01-20 07:59:01 --> Session routines successfully run
DEBUG - 2014-01-20 07:59:01 --> User Agent Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Form Validation Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Model Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Model Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Controller Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-20 07:59:01 --> Config Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:59:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:59:01 --> URI Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Router Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Output Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Security Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Input Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:59:01 --> Language Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Loader Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Helper loaded: url_helper
DEBUG - 2014-01-20 07:59:01 --> Helper loaded: form_helper
DEBUG - 2014-01-20 07:59:01 --> Helper loaded: custom_helper
DEBUG - 2014-01-20 07:59:01 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Session Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Helper loaded: string_helper
DEBUG - 2014-01-20 07:59:01 --> Session routines successfully run
DEBUG - 2014-01-20 07:59:01 --> User Agent Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Form Validation Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Model Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Model Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Controller Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Model Class Initialized
DEBUG - 2014-01-20 07:59:01 --> Model Class Initialized
DEBUG - 2014-01-20 07:59:01 --> File loaded: application/views/wniosek/lista.php
DEBUG - 2014-01-20 07:59:01 --> File loaded: application/views/user/aktualnosci.php
DEBUG - 2014-01-20 07:59:01 --> File loaded: application/views/index.php
DEBUG - 2014-01-20 07:59:01 --> Final output sent to browser
DEBUG - 2014-01-20 07:59:01 --> Total execution time: 0.3288
DEBUG - 2014-01-20 07:59:09 --> Config Class Initialized
DEBUG - 2014-01-20 07:59:09 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:59:09 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:59:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:59:09 --> URI Class Initialized
DEBUG - 2014-01-20 07:59:09 --> Router Class Initialized
DEBUG - 2014-01-20 07:59:09 --> Output Class Initialized
DEBUG - 2014-01-20 07:59:09 --> Security Class Initialized
DEBUG - 2014-01-20 07:59:09 --> Input Class Initialized
DEBUG - 2014-01-20 07:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:59:09 --> Language Class Initialized
DEBUG - 2014-01-20 07:59:09 --> Loader Class Initialized
DEBUG - 2014-01-20 07:59:09 --> Helper loaded: url_helper
DEBUG - 2014-01-20 07:59:09 --> Helper loaded: form_helper
DEBUG - 2014-01-20 07:59:09 --> Helper loaded: custom_helper
DEBUG - 2014-01-20 07:59:09 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:59:09 --> Session Class Initialized
DEBUG - 2014-01-20 07:59:09 --> Helper loaded: string_helper
DEBUG - 2014-01-20 07:59:09 --> Session routines successfully run
DEBUG - 2014-01-20 07:59:09 --> User Agent Class Initialized
DEBUG - 2014-01-20 07:59:09 --> Form Validation Class Initialized
DEBUG - 2014-01-20 07:59:09 --> Model Class Initialized
DEBUG - 2014-01-20 07:59:09 --> Model Class Initialized
DEBUG - 2014-01-20 07:59:09 --> Controller Class Initialized
DEBUG - 2014-01-20 07:59:09 --> Model Class Initialized
DEBUG - 2014-01-20 07:59:09 --> Model Class Initialized
DEBUG - 2014-01-20 07:59:09 --> File loaded: application/views/wniosek/szukaj.php
DEBUG - 2014-01-20 07:59:09 --> File loaded: application/views/wniosek/lista.php
DEBUG - 2014-01-20 07:59:09 --> File loaded: application/views/wniosek/zarzadzanie.php
DEBUG - 2014-01-20 07:59:09 --> File loaded: application/views/index.php
DEBUG - 2014-01-20 07:59:09 --> Final output sent to browser
DEBUG - 2014-01-20 07:59:09 --> Total execution time: 0.0679
DEBUG - 2014-01-20 07:59:11 --> Config Class Initialized
DEBUG - 2014-01-20 07:59:11 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:59:11 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:59:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:59:11 --> URI Class Initialized
DEBUG - 2014-01-20 07:59:11 --> Router Class Initialized
DEBUG - 2014-01-20 07:59:11 --> Output Class Initialized
DEBUG - 2014-01-20 07:59:11 --> Security Class Initialized
DEBUG - 2014-01-20 07:59:11 --> Input Class Initialized
DEBUG - 2014-01-20 07:59:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:59:11 --> Language Class Initialized
DEBUG - 2014-01-20 07:59:11 --> Loader Class Initialized
DEBUG - 2014-01-20 07:59:11 --> Helper loaded: url_helper
DEBUG - 2014-01-20 07:59:11 --> Helper loaded: form_helper
DEBUG - 2014-01-20 07:59:11 --> Helper loaded: custom_helper
DEBUG - 2014-01-20 07:59:11 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:59:11 --> Session Class Initialized
DEBUG - 2014-01-20 07:59:11 --> Helper loaded: string_helper
DEBUG - 2014-01-20 07:59:11 --> Session routines successfully run
DEBUG - 2014-01-20 07:59:11 --> User Agent Class Initialized
DEBUG - 2014-01-20 07:59:11 --> Form Validation Class Initialized
DEBUG - 2014-01-20 07:59:11 --> Model Class Initialized
DEBUG - 2014-01-20 07:59:11 --> Model Class Initialized
DEBUG - 2014-01-20 07:59:11 --> Controller Class Initialized
DEBUG - 2014-01-20 07:59:11 --> Model Class Initialized
DEBUG - 2014-01-20 07:59:11 --> File loaded: application/views/wplata/szukaj.php
DEBUG - 2014-01-20 07:59:11 --> File loaded: application/views/wplata/lista.php
DEBUG - 2014-01-20 07:59:11 --> File loaded: application/views/wplata/zarzadzanie.php
DEBUG - 2014-01-20 07:59:11 --> File loaded: application/views/index.php
DEBUG - 2014-01-20 07:59:11 --> Final output sent to browser
DEBUG - 2014-01-20 07:59:11 --> Total execution time: 0.0719
DEBUG - 2014-01-20 07:59:13 --> Config Class Initialized
DEBUG - 2014-01-20 07:59:13 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:59:13 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:59:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:59:13 --> URI Class Initialized
DEBUG - 2014-01-20 07:59:13 --> Router Class Initialized
DEBUG - 2014-01-20 07:59:13 --> Output Class Initialized
DEBUG - 2014-01-20 07:59:13 --> Security Class Initialized
DEBUG - 2014-01-20 07:59:13 --> Input Class Initialized
DEBUG - 2014-01-20 07:59:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:59:13 --> Language Class Initialized
DEBUG - 2014-01-20 07:59:13 --> Loader Class Initialized
DEBUG - 2014-01-20 07:59:13 --> Helper loaded: url_helper
DEBUG - 2014-01-20 07:59:13 --> Helper loaded: form_helper
DEBUG - 2014-01-20 07:59:13 --> Helper loaded: custom_helper
DEBUG - 2014-01-20 07:59:13 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:59:13 --> Session Class Initialized
DEBUG - 2014-01-20 07:59:13 --> Helper loaded: string_helper
DEBUG - 2014-01-20 07:59:13 --> Session routines successfully run
DEBUG - 2014-01-20 07:59:13 --> User Agent Class Initialized
DEBUG - 2014-01-20 07:59:13 --> Form Validation Class Initialized
DEBUG - 2014-01-20 07:59:13 --> Model Class Initialized
DEBUG - 2014-01-20 07:59:13 --> Model Class Initialized
DEBUG - 2014-01-20 07:59:13 --> Controller Class Initialized
DEBUG - 2014-01-20 07:59:13 --> Model Class Initialized
DEBUG - 2014-01-20 07:59:13 --> File loaded: application/views/wplata/szczegoly.php
DEBUG - 2014-01-20 07:59:13 --> File loaded: application/views/index.php
DEBUG - 2014-01-20 07:59:13 --> Final output sent to browser
DEBUG - 2014-01-20 07:59:13 --> Total execution time: 0.1138
DEBUG - 2014-01-20 07:59:16 --> Config Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:59:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:59:16 --> URI Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Router Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Output Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Security Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Input Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:59:16 --> Language Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Loader Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Helper loaded: url_helper
DEBUG - 2014-01-20 07:59:16 --> Helper loaded: form_helper
DEBUG - 2014-01-20 07:59:16 --> Helper loaded: custom_helper
DEBUG - 2014-01-20 07:59:16 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Session Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Helper loaded: string_helper
DEBUG - 2014-01-20 07:59:16 --> Session routines successfully run
DEBUG - 2014-01-20 07:59:16 --> User Agent Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Form Validation Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Model Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Model Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Controller Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Model Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Model Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Model Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Config Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:59:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:59:16 --> URI Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Router Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Output Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Security Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Input Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:59:16 --> Language Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Loader Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Helper loaded: url_helper
DEBUG - 2014-01-20 07:59:16 --> Helper loaded: form_helper
DEBUG - 2014-01-20 07:59:16 --> Helper loaded: custom_helper
DEBUG - 2014-01-20 07:59:16 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Session Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Helper loaded: string_helper
DEBUG - 2014-01-20 07:59:16 --> A session cookie was not found.
DEBUG - 2014-01-20 07:59:16 --> Session routines successfully run
DEBUG - 2014-01-20 07:59:16 --> User Agent Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Form Validation Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Model Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Model Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Controller Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Model Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Model Class Initialized
DEBUG - 2014-01-20 07:59:16 --> Model Class Initialized
DEBUG - 2014-01-20 07:59:16 --> File loaded: application/views/formularz/planPodzialu.php
DEBUG - 2014-01-20 07:59:16 --> File loaded: application/views/formularz/layoutWewnetrzny.php
DEBUG - 2014-01-20 07:59:16 --> Final output sent to browser
DEBUG - 2014-01-20 07:59:16 --> Total execution time: 0.1503
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: BODY C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: BODY>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined offset: -1 C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1150
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: DIV C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: ID>>CONTAINER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1003
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: DIV>>ID>>CONTAINER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: DIV C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: ID>>CONTAINER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1003
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: DIV>>ID>>CONTAINER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: DIV C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: ID>>HEADER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1003
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: DIV>>ID>>HEADER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: DIV C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: ID>>HEADER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1003
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: DIV>>ID>>HEADER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: direction C:\wamp\www\Windykator1\MPDF57\mpdf.php 18502
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: direction C:\wamp\www\Windykator1\MPDF57\mpdf.php 18502
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: DIV C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: CLASS>>CONTENT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CONTENT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: CLASS>>CONTENT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CONTENT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: DIV>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: DIV C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: DIV>>ID>>PLANPODZIALU C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: ID>>PLANPODZIALU C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1003
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: DIV>>ID>>PLANPODZIALU C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P>>CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P>>CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P>>CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P>>CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P>>CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TABLE C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TABLE>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TABLE C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TABLE>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TH C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TH>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:16 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: TR C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: TR>>CLASS>>CENTER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: TR>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: CLASS>>NO_BORDER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: TD>>CLASS>>NO_BORDER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: CLASS>>NO_BORDER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: TD>>CLASS>>NO_BORDER C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: TD C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: TD>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined variable: pre C:\wamp\www\Windykator1\MPDF57\mpdf.php 12604
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined variable: post C:\wamp\www\Windykator1\MPDF57\mpdf.php 12604
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined variable: prelength C:\wamp\www\Windykator1\MPDF57\mpdf.php 12604
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22877
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22888
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 22897
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined offset: 0 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined offset: 4 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined offset: 5 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined offset: 6 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined offset: 7 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined offset: 8 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined offset: 9 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined offset: 10 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined offset: 11 C:\wamp\www\Windykator1\MPDF57\mpdf.php 26572
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:17 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 1 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 2 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Uninitialized string offset: 3 C:\wamp\www\Windykator1\MPDF57\mpdf.php 2664
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: P>>CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: P>>CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: z-index C:\wamp\www\Windykator1\MPDF57\mpdf.php 2464
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: z-index C:\wamp\www\Windykator1\MPDF57\mpdf.php 2464
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: z-index C:\wamp\www\Windykator1\MPDF57\mpdf.php 2464
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: OL C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: OL>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: OL C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: OL>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: OL C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: OL>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: OL C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: OL>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 969
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: LI>>CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: LI>>CLASS>>RIGHT C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1007
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:18 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:19 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:19 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5889
ERROR - 2014-01-20 07:59:19 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5903
ERROR - 2014-01-20 07:59:19 --> Severity: Notice  --> Undefined index: hyphens C:\wamp\www\Windykator1\MPDF57\mpdf.php 5908
ERROR - 2014-01-20 07:59:19 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:19 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:19 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:19 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:19 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:19 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:19 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:19 --> Severity: Notice  --> Undefined index: P C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:19 --> Severity: Notice  --> Undefined index: P>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:19 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:19 --> Severity: Notice  --> Undefined index: OL C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:19 --> Severity: Notice  --> Undefined index: OL>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:19 --> Severity: Notice  --> Undefined index: OL C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:19 --> Severity: Notice  --> Undefined index: OL>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:19 --> Severity: Notice  --> Undefined index: LI C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 966
ERROR - 2014-01-20 07:59:19 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:19 --> Severity: Notice  --> Undefined index: LI>>ID>> C:\wamp\www\Windykator1\MPDF57\classes\cssmgr.php 1011
ERROR - 2014-01-20 07:59:19 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:19 --> Severity: Notice  --> Undefined index: outline-s C:\wamp\www\Windykator1\MPDF57\mpdf.php 3892
ERROR - 2014-01-20 07:59:19 --> Severity: Notice  --> Undefined index: direction C:\wamp\www\Windykator1\MPDF57\mpdf.php 18502
ERROR - 2014-01-20 07:59:19 --> Severity: Notice  --> Undefined index: direction C:\wamp\www\Windykator1\MPDF57\mpdf.php 18502
ERROR - 2014-01-20 07:59:19 --> Severity: Notice  --> Undefined index: direction C:\wamp\www\Windykator1\MPDF57\mpdf.php 18502
ERROR - 2014-01-20 07:59:19 --> Severity: Notice  --> Undefined property: mPDF::$hasOC C:\wamp\www\Windykator1\MPDF57\mpdf.php 27505
ERROR - 2014-01-20 07:59:19 --> Severity: Notice  --> Undefined property: mPDF::$hasOC C:\wamp\www\Windykator1\MPDF57\mpdf.php 27608
ERROR - 2014-01-20 07:59:19 --> Severity: Notice  --> Undefined property: mPDF::$hasOC C:\wamp\www\Windykator1\MPDF57\mpdf.php 9158
DEBUG - 2014-01-20 07:59:19 --> Final output sent to browser
DEBUG - 2014-01-20 07:59:19 --> Total execution time: 3.2226
DEBUG - 2014-01-20 07:59:30 --> Config Class Initialized
DEBUG - 2014-01-20 07:59:30 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:59:30 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:59:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:59:30 --> URI Class Initialized
DEBUG - 2014-01-20 07:59:30 --> Router Class Initialized
DEBUG - 2014-01-20 07:59:30 --> Output Class Initialized
DEBUG - 2014-01-20 07:59:30 --> Security Class Initialized
DEBUG - 2014-01-20 07:59:30 --> Input Class Initialized
DEBUG - 2014-01-20 07:59:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:59:30 --> Language Class Initialized
DEBUG - 2014-01-20 07:59:30 --> Loader Class Initialized
DEBUG - 2014-01-20 07:59:30 --> Helper loaded: url_helper
DEBUG - 2014-01-20 07:59:30 --> Helper loaded: form_helper
DEBUG - 2014-01-20 07:59:30 --> Helper loaded: custom_helper
DEBUG - 2014-01-20 07:59:30 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:59:30 --> Session Class Initialized
DEBUG - 2014-01-20 07:59:30 --> Helper loaded: string_helper
DEBUG - 2014-01-20 07:59:30 --> Session routines successfully run
DEBUG - 2014-01-20 07:59:30 --> User Agent Class Initialized
DEBUG - 2014-01-20 07:59:30 --> Form Validation Class Initialized
DEBUG - 2014-01-20 07:59:30 --> Model Class Initialized
DEBUG - 2014-01-20 07:59:30 --> Model Class Initialized
DEBUG - 2014-01-20 07:59:30 --> Controller Class Initialized
DEBUG - 2014-01-20 07:59:30 --> Config Class Initialized
DEBUG - 2014-01-20 07:59:30 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:59:30 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:59:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:59:30 --> URI Class Initialized
DEBUG - 2014-01-20 07:59:30 --> Router Class Initialized
DEBUG - 2014-01-20 07:59:30 --> No URI present. Default controller set.
DEBUG - 2014-01-20 07:59:30 --> Output Class Initialized
DEBUG - 2014-01-20 07:59:30 --> Security Class Initialized
DEBUG - 2014-01-20 07:59:30 --> Input Class Initialized
DEBUG - 2014-01-20 07:59:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:59:30 --> Language Class Initialized
DEBUG - 2014-01-20 07:59:30 --> Loader Class Initialized
DEBUG - 2014-01-20 07:59:30 --> Helper loaded: url_helper
DEBUG - 2014-01-20 07:59:30 --> Helper loaded: form_helper
DEBUG - 2014-01-20 07:59:30 --> Helper loaded: custom_helper
DEBUG - 2014-01-20 07:59:30 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:59:30 --> Session Class Initialized
DEBUG - 2014-01-20 07:59:30 --> Helper loaded: string_helper
DEBUG - 2014-01-20 07:59:30 --> Session routines successfully run
DEBUG - 2014-01-20 07:59:30 --> User Agent Class Initialized
DEBUG - 2014-01-20 07:59:31 --> Form Validation Class Initialized
DEBUG - 2014-01-20 07:59:31 --> Model Class Initialized
DEBUG - 2014-01-20 07:59:31 --> Model Class Initialized
DEBUG - 2014-01-20 07:59:31 --> Controller Class Initialized
DEBUG - 2014-01-20 07:59:31 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-20 07:59:31 --> File loaded: application/views/index.php
DEBUG - 2014-01-20 07:59:31 --> Final output sent to browser
DEBUG - 2014-01-20 07:59:31 --> Total execution time: 0.0506
