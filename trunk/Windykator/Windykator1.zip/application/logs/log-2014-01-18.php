<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-01-18 08:56:44 --> Config Class Initialized
DEBUG - 2014-01-18 08:56:44 --> Hooks Class Initialized
DEBUG - 2014-01-18 08:56:44 --> Utf8 Class Initialized
DEBUG - 2014-01-18 08:56:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 08:56:44 --> URI Class Initialized
DEBUG - 2014-01-18 08:56:44 --> Router Class Initialized
DEBUG - 2014-01-18 08:56:44 --> Output Class Initialized
DEBUG - 2014-01-18 08:56:44 --> Security Class Initialized
DEBUG - 2014-01-18 08:56:44 --> Input Class Initialized
DEBUG - 2014-01-18 08:56:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 08:56:44 --> Language Class Initialized
DEBUG - 2014-01-18 08:56:44 --> Loader Class Initialized
DEBUG - 2014-01-18 08:56:44 --> Helper loaded: url_helper
DEBUG - 2014-01-18 08:56:44 --> Helper loaded: form_helper
DEBUG - 2014-01-18 08:56:44 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 08:56:44 --> Database Driver Class Initialized
DEBUG - 2014-01-18 08:56:44 --> Session Class Initialized
DEBUG - 2014-01-18 08:56:44 --> Helper loaded: string_helper
DEBUG - 2014-01-18 08:56:44 --> Session routines successfully run
DEBUG - 2014-01-18 08:56:44 --> User Agent Class Initialized
DEBUG - 2014-01-18 08:56:44 --> Form Validation Class Initialized
DEBUG - 2014-01-18 08:56:44 --> Model Class Initialized
DEBUG - 2014-01-18 08:56:44 --> Model Class Initialized
DEBUG - 2014-01-18 08:56:44 --> Controller Class Initialized
DEBUG - 2014-01-18 08:56:44 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 08:56:44 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 08:56:44 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 08:56:44 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 08:56:44 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 08:56:44 --> Final output sent to browser
DEBUG - 2014-01-18 08:56:44 --> Total execution time: 0.1374
DEBUG - 2014-01-18 08:56:47 --> Config Class Initialized
DEBUG - 2014-01-18 08:56:47 --> Hooks Class Initialized
DEBUG - 2014-01-18 08:56:47 --> Utf8 Class Initialized
DEBUG - 2014-01-18 08:56:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 08:56:47 --> URI Class Initialized
DEBUG - 2014-01-18 08:56:47 --> Router Class Initialized
DEBUG - 2014-01-18 08:56:47 --> Output Class Initialized
DEBUG - 2014-01-18 08:56:47 --> Security Class Initialized
DEBUG - 2014-01-18 08:56:47 --> Input Class Initialized
DEBUG - 2014-01-18 08:56:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 08:56:47 --> Language Class Initialized
DEBUG - 2014-01-18 08:56:47 --> Loader Class Initialized
DEBUG - 2014-01-18 08:56:47 --> Helper loaded: url_helper
DEBUG - 2014-01-18 08:56:47 --> Helper loaded: form_helper
DEBUG - 2014-01-18 08:56:47 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 08:56:47 --> Database Driver Class Initialized
DEBUG - 2014-01-18 08:56:47 --> Session Class Initialized
DEBUG - 2014-01-18 08:56:47 --> Helper loaded: string_helper
DEBUG - 2014-01-18 08:56:47 --> Session routines successfully run
DEBUG - 2014-01-18 08:56:47 --> User Agent Class Initialized
DEBUG - 2014-01-18 08:56:47 --> Form Validation Class Initialized
DEBUG - 2014-01-18 08:56:47 --> Model Class Initialized
DEBUG - 2014-01-18 08:56:47 --> Model Class Initialized
DEBUG - 2014-01-18 08:56:47 --> Controller Class Initialized
DEBUG - 2014-01-18 08:56:47 --> Model Class Initialized
DEBUG - 2014-01-18 08:56:47 --> File loaded: application/views/user/edytuj.php
DEBUG - 2014-01-18 08:56:47 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 08:56:47 --> Final output sent to browser
DEBUG - 2014-01-18 08:56:47 --> Total execution time: 0.0735
DEBUG - 2014-01-18 08:56:50 --> Config Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Hooks Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Utf8 Class Initialized
DEBUG - 2014-01-18 08:56:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 08:56:50 --> URI Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Router Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Output Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Security Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Input Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 08:56:50 --> Language Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Loader Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Helper loaded: url_helper
DEBUG - 2014-01-18 08:56:50 --> Helper loaded: form_helper
DEBUG - 2014-01-18 08:56:50 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 08:56:50 --> Database Driver Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Session Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Helper loaded: string_helper
DEBUG - 2014-01-18 08:56:50 --> Session routines successfully run
DEBUG - 2014-01-18 08:56:50 --> User Agent Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Form Validation Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Model Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Model Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Controller Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Model Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 08:56:50 --> Config Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Hooks Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Utf8 Class Initialized
DEBUG - 2014-01-18 08:56:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 08:56:50 --> URI Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Router Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Output Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Security Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Input Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 08:56:50 --> Language Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Loader Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Helper loaded: url_helper
DEBUG - 2014-01-18 08:56:50 --> Helper loaded: form_helper
DEBUG - 2014-01-18 08:56:50 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 08:56:50 --> Database Driver Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Session Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Helper loaded: string_helper
DEBUG - 2014-01-18 08:56:50 --> Session routines successfully run
DEBUG - 2014-01-18 08:56:50 --> User Agent Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Form Validation Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Model Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Model Class Initialized
DEBUG - 2014-01-18 08:56:50 --> Controller Class Initialized
DEBUG - 2014-01-18 08:56:50 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 08:56:50 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 08:56:50 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 08:56:50 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 08:56:50 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 08:56:50 --> Final output sent to browser
DEBUG - 2014-01-18 08:56:50 --> Total execution time: 0.0518
DEBUG - 2014-01-18 08:57:02 --> Config Class Initialized
DEBUG - 2014-01-18 08:57:02 --> Hooks Class Initialized
DEBUG - 2014-01-18 08:57:02 --> Utf8 Class Initialized
DEBUG - 2014-01-18 08:57:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 08:57:02 --> URI Class Initialized
DEBUG - 2014-01-18 08:57:02 --> Router Class Initialized
DEBUG - 2014-01-18 08:57:02 --> Output Class Initialized
DEBUG - 2014-01-18 08:57:02 --> Security Class Initialized
DEBUG - 2014-01-18 08:57:02 --> Input Class Initialized
DEBUG - 2014-01-18 08:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 08:57:02 --> Language Class Initialized
DEBUG - 2014-01-18 08:57:02 --> Loader Class Initialized
DEBUG - 2014-01-18 08:57:02 --> Helper loaded: url_helper
DEBUG - 2014-01-18 08:57:02 --> Helper loaded: form_helper
DEBUG - 2014-01-18 08:57:02 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 08:57:02 --> Database Driver Class Initialized
DEBUG - 2014-01-18 08:57:02 --> Session Class Initialized
DEBUG - 2014-01-18 08:57:02 --> Helper loaded: string_helper
DEBUG - 2014-01-18 08:57:02 --> Session routines successfully run
DEBUG - 2014-01-18 08:57:02 --> User Agent Class Initialized
DEBUG - 2014-01-18 08:57:02 --> Form Validation Class Initialized
DEBUG - 2014-01-18 08:57:02 --> Model Class Initialized
DEBUG - 2014-01-18 08:57:02 --> Model Class Initialized
DEBUG - 2014-01-18 08:57:02 --> Controller Class Initialized
DEBUG - 2014-01-18 08:57:02 --> Model Class Initialized
DEBUG - 2014-01-18 08:57:02 --> File loaded: application/views/user/edytuj.php
DEBUG - 2014-01-18 08:57:02 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 08:57:02 --> Final output sent to browser
DEBUG - 2014-01-18 08:57:02 --> Total execution time: 0.0624
DEBUG - 2014-01-18 08:57:07 --> Config Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Hooks Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Utf8 Class Initialized
DEBUG - 2014-01-18 08:57:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 08:57:07 --> URI Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Router Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Output Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Security Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Input Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 08:57:07 --> Language Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Loader Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Helper loaded: url_helper
DEBUG - 2014-01-18 08:57:07 --> Helper loaded: form_helper
DEBUG - 2014-01-18 08:57:07 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 08:57:07 --> Database Driver Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Session Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Helper loaded: string_helper
DEBUG - 2014-01-18 08:57:07 --> Session routines successfully run
DEBUG - 2014-01-18 08:57:07 --> User Agent Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Form Validation Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Model Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Model Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Controller Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Model Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 08:57:07 --> Config Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Hooks Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Utf8 Class Initialized
DEBUG - 2014-01-18 08:57:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 08:57:07 --> URI Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Router Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Output Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Security Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Input Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 08:57:07 --> Language Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Loader Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Helper loaded: url_helper
DEBUG - 2014-01-18 08:57:07 --> Helper loaded: form_helper
DEBUG - 2014-01-18 08:57:07 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 08:57:07 --> Database Driver Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Session Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Helper loaded: string_helper
DEBUG - 2014-01-18 08:57:07 --> Session routines successfully run
DEBUG - 2014-01-18 08:57:07 --> User Agent Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Form Validation Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Model Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Model Class Initialized
DEBUG - 2014-01-18 08:57:07 --> Controller Class Initialized
DEBUG - 2014-01-18 08:57:07 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 08:57:07 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 08:57:07 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 08:57:07 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 08:57:07 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 08:57:07 --> Final output sent to browser
DEBUG - 2014-01-18 08:57:07 --> Total execution time: 0.0560
DEBUG - 2014-01-18 08:57:22 --> Config Class Initialized
DEBUG - 2014-01-18 08:57:22 --> Hooks Class Initialized
DEBUG - 2014-01-18 08:57:22 --> Utf8 Class Initialized
DEBUG - 2014-01-18 08:57:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 08:57:22 --> URI Class Initialized
DEBUG - 2014-01-18 08:57:22 --> Router Class Initialized
DEBUG - 2014-01-18 08:57:22 --> Output Class Initialized
DEBUG - 2014-01-18 08:57:22 --> Security Class Initialized
DEBUG - 2014-01-18 08:57:22 --> Input Class Initialized
DEBUG - 2014-01-18 08:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 08:57:22 --> Language Class Initialized
DEBUG - 2014-01-18 08:57:22 --> Loader Class Initialized
DEBUG - 2014-01-18 08:57:22 --> Helper loaded: url_helper
DEBUG - 2014-01-18 08:57:22 --> Helper loaded: form_helper
DEBUG - 2014-01-18 08:57:22 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 08:57:22 --> Database Driver Class Initialized
DEBUG - 2014-01-18 08:57:22 --> Session Class Initialized
DEBUG - 2014-01-18 08:57:22 --> Helper loaded: string_helper
DEBUG - 2014-01-18 08:57:22 --> Session routines successfully run
DEBUG - 2014-01-18 08:57:22 --> User Agent Class Initialized
DEBUG - 2014-01-18 08:57:22 --> Form Validation Class Initialized
DEBUG - 2014-01-18 08:57:22 --> Model Class Initialized
DEBUG - 2014-01-18 08:57:22 --> Model Class Initialized
DEBUG - 2014-01-18 08:57:22 --> Controller Class Initialized
DEBUG - 2014-01-18 08:57:22 --> Model Class Initialized
DEBUG - 2014-01-18 08:57:22 --> File loaded: application/views/user/dodaj.php
DEBUG - 2014-01-18 08:57:22 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 08:57:22 --> Final output sent to browser
DEBUG - 2014-01-18 08:57:22 --> Total execution time: 0.0711
DEBUG - 2014-01-18 08:58:08 --> Config Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Hooks Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Utf8 Class Initialized
DEBUG - 2014-01-18 08:58:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 08:58:08 --> URI Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Router Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Output Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Security Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Input Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 08:58:08 --> Language Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Loader Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Helper loaded: url_helper
DEBUG - 2014-01-18 08:58:08 --> Helper loaded: form_helper
DEBUG - 2014-01-18 08:58:08 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 08:58:08 --> Database Driver Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Session Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Helper loaded: string_helper
DEBUG - 2014-01-18 08:58:08 --> Session routines successfully run
DEBUG - 2014-01-18 08:58:08 --> User Agent Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Form Validation Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Model Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Model Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Controller Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Model Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 08:58:08 --> Config Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Hooks Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Utf8 Class Initialized
DEBUG - 2014-01-18 08:58:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 08:58:08 --> URI Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Router Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Output Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Security Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Input Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 08:58:08 --> Language Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Loader Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Helper loaded: url_helper
DEBUG - 2014-01-18 08:58:08 --> Helper loaded: form_helper
DEBUG - 2014-01-18 08:58:08 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 08:58:08 --> Database Driver Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Session Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Helper loaded: string_helper
DEBUG - 2014-01-18 08:58:08 --> Session routines successfully run
DEBUG - 2014-01-18 08:58:08 --> User Agent Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Form Validation Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Model Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Model Class Initialized
DEBUG - 2014-01-18 08:58:08 --> Controller Class Initialized
DEBUG - 2014-01-18 08:58:09 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 08:58:09 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 08:58:09 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 08:58:09 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 08:58:09 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 08:58:09 --> Final output sent to browser
DEBUG - 2014-01-18 08:58:09 --> Total execution time: 0.0547
DEBUG - 2014-01-18 08:58:53 --> Config Class Initialized
DEBUG - 2014-01-18 08:58:53 --> Hooks Class Initialized
DEBUG - 2014-01-18 08:58:53 --> Utf8 Class Initialized
DEBUG - 2014-01-18 08:58:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 08:58:53 --> URI Class Initialized
DEBUG - 2014-01-18 08:58:53 --> Router Class Initialized
DEBUG - 2014-01-18 08:58:53 --> Output Class Initialized
DEBUG - 2014-01-18 08:58:53 --> Security Class Initialized
DEBUG - 2014-01-18 08:58:53 --> Input Class Initialized
DEBUG - 2014-01-18 08:58:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 08:58:53 --> Language Class Initialized
DEBUG - 2014-01-18 08:58:53 --> Loader Class Initialized
DEBUG - 2014-01-18 08:58:53 --> Helper loaded: url_helper
DEBUG - 2014-01-18 08:58:53 --> Helper loaded: form_helper
DEBUG - 2014-01-18 08:58:53 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 08:58:53 --> Database Driver Class Initialized
DEBUG - 2014-01-18 08:58:53 --> Session Class Initialized
DEBUG - 2014-01-18 08:58:53 --> Helper loaded: string_helper
DEBUG - 2014-01-18 08:58:53 --> Session routines successfully run
DEBUG - 2014-01-18 08:58:53 --> User Agent Class Initialized
DEBUG - 2014-01-18 08:58:53 --> Form Validation Class Initialized
DEBUG - 2014-01-18 08:58:53 --> Model Class Initialized
DEBUG - 2014-01-18 08:58:53 --> Model Class Initialized
DEBUG - 2014-01-18 08:58:53 --> Controller Class Initialized
DEBUG - 2014-01-18 08:58:53 --> File loaded: application/views/user/podglad.php
DEBUG - 2014-01-18 08:58:53 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 08:58:53 --> Final output sent to browser
DEBUG - 2014-01-18 08:58:53 --> Total execution time: 0.0605
DEBUG - 2014-01-18 09:05:05 --> Config Class Initialized
DEBUG - 2014-01-18 09:05:05 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:05:05 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:05:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:05:05 --> URI Class Initialized
DEBUG - 2014-01-18 09:05:05 --> Router Class Initialized
DEBUG - 2014-01-18 09:05:06 --> Output Class Initialized
DEBUG - 2014-01-18 09:05:06 --> Security Class Initialized
DEBUG - 2014-01-18 09:05:06 --> Input Class Initialized
DEBUG - 2014-01-18 09:05:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:05:06 --> Language Class Initialized
DEBUG - 2014-01-18 09:05:06 --> Loader Class Initialized
DEBUG - 2014-01-18 09:05:06 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:05:06 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:05:06 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:05:06 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:05:06 --> Session Class Initialized
DEBUG - 2014-01-18 09:05:06 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:05:06 --> Session routines successfully run
DEBUG - 2014-01-18 09:05:06 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:05:06 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:05:06 --> Model Class Initialized
DEBUG - 2014-01-18 09:05:06 --> Model Class Initialized
DEBUG - 2014-01-18 09:05:06 --> Controller Class Initialized
DEBUG - 2014-01-18 09:05:06 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 09:05:06 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 09:05:06 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 09:05:06 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 09:05:06 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 09:05:06 --> Final output sent to browser
DEBUG - 2014-01-18 09:05:06 --> Total execution time: 0.0613
DEBUG - 2014-01-18 09:08:46 --> Config Class Initialized
DEBUG - 2014-01-18 09:08:46 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:08:46 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:08:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:08:46 --> URI Class Initialized
DEBUG - 2014-01-18 09:08:46 --> Router Class Initialized
DEBUG - 2014-01-18 09:08:46 --> Output Class Initialized
DEBUG - 2014-01-18 09:08:46 --> Security Class Initialized
DEBUG - 2014-01-18 09:08:46 --> Input Class Initialized
DEBUG - 2014-01-18 09:08:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:08:46 --> Language Class Initialized
DEBUG - 2014-01-18 09:08:46 --> Loader Class Initialized
DEBUG - 2014-01-18 09:08:46 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:08:46 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:08:46 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:08:47 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:08:47 --> Session Class Initialized
DEBUG - 2014-01-18 09:08:47 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:08:47 --> Session routines successfully run
DEBUG - 2014-01-18 09:08:47 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:08:47 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:08:47 --> Model Class Initialized
DEBUG - 2014-01-18 09:08:47 --> Model Class Initialized
DEBUG - 2014-01-18 09:08:47 --> Controller Class Initialized
DEBUG - 2014-01-18 09:08:47 --> Config Class Initialized
DEBUG - 2014-01-18 09:08:47 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:08:47 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:08:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:08:47 --> URI Class Initialized
DEBUG - 2014-01-18 09:08:47 --> Router Class Initialized
DEBUG - 2014-01-18 09:08:47 --> No URI present. Default controller set.
DEBUG - 2014-01-18 09:08:47 --> Output Class Initialized
DEBUG - 2014-01-18 09:08:47 --> Security Class Initialized
DEBUG - 2014-01-18 09:08:47 --> Input Class Initialized
DEBUG - 2014-01-18 09:08:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:08:47 --> Language Class Initialized
DEBUG - 2014-01-18 09:08:47 --> Loader Class Initialized
DEBUG - 2014-01-18 09:08:47 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:08:47 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:08:47 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:08:47 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:08:47 --> Session Class Initialized
DEBUG - 2014-01-18 09:08:47 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:08:47 --> Session routines successfully run
DEBUG - 2014-01-18 09:08:47 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:08:47 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:08:47 --> Model Class Initialized
DEBUG - 2014-01-18 09:08:47 --> Model Class Initialized
DEBUG - 2014-01-18 09:08:47 --> Controller Class Initialized
DEBUG - 2014-01-18 09:08:47 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 09:08:47 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 09:08:47 --> Final output sent to browser
DEBUG - 2014-01-18 09:08:47 --> Total execution time: 0.0573
DEBUG - 2014-01-18 09:08:51 --> Config Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:08:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:08:51 --> URI Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Router Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Output Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Security Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Input Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:08:51 --> Language Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Loader Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:08:51 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:08:51 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:08:51 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Session Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:08:51 --> Session routines successfully run
DEBUG - 2014-01-18 09:08:51 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Model Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Model Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Controller Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 09:08:51 --> Config Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:08:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:08:51 --> URI Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Router Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Output Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Security Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Input Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:08:51 --> Language Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Loader Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:08:51 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:08:51 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:08:51 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Session Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:08:51 --> Session routines successfully run
DEBUG - 2014-01-18 09:08:51 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Model Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Model Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Controller Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Model Class Initialized
DEBUG - 2014-01-18 09:08:51 --> Model Class Initialized
DEBUG - 2014-01-18 09:08:51 --> File loaded: application/views/wniosek/lista.php
DEBUG - 2014-01-18 09:08:51 --> File loaded: application/views/user/aktualnosci.php
DEBUG - 2014-01-18 09:08:51 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 09:08:51 --> Final output sent to browser
DEBUG - 2014-01-18 09:08:51 --> Total execution time: 0.0602
DEBUG - 2014-01-18 09:08:53 --> Config Class Initialized
DEBUG - 2014-01-18 09:08:53 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:08:53 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:08:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:08:53 --> URI Class Initialized
DEBUG - 2014-01-18 09:08:53 --> Router Class Initialized
DEBUG - 2014-01-18 09:08:53 --> Output Class Initialized
DEBUG - 2014-01-18 09:08:53 --> Security Class Initialized
DEBUG - 2014-01-18 09:08:53 --> Input Class Initialized
DEBUG - 2014-01-18 09:08:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:08:53 --> Language Class Initialized
DEBUG - 2014-01-18 09:08:53 --> Loader Class Initialized
DEBUG - 2014-01-18 09:08:53 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:08:53 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:08:53 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:08:53 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:08:53 --> Session Class Initialized
DEBUG - 2014-01-18 09:08:53 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:08:53 --> Session routines successfully run
DEBUG - 2014-01-18 09:08:53 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:08:53 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:08:53 --> Model Class Initialized
DEBUG - 2014-01-18 09:08:53 --> Model Class Initialized
DEBUG - 2014-01-18 09:08:53 --> Controller Class Initialized
DEBUG - 2014-01-18 09:08:53 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 09:08:53 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 09:08:53 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 09:08:53 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 09:08:53 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 09:08:53 --> Final output sent to browser
DEBUG - 2014-01-18 09:08:53 --> Total execution time: 0.0743
DEBUG - 2014-01-18 09:09:08 --> Config Class Initialized
DEBUG - 2014-01-18 09:09:08 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:09:08 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:09:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:09:08 --> URI Class Initialized
DEBUG - 2014-01-18 09:09:08 --> Router Class Initialized
DEBUG - 2014-01-18 09:09:08 --> Output Class Initialized
DEBUG - 2014-01-18 09:09:08 --> Security Class Initialized
DEBUG - 2014-01-18 09:09:08 --> Input Class Initialized
DEBUG - 2014-01-18 09:09:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:09:08 --> Language Class Initialized
DEBUG - 2014-01-18 09:09:08 --> Loader Class Initialized
DEBUG - 2014-01-18 09:09:08 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:09:08 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:09:08 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:09:08 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:09:08 --> Session Class Initialized
DEBUG - 2014-01-18 09:09:08 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:09:08 --> Session routines successfully run
DEBUG - 2014-01-18 09:09:08 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:09:08 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:09:08 --> Model Class Initialized
DEBUG - 2014-01-18 09:09:08 --> Model Class Initialized
DEBUG - 2014-01-18 09:09:08 --> Controller Class Initialized
DEBUG - 2014-01-18 09:09:08 --> Model Class Initialized
DEBUG - 2014-01-18 09:09:08 --> File loaded: application/views/user/dodaj.php
DEBUG - 2014-01-18 09:09:08 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 09:09:08 --> Final output sent to browser
DEBUG - 2014-01-18 09:09:08 --> Total execution time: 0.0665
DEBUG - 2014-01-18 09:09:40 --> Config Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:09:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:09:40 --> URI Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Router Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Output Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Security Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Input Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:09:40 --> Language Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Loader Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:09:40 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:09:40 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:09:40 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Session Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:09:40 --> Session routines successfully run
DEBUG - 2014-01-18 09:09:40 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Model Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Model Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Controller Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Model Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 09:09:40 --> Config Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:09:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:09:40 --> URI Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Router Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Output Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Security Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Input Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:09:40 --> Language Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Loader Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:09:40 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:09:40 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:09:40 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Session Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:09:40 --> Session routines successfully run
DEBUG - 2014-01-18 09:09:40 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Model Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Model Class Initialized
DEBUG - 2014-01-18 09:09:40 --> Controller Class Initialized
DEBUG - 2014-01-18 09:09:40 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 09:09:40 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 09:09:40 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 09:09:40 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 09:09:40 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 09:09:40 --> Final output sent to browser
DEBUG - 2014-01-18 09:09:40 --> Total execution time: 0.0580
DEBUG - 2014-01-18 09:11:32 --> Config Class Initialized
DEBUG - 2014-01-18 09:11:32 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:11:32 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:11:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:11:32 --> URI Class Initialized
DEBUG - 2014-01-18 09:11:32 --> Router Class Initialized
DEBUG - 2014-01-18 09:11:32 --> Output Class Initialized
DEBUG - 2014-01-18 09:11:32 --> Security Class Initialized
DEBUG - 2014-01-18 09:11:32 --> Input Class Initialized
DEBUG - 2014-01-18 09:11:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:11:32 --> Language Class Initialized
DEBUG - 2014-01-18 09:11:32 --> Loader Class Initialized
DEBUG - 2014-01-18 09:11:32 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:11:32 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:11:32 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:11:32 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:11:32 --> Session Class Initialized
DEBUG - 2014-01-18 09:11:32 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:11:32 --> Session routines successfully run
DEBUG - 2014-01-18 09:11:32 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:11:32 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:11:32 --> Model Class Initialized
DEBUG - 2014-01-18 09:11:32 --> Model Class Initialized
DEBUG - 2014-01-18 09:11:32 --> Controller Class Initialized
DEBUG - 2014-01-18 09:11:32 --> Model Class Initialized
DEBUG - 2014-01-18 09:11:32 --> File loaded: application/views/user/edytuj.php
DEBUG - 2014-01-18 09:11:32 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 09:11:32 --> Final output sent to browser
DEBUG - 2014-01-18 09:11:32 --> Total execution time: 0.0606
DEBUG - 2014-01-18 09:11:43 --> Config Class Initialized
DEBUG - 2014-01-18 09:11:43 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:11:43 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:11:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:11:43 --> URI Class Initialized
DEBUG - 2014-01-18 09:11:43 --> Router Class Initialized
DEBUG - 2014-01-18 09:11:43 --> Output Class Initialized
DEBUG - 2014-01-18 09:11:43 --> Security Class Initialized
DEBUG - 2014-01-18 09:11:43 --> Input Class Initialized
DEBUG - 2014-01-18 09:11:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:11:43 --> Language Class Initialized
DEBUG - 2014-01-18 09:11:43 --> Loader Class Initialized
DEBUG - 2014-01-18 09:11:43 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:11:43 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:11:43 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:11:43 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:11:43 --> Session Class Initialized
DEBUG - 2014-01-18 09:11:43 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:11:43 --> Session routines successfully run
DEBUG - 2014-01-18 09:11:43 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:11:43 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:11:43 --> Model Class Initialized
DEBUG - 2014-01-18 09:11:43 --> Model Class Initialized
DEBUG - 2014-01-18 09:11:43 --> Controller Class Initialized
DEBUG - 2014-01-18 09:11:43 --> Model Class Initialized
DEBUG - 2014-01-18 09:11:43 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 09:11:44 --> Config Class Initialized
DEBUG - 2014-01-18 09:11:44 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:11:44 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:11:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:11:44 --> URI Class Initialized
DEBUG - 2014-01-18 09:11:44 --> Router Class Initialized
DEBUG - 2014-01-18 09:11:44 --> Output Class Initialized
DEBUG - 2014-01-18 09:11:44 --> Security Class Initialized
DEBUG - 2014-01-18 09:11:44 --> Input Class Initialized
DEBUG - 2014-01-18 09:11:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:11:44 --> Language Class Initialized
DEBUG - 2014-01-18 09:11:44 --> Loader Class Initialized
DEBUG - 2014-01-18 09:11:44 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:11:44 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:11:44 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:11:44 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:11:44 --> Session Class Initialized
DEBUG - 2014-01-18 09:11:44 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:11:44 --> Session routines successfully run
DEBUG - 2014-01-18 09:11:44 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:11:44 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:11:44 --> Model Class Initialized
DEBUG - 2014-01-18 09:11:44 --> Model Class Initialized
DEBUG - 2014-01-18 09:11:44 --> Controller Class Initialized
DEBUG - 2014-01-18 09:11:44 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 09:11:44 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 09:11:44 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 09:11:44 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 09:11:44 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 09:11:44 --> Final output sent to browser
DEBUG - 2014-01-18 09:11:44 --> Total execution time: 0.0550
DEBUG - 2014-01-18 09:12:03 --> Config Class Initialized
DEBUG - 2014-01-18 09:12:03 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:12:03 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:12:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:12:03 --> URI Class Initialized
DEBUG - 2014-01-18 09:12:03 --> Router Class Initialized
DEBUG - 2014-01-18 09:12:03 --> Output Class Initialized
DEBUG - 2014-01-18 09:12:03 --> Security Class Initialized
DEBUG - 2014-01-18 09:12:03 --> Input Class Initialized
DEBUG - 2014-01-18 09:12:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:12:03 --> Language Class Initialized
DEBUG - 2014-01-18 09:12:03 --> Loader Class Initialized
DEBUG - 2014-01-18 09:12:03 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:12:03 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:12:03 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:12:03 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:12:03 --> Session Class Initialized
DEBUG - 2014-01-18 09:12:03 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:12:03 --> Session routines successfully run
DEBUG - 2014-01-18 09:12:03 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:12:03 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:12:03 --> Model Class Initialized
DEBUG - 2014-01-18 09:12:03 --> Model Class Initialized
DEBUG - 2014-01-18 09:12:03 --> Controller Class Initialized
DEBUG - 2014-01-18 09:12:03 --> Model Class Initialized
DEBUG - 2014-01-18 09:12:03 --> File loaded: application/views/user/dodaj.php
DEBUG - 2014-01-18 09:12:03 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 09:12:03 --> Final output sent to browser
DEBUG - 2014-01-18 09:12:03 --> Total execution time: 0.0619
DEBUG - 2014-01-18 09:12:19 --> Config Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:12:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:12:19 --> URI Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Router Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Output Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Security Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Input Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:12:19 --> Language Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Loader Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:12:19 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:12:19 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:12:19 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Session Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:12:19 --> Session routines successfully run
DEBUG - 2014-01-18 09:12:19 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Model Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Model Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Controller Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Model Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 09:12:19 --> Config Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:12:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:12:19 --> URI Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Router Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Output Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Security Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Input Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:12:19 --> Language Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Loader Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:12:19 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:12:19 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:12:19 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Session Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:12:19 --> Session routines successfully run
DEBUG - 2014-01-18 09:12:19 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Model Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Model Class Initialized
DEBUG - 2014-01-18 09:12:19 --> Controller Class Initialized
DEBUG - 2014-01-18 09:12:19 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 09:12:19 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 09:12:19 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 09:12:19 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 09:12:19 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 09:12:19 --> Final output sent to browser
DEBUG - 2014-01-18 09:12:19 --> Total execution time: 0.0610
DEBUG - 2014-01-18 09:18:15 --> Config Class Initialized
DEBUG - 2014-01-18 09:18:15 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:18:15 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:18:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:18:15 --> URI Class Initialized
DEBUG - 2014-01-18 09:18:15 --> Router Class Initialized
DEBUG - 2014-01-18 09:18:15 --> Output Class Initialized
DEBUG - 2014-01-18 09:18:15 --> Security Class Initialized
DEBUG - 2014-01-18 09:18:15 --> Input Class Initialized
DEBUG - 2014-01-18 09:18:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:18:15 --> Language Class Initialized
DEBUG - 2014-01-18 09:18:15 --> Loader Class Initialized
DEBUG - 2014-01-18 09:18:15 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:18:15 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:18:15 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:18:15 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:18:15 --> Session Class Initialized
DEBUG - 2014-01-18 09:18:15 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:18:15 --> Session routines successfully run
DEBUG - 2014-01-18 09:18:15 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:18:15 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:18:15 --> Model Class Initialized
DEBUG - 2014-01-18 09:18:15 --> Model Class Initialized
DEBUG - 2014-01-18 09:18:15 --> Controller Class Initialized
DEBUG - 2014-01-18 09:18:15 --> File loaded: application/views/user/podglad.php
DEBUG - 2014-01-18 09:18:15 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 09:18:15 --> Final output sent to browser
DEBUG - 2014-01-18 09:18:15 --> Total execution time: 0.0675
DEBUG - 2014-01-18 09:18:22 --> Config Class Initialized
DEBUG - 2014-01-18 09:18:22 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:18:22 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:18:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:18:22 --> URI Class Initialized
DEBUG - 2014-01-18 09:18:22 --> Router Class Initialized
DEBUG - 2014-01-18 09:18:22 --> Output Class Initialized
DEBUG - 2014-01-18 09:18:22 --> Security Class Initialized
DEBUG - 2014-01-18 09:18:22 --> Input Class Initialized
DEBUG - 2014-01-18 09:18:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:18:22 --> Language Class Initialized
DEBUG - 2014-01-18 09:18:22 --> Loader Class Initialized
DEBUG - 2014-01-18 09:18:22 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:18:22 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:18:22 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:18:22 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:18:22 --> Session Class Initialized
DEBUG - 2014-01-18 09:18:22 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:18:22 --> Session routines successfully run
DEBUG - 2014-01-18 09:18:22 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:18:22 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:18:22 --> Model Class Initialized
DEBUG - 2014-01-18 09:18:22 --> Model Class Initialized
DEBUG - 2014-01-18 09:18:22 --> Controller Class Initialized
DEBUG - 2014-01-18 09:18:22 --> Config Class Initialized
DEBUG - 2014-01-18 09:18:22 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:18:22 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:18:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:18:22 --> URI Class Initialized
DEBUG - 2014-01-18 09:18:22 --> Router Class Initialized
DEBUG - 2014-01-18 09:18:22 --> No URI present. Default controller set.
DEBUG - 2014-01-18 09:18:22 --> Output Class Initialized
DEBUG - 2014-01-18 09:18:22 --> Security Class Initialized
DEBUG - 2014-01-18 09:18:22 --> Input Class Initialized
DEBUG - 2014-01-18 09:18:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:18:22 --> Language Class Initialized
DEBUG - 2014-01-18 09:18:22 --> Loader Class Initialized
DEBUG - 2014-01-18 09:18:22 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:18:22 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:18:22 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:18:22 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:18:22 --> Session Class Initialized
DEBUG - 2014-01-18 09:18:22 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:18:22 --> Session routines successfully run
DEBUG - 2014-01-18 09:18:22 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:18:22 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:18:22 --> Model Class Initialized
DEBUG - 2014-01-18 09:18:22 --> Model Class Initialized
DEBUG - 2014-01-18 09:18:22 --> Controller Class Initialized
DEBUG - 2014-01-18 09:18:22 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 09:18:22 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 09:18:22 --> Final output sent to browser
DEBUG - 2014-01-18 09:18:22 --> Total execution time: 0.0480
DEBUG - 2014-01-18 09:18:24 --> Config Class Initialized
DEBUG - 2014-01-18 09:18:24 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:18:24 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:18:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:18:24 --> URI Class Initialized
DEBUG - 2014-01-18 09:18:24 --> Router Class Initialized
DEBUG - 2014-01-18 09:18:24 --> Output Class Initialized
DEBUG - 2014-01-18 09:18:24 --> Security Class Initialized
DEBUG - 2014-01-18 09:18:24 --> Input Class Initialized
DEBUG - 2014-01-18 09:18:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:18:24 --> Language Class Initialized
DEBUG - 2014-01-18 09:18:24 --> Loader Class Initialized
DEBUG - 2014-01-18 09:18:24 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:18:24 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:18:24 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:18:24 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:18:24 --> Session Class Initialized
DEBUG - 2014-01-18 09:18:24 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:18:24 --> Session routines successfully run
DEBUG - 2014-01-18 09:18:24 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:18:24 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:18:24 --> Model Class Initialized
DEBUG - 2014-01-18 09:18:24 --> Model Class Initialized
DEBUG - 2014-01-18 09:18:24 --> Controller Class Initialized
DEBUG - 2014-01-18 09:18:24 --> File loaded: application/views/user/reset_hasla.php
DEBUG - 2014-01-18 09:18:24 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 09:18:24 --> Final output sent to browser
DEBUG - 2014-01-18 09:18:24 --> Total execution time: 0.0619
DEBUG - 2014-01-18 09:18:45 --> Config Class Initialized
DEBUG - 2014-01-18 09:18:45 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:18:45 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:18:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:18:45 --> URI Class Initialized
DEBUG - 2014-01-18 09:18:45 --> Router Class Initialized
DEBUG - 2014-01-18 09:18:45 --> Output Class Initialized
DEBUG - 2014-01-18 09:18:45 --> Security Class Initialized
DEBUG - 2014-01-18 09:18:45 --> Input Class Initialized
DEBUG - 2014-01-18 09:18:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:18:45 --> Language Class Initialized
DEBUG - 2014-01-18 09:18:45 --> Loader Class Initialized
DEBUG - 2014-01-18 09:18:45 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:18:45 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:18:45 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:18:46 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:18:46 --> Session Class Initialized
DEBUG - 2014-01-18 09:18:46 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:18:46 --> Session routines successfully run
DEBUG - 2014-01-18 09:18:46 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:18:46 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:18:46 --> Model Class Initialized
DEBUG - 2014-01-18 09:18:46 --> Model Class Initialized
DEBUG - 2014-01-18 09:18:46 --> Controller Class Initialized
DEBUG - 2014-01-18 09:18:46 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 09:18:46 --> Model Class Initialized
ERROR - 2014-01-18 09:18:46 --> Severity: Warning  --> fsockopen(): unable to connect to ssl://smtp.gmail.com:465 (Unable to find the socket transport &quot;ssl&quot; - did you forget to enable it when you configured PHP?) C:\wamp\www\Windykator1\phpmailer\class.smtp.php 132
DEBUG - 2014-01-18 09:46:57 --> Config Class Initialized
DEBUG - 2014-01-18 09:46:57 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:46:57 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:46:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:46:57 --> URI Class Initialized
DEBUG - 2014-01-18 09:46:57 --> Router Class Initialized
DEBUG - 2014-01-18 09:46:58 --> Output Class Initialized
DEBUG - 2014-01-18 09:46:58 --> Security Class Initialized
DEBUG - 2014-01-18 09:46:58 --> Input Class Initialized
DEBUG - 2014-01-18 09:46:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:46:58 --> Language Class Initialized
DEBUG - 2014-01-18 09:46:58 --> Loader Class Initialized
DEBUG - 2014-01-18 09:46:58 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:46:58 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:46:58 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:46:58 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:46:58 --> Session Class Initialized
DEBUG - 2014-01-18 09:46:58 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:46:58 --> Session routines successfully run
DEBUG - 2014-01-18 09:46:58 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:46:58 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:46:58 --> Model Class Initialized
DEBUG - 2014-01-18 09:46:58 --> Model Class Initialized
DEBUG - 2014-01-18 09:46:58 --> Controller Class Initialized
DEBUG - 2014-01-18 09:46:58 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 09:46:58 --> Model Class Initialized
DEBUG - 2014-01-18 09:47:54 --> Config Class Initialized
DEBUG - 2014-01-18 09:47:54 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:47:54 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:47:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:47:54 --> URI Class Initialized
DEBUG - 2014-01-18 09:47:54 --> Router Class Initialized
DEBUG - 2014-01-18 09:47:54 --> No URI present. Default controller set.
DEBUG - 2014-01-18 09:47:54 --> Output Class Initialized
DEBUG - 2014-01-18 09:47:54 --> Security Class Initialized
DEBUG - 2014-01-18 09:47:54 --> Input Class Initialized
DEBUG - 2014-01-18 09:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:47:54 --> Language Class Initialized
DEBUG - 2014-01-18 09:47:54 --> Loader Class Initialized
DEBUG - 2014-01-18 09:47:54 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:47:54 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:47:54 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:47:54 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:47:54 --> Session Class Initialized
DEBUG - 2014-01-18 09:47:54 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:47:54 --> Session routines successfully run
DEBUG - 2014-01-18 09:47:54 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:47:54 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:47:54 --> Model Class Initialized
DEBUG - 2014-01-18 09:47:54 --> Model Class Initialized
DEBUG - 2014-01-18 09:47:54 --> Controller Class Initialized
DEBUG - 2014-01-18 09:47:54 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 09:47:54 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 09:47:54 --> Final output sent to browser
DEBUG - 2014-01-18 09:47:54 --> Total execution time: 0.0711
DEBUG - 2014-01-18 09:47:58 --> Config Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:47:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:47:58 --> URI Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Router Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Output Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Security Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Input Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:47:58 --> Language Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Loader Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:47:58 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:47:58 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:47:58 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Session Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:47:58 --> Session routines successfully run
DEBUG - 2014-01-18 09:47:58 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Model Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Model Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Controller Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 09:47:58 --> Config Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:47:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:47:58 --> URI Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Router Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Output Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Security Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Input Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:47:58 --> Language Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Loader Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:47:58 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:47:58 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:47:58 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Session Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:47:58 --> Session routines successfully run
DEBUG - 2014-01-18 09:47:58 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Model Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Model Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Controller Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Model Class Initialized
DEBUG - 2014-01-18 09:47:58 --> Model Class Initialized
DEBUG - 2014-01-18 09:47:59 --> File loaded: application/views/wniosek/lista.php
DEBUG - 2014-01-18 09:47:59 --> File loaded: application/views/user/aktualnosci.php
DEBUG - 2014-01-18 09:47:59 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 09:47:59 --> Final output sent to browser
DEBUG - 2014-01-18 09:47:59 --> Total execution time: 0.1901
DEBUG - 2014-01-18 09:48:00 --> Config Class Initialized
DEBUG - 2014-01-18 09:48:00 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:48:00 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:48:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:48:01 --> URI Class Initialized
DEBUG - 2014-01-18 09:48:01 --> Router Class Initialized
DEBUG - 2014-01-18 09:48:01 --> Output Class Initialized
DEBUG - 2014-01-18 09:48:01 --> Security Class Initialized
DEBUG - 2014-01-18 09:48:01 --> Input Class Initialized
DEBUG - 2014-01-18 09:48:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:48:01 --> Language Class Initialized
DEBUG - 2014-01-18 09:48:01 --> Loader Class Initialized
DEBUG - 2014-01-18 09:48:01 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:48:01 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:48:01 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:48:01 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:48:01 --> Session Class Initialized
DEBUG - 2014-01-18 09:48:01 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:48:01 --> Session routines successfully run
DEBUG - 2014-01-18 09:48:01 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:48:01 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:48:01 --> Model Class Initialized
DEBUG - 2014-01-18 09:48:01 --> Model Class Initialized
DEBUG - 2014-01-18 09:48:01 --> Controller Class Initialized
DEBUG - 2014-01-18 09:48:01 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 09:48:01 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 09:48:01 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 09:48:01 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 09:48:01 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 09:48:01 --> Final output sent to browser
DEBUG - 2014-01-18 09:48:01 --> Total execution time: 0.0676
DEBUG - 2014-01-18 09:48:04 --> Config Class Initialized
DEBUG - 2014-01-18 09:48:04 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:48:04 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:48:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:48:04 --> URI Class Initialized
DEBUG - 2014-01-18 09:48:04 --> Router Class Initialized
DEBUG - 2014-01-18 09:48:04 --> Output Class Initialized
DEBUG - 2014-01-18 09:48:04 --> Security Class Initialized
DEBUG - 2014-01-18 09:48:04 --> Input Class Initialized
DEBUG - 2014-01-18 09:48:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:48:04 --> Language Class Initialized
DEBUG - 2014-01-18 09:48:04 --> Loader Class Initialized
DEBUG - 2014-01-18 09:48:04 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:48:04 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:48:04 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:48:04 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:48:04 --> Session Class Initialized
DEBUG - 2014-01-18 09:48:04 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:48:04 --> Session routines successfully run
DEBUG - 2014-01-18 09:48:04 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:48:04 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:48:04 --> Model Class Initialized
DEBUG - 2014-01-18 09:48:04 --> Model Class Initialized
DEBUG - 2014-01-18 09:48:04 --> Controller Class Initialized
DEBUG - 2014-01-18 09:48:04 --> File loaded: application/views/user/podglad.php
DEBUG - 2014-01-18 09:48:04 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 09:48:04 --> Final output sent to browser
DEBUG - 2014-01-18 09:48:04 --> Total execution time: 0.0756
DEBUG - 2014-01-18 09:48:16 --> Config Class Initialized
DEBUG - 2014-01-18 09:48:16 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:48:16 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:48:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:48:16 --> URI Class Initialized
DEBUG - 2014-01-18 09:48:16 --> Router Class Initialized
DEBUG - 2014-01-18 09:48:16 --> Output Class Initialized
DEBUG - 2014-01-18 09:48:16 --> Security Class Initialized
DEBUG - 2014-01-18 09:48:16 --> Input Class Initialized
DEBUG - 2014-01-18 09:48:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:48:16 --> Language Class Initialized
DEBUG - 2014-01-18 09:48:16 --> Loader Class Initialized
DEBUG - 2014-01-18 09:48:16 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:48:16 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:48:16 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:48:16 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:48:16 --> Session Class Initialized
DEBUG - 2014-01-18 09:48:16 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:48:16 --> Session routines successfully run
DEBUG - 2014-01-18 09:48:16 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:48:16 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:48:16 --> Model Class Initialized
DEBUG - 2014-01-18 09:48:16 --> Model Class Initialized
DEBUG - 2014-01-18 09:48:16 --> Controller Class Initialized
DEBUG - 2014-01-18 09:48:16 --> File loaded: application/views/user/reset_hasla.php
DEBUG - 2014-01-18 09:48:16 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 09:48:16 --> Final output sent to browser
DEBUG - 2014-01-18 09:48:16 --> Total execution time: 0.0758
DEBUG - 2014-01-18 09:48:21 --> Config Class Initialized
DEBUG - 2014-01-18 09:48:21 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:48:21 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:48:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:48:21 --> URI Class Initialized
DEBUG - 2014-01-18 09:48:21 --> Router Class Initialized
DEBUG - 2014-01-18 09:48:21 --> Output Class Initialized
DEBUG - 2014-01-18 09:48:21 --> Security Class Initialized
DEBUG - 2014-01-18 09:48:21 --> Input Class Initialized
DEBUG - 2014-01-18 09:48:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:48:21 --> Language Class Initialized
DEBUG - 2014-01-18 09:48:21 --> Loader Class Initialized
DEBUG - 2014-01-18 09:48:21 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:48:21 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:48:21 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:48:21 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:48:21 --> Session Class Initialized
DEBUG - 2014-01-18 09:48:21 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:48:21 --> Session routines successfully run
DEBUG - 2014-01-18 09:48:21 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:48:21 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:48:21 --> Model Class Initialized
DEBUG - 2014-01-18 09:48:21 --> Model Class Initialized
DEBUG - 2014-01-18 09:48:21 --> Controller Class Initialized
DEBUG - 2014-01-18 09:48:21 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 09:48:21 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 09:48:21 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 09:48:21 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 09:48:21 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 09:48:21 --> Final output sent to browser
DEBUG - 2014-01-18 09:48:21 --> Total execution time: 0.0693
DEBUG - 2014-01-18 09:48:29 --> Config Class Initialized
DEBUG - 2014-01-18 09:48:29 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:48:29 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:48:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:48:29 --> URI Class Initialized
DEBUG - 2014-01-18 09:48:29 --> Router Class Initialized
DEBUG - 2014-01-18 09:48:29 --> Output Class Initialized
DEBUG - 2014-01-18 09:48:29 --> Security Class Initialized
DEBUG - 2014-01-18 09:48:29 --> Input Class Initialized
DEBUG - 2014-01-18 09:48:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:48:29 --> Language Class Initialized
DEBUG - 2014-01-18 09:48:29 --> Loader Class Initialized
DEBUG - 2014-01-18 09:48:29 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:48:29 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:48:29 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:48:29 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:48:29 --> Session Class Initialized
DEBUG - 2014-01-18 09:48:29 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:48:29 --> Session routines successfully run
DEBUG - 2014-01-18 09:48:29 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:48:29 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:48:29 --> Model Class Initialized
DEBUG - 2014-01-18 09:48:29 --> Model Class Initialized
DEBUG - 2014-01-18 09:48:29 --> Controller Class Initialized
DEBUG - 2014-01-18 09:48:29 --> File loaded: application/views/user/reset_hasla.php
DEBUG - 2014-01-18 09:48:29 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 09:48:29 --> Final output sent to browser
DEBUG - 2014-01-18 09:48:29 --> Total execution time: 0.0574
DEBUG - 2014-01-18 09:48:30 --> Config Class Initialized
DEBUG - 2014-01-18 09:48:30 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:48:30 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:48:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:48:30 --> URI Class Initialized
DEBUG - 2014-01-18 09:48:30 --> Router Class Initialized
DEBUG - 2014-01-18 09:48:30 --> Output Class Initialized
DEBUG - 2014-01-18 09:48:30 --> Security Class Initialized
DEBUG - 2014-01-18 09:48:30 --> Input Class Initialized
DEBUG - 2014-01-18 09:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:48:30 --> Language Class Initialized
DEBUG - 2014-01-18 09:48:30 --> Loader Class Initialized
DEBUG - 2014-01-18 09:48:30 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:48:30 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:48:30 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:48:30 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:48:30 --> Session Class Initialized
DEBUG - 2014-01-18 09:48:30 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:48:30 --> Session routines successfully run
DEBUG - 2014-01-18 09:48:30 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:48:30 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:48:30 --> Model Class Initialized
DEBUG - 2014-01-18 09:48:30 --> Model Class Initialized
DEBUG - 2014-01-18 09:48:30 --> Controller Class Initialized
DEBUG - 2014-01-18 09:48:30 --> Config Class Initialized
DEBUG - 2014-01-18 09:48:30 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:48:30 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:48:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:48:30 --> URI Class Initialized
DEBUG - 2014-01-18 09:48:30 --> Router Class Initialized
DEBUG - 2014-01-18 09:48:30 --> No URI present. Default controller set.
DEBUG - 2014-01-18 09:48:30 --> Output Class Initialized
DEBUG - 2014-01-18 09:48:30 --> Security Class Initialized
DEBUG - 2014-01-18 09:48:30 --> Input Class Initialized
DEBUG - 2014-01-18 09:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:48:30 --> Language Class Initialized
DEBUG - 2014-01-18 09:48:30 --> Loader Class Initialized
DEBUG - 2014-01-18 09:48:30 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:48:30 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:48:30 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:48:30 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:48:30 --> Session Class Initialized
DEBUG - 2014-01-18 09:48:30 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:48:30 --> Session routines successfully run
DEBUG - 2014-01-18 09:48:30 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:48:30 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:48:30 --> Model Class Initialized
DEBUG - 2014-01-18 09:48:30 --> Model Class Initialized
DEBUG - 2014-01-18 09:48:30 --> Controller Class Initialized
DEBUG - 2014-01-18 09:48:30 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 09:48:30 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 09:48:30 --> Final output sent to browser
DEBUG - 2014-01-18 09:48:30 --> Total execution time: 0.0572
DEBUG - 2014-01-18 09:48:41 --> Config Class Initialized
DEBUG - 2014-01-18 09:48:41 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:48:41 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:48:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:48:41 --> URI Class Initialized
DEBUG - 2014-01-18 09:48:41 --> Router Class Initialized
DEBUG - 2014-01-18 09:48:41 --> Output Class Initialized
DEBUG - 2014-01-18 09:48:41 --> Security Class Initialized
DEBUG - 2014-01-18 09:48:41 --> Input Class Initialized
DEBUG - 2014-01-18 09:48:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:48:41 --> Language Class Initialized
DEBUG - 2014-01-18 09:48:41 --> Loader Class Initialized
DEBUG - 2014-01-18 09:48:41 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:48:41 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:48:41 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:48:41 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:48:41 --> Session Class Initialized
DEBUG - 2014-01-18 09:48:41 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:48:41 --> Session routines successfully run
DEBUG - 2014-01-18 09:48:41 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:48:41 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:48:41 --> Model Class Initialized
DEBUG - 2014-01-18 09:48:41 --> Model Class Initialized
DEBUG - 2014-01-18 09:48:41 --> Controller Class Initialized
DEBUG - 2014-01-18 09:48:41 --> File loaded: application/views/user/reset_hasla.php
DEBUG - 2014-01-18 09:48:41 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 09:48:41 --> Final output sent to browser
DEBUG - 2014-01-18 09:48:41 --> Total execution time: 0.0580
DEBUG - 2014-01-18 09:48:53 --> Config Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:48:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:48:53 --> URI Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Router Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Output Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Security Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Input Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:48:53 --> Language Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Loader Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:48:53 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:48:53 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:48:53 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Session Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:48:53 --> Session routines successfully run
DEBUG - 2014-01-18 09:48:53 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Model Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Model Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Controller Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 09:48:53 --> Config Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:48:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:48:53 --> URI Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Router Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Output Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Security Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Input Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:48:53 --> Language Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Loader Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:48:53 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:48:53 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:48:53 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Session Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:48:53 --> Session routines successfully run
DEBUG - 2014-01-18 09:48:53 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Model Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Model Class Initialized
DEBUG - 2014-01-18 09:48:53 --> Controller Class Initialized
DEBUG - 2014-01-18 09:48:53 --> File loaded: application/views/user/reset_hasla.php
DEBUG - 2014-01-18 09:48:53 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 09:48:53 --> Final output sent to browser
DEBUG - 2014-01-18 09:48:53 --> Total execution time: 0.0577
DEBUG - 2014-01-18 09:49:07 --> Config Class Initialized
DEBUG - 2014-01-18 09:49:07 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:49:07 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:49:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:49:07 --> URI Class Initialized
DEBUG - 2014-01-18 09:49:07 --> Router Class Initialized
DEBUG - 2014-01-18 09:49:07 --> Output Class Initialized
DEBUG - 2014-01-18 09:49:07 --> Security Class Initialized
DEBUG - 2014-01-18 09:49:07 --> Input Class Initialized
DEBUG - 2014-01-18 09:49:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:49:07 --> Language Class Initialized
DEBUG - 2014-01-18 09:49:07 --> Loader Class Initialized
DEBUG - 2014-01-18 09:49:07 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:49:07 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:49:07 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:49:07 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:49:07 --> Session Class Initialized
DEBUG - 2014-01-18 09:49:07 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:49:07 --> Session routines successfully run
DEBUG - 2014-01-18 09:49:07 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:49:07 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:49:07 --> Model Class Initialized
DEBUG - 2014-01-18 09:49:07 --> Model Class Initialized
DEBUG - 2014-01-18 09:49:07 --> Controller Class Initialized
DEBUG - 2014-01-18 09:49:07 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 09:49:07 --> Model Class Initialized
DEBUG - 2014-01-18 09:58:19 --> Config Class Initialized
DEBUG - 2014-01-18 09:58:19 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:58:19 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:58:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:58:19 --> URI Class Initialized
DEBUG - 2014-01-18 09:58:19 --> Router Class Initialized
DEBUG - 2014-01-18 09:58:19 --> Output Class Initialized
DEBUG - 2014-01-18 09:58:19 --> Security Class Initialized
DEBUG - 2014-01-18 09:58:19 --> Input Class Initialized
DEBUG - 2014-01-18 09:58:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:58:19 --> Language Class Initialized
DEBUG - 2014-01-18 09:58:19 --> Loader Class Initialized
DEBUG - 2014-01-18 09:58:19 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:58:19 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:58:19 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:58:19 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:58:19 --> Session Class Initialized
DEBUG - 2014-01-18 09:58:19 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:58:19 --> Session routines successfully run
DEBUG - 2014-01-18 09:58:19 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:58:19 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:58:19 --> Model Class Initialized
DEBUG - 2014-01-18 09:58:19 --> Model Class Initialized
DEBUG - 2014-01-18 09:58:19 --> Controller Class Initialized
DEBUG - 2014-01-18 09:58:19 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 09:58:19 --> Model Class Initialized
ERROR - 2014-01-18 09:58:21 --> Severity: Notice  --> Undefined index: e-mail C:\wamp\www\Windykator1\application\models\users.php 153
DEBUG - 2014-01-18 09:58:21 --> Config Class Initialized
DEBUG - 2014-01-18 09:58:21 --> Hooks Class Initialized
DEBUG - 2014-01-18 09:58:21 --> Utf8 Class Initialized
DEBUG - 2014-01-18 09:58:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 09:58:21 --> URI Class Initialized
DEBUG - 2014-01-18 09:58:21 --> Router Class Initialized
DEBUG - 2014-01-18 09:58:21 --> Output Class Initialized
DEBUG - 2014-01-18 09:58:21 --> Security Class Initialized
DEBUG - 2014-01-18 09:58:21 --> Input Class Initialized
DEBUG - 2014-01-18 09:58:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 09:58:21 --> Language Class Initialized
DEBUG - 2014-01-18 09:58:21 --> Loader Class Initialized
DEBUG - 2014-01-18 09:58:21 --> Helper loaded: url_helper
DEBUG - 2014-01-18 09:58:21 --> Helper loaded: form_helper
DEBUG - 2014-01-18 09:58:21 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 09:58:21 --> Database Driver Class Initialized
DEBUG - 2014-01-18 09:58:21 --> Session Class Initialized
DEBUG - 2014-01-18 09:58:21 --> Helper loaded: string_helper
DEBUG - 2014-01-18 09:58:21 --> Session routines successfully run
DEBUG - 2014-01-18 09:58:21 --> User Agent Class Initialized
DEBUG - 2014-01-18 09:58:21 --> Form Validation Class Initialized
DEBUG - 2014-01-18 09:58:21 --> Model Class Initialized
DEBUG - 2014-01-18 09:58:21 --> Model Class Initialized
DEBUG - 2014-01-18 09:58:21 --> Controller Class Initialized
DEBUG - 2014-01-18 09:58:21 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 09:58:21 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 09:58:21 --> Final output sent to browser
DEBUG - 2014-01-18 09:58:21 --> Total execution time: 0.0578
DEBUG - 2014-01-18 10:01:56 --> Config Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Hooks Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Utf8 Class Initialized
DEBUG - 2014-01-18 10:01:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 10:01:56 --> URI Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Router Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Output Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Security Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Input Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 10:01:56 --> Language Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Loader Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Helper loaded: url_helper
DEBUG - 2014-01-18 10:01:56 --> Helper loaded: form_helper
DEBUG - 2014-01-18 10:01:56 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 10:01:56 --> Database Driver Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Session Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Helper loaded: string_helper
DEBUG - 2014-01-18 10:01:56 --> Session routines successfully run
DEBUG - 2014-01-18 10:01:56 --> User Agent Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Form Validation Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Model Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Model Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Controller Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 10:01:56 --> Config Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Hooks Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Utf8 Class Initialized
DEBUG - 2014-01-18 10:01:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 10:01:56 --> URI Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Router Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Output Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Security Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Input Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 10:01:56 --> Language Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Loader Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Helper loaded: url_helper
DEBUG - 2014-01-18 10:01:56 --> Helper loaded: form_helper
DEBUG - 2014-01-18 10:01:56 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 10:01:56 --> Database Driver Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Session Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Helper loaded: string_helper
DEBUG - 2014-01-18 10:01:56 --> Session routines successfully run
DEBUG - 2014-01-18 10:01:56 --> User Agent Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Form Validation Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Model Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Model Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Controller Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Model Class Initialized
DEBUG - 2014-01-18 10:01:56 --> Model Class Initialized
DEBUG - 2014-01-18 10:01:56 --> File loaded: application/views/wniosek/lista.php
DEBUG - 2014-01-18 10:01:56 --> File loaded: application/views/user/aktualnosci.php
DEBUG - 2014-01-18 10:01:56 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 10:01:56 --> Final output sent to browser
DEBUG - 2014-01-18 10:01:56 --> Total execution time: 0.0623
DEBUG - 2014-01-18 10:01:59 --> Config Class Initialized
DEBUG - 2014-01-18 10:01:59 --> Hooks Class Initialized
DEBUG - 2014-01-18 10:01:59 --> Utf8 Class Initialized
DEBUG - 2014-01-18 10:01:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 10:01:59 --> URI Class Initialized
DEBUG - 2014-01-18 10:01:59 --> Router Class Initialized
DEBUG - 2014-01-18 10:01:59 --> Output Class Initialized
DEBUG - 2014-01-18 10:01:59 --> Security Class Initialized
DEBUG - 2014-01-18 10:01:59 --> Input Class Initialized
DEBUG - 2014-01-18 10:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 10:01:59 --> Language Class Initialized
DEBUG - 2014-01-18 10:01:59 --> Loader Class Initialized
DEBUG - 2014-01-18 10:01:59 --> Helper loaded: url_helper
DEBUG - 2014-01-18 10:01:59 --> Helper loaded: form_helper
DEBUG - 2014-01-18 10:01:59 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 10:01:59 --> Database Driver Class Initialized
DEBUG - 2014-01-18 10:01:59 --> Session Class Initialized
DEBUG - 2014-01-18 10:01:59 --> Helper loaded: string_helper
DEBUG - 2014-01-18 10:01:59 --> Session routines successfully run
DEBUG - 2014-01-18 10:01:59 --> User Agent Class Initialized
DEBUG - 2014-01-18 10:01:59 --> Form Validation Class Initialized
DEBUG - 2014-01-18 10:01:59 --> Model Class Initialized
DEBUG - 2014-01-18 10:01:59 --> Model Class Initialized
DEBUG - 2014-01-18 10:01:59 --> Controller Class Initialized
DEBUG - 2014-01-18 10:01:59 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 10:01:59 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 10:01:59 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 10:01:59 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 10:01:59 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 10:01:59 --> Final output sent to browser
DEBUG - 2014-01-18 10:01:59 --> Total execution time: 0.0791
DEBUG - 2014-01-18 10:02:02 --> Config Class Initialized
DEBUG - 2014-01-18 10:02:02 --> Hooks Class Initialized
DEBUG - 2014-01-18 10:02:02 --> Utf8 Class Initialized
DEBUG - 2014-01-18 10:02:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 10:02:02 --> URI Class Initialized
DEBUG - 2014-01-18 10:02:02 --> Router Class Initialized
DEBUG - 2014-01-18 10:02:02 --> Output Class Initialized
DEBUG - 2014-01-18 10:02:02 --> Security Class Initialized
DEBUG - 2014-01-18 10:02:02 --> Input Class Initialized
DEBUG - 2014-01-18 10:02:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 10:02:02 --> Language Class Initialized
DEBUG - 2014-01-18 10:02:02 --> Loader Class Initialized
DEBUG - 2014-01-18 10:02:02 --> Helper loaded: url_helper
DEBUG - 2014-01-18 10:02:02 --> Helper loaded: form_helper
DEBUG - 2014-01-18 10:02:02 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 10:02:02 --> Database Driver Class Initialized
DEBUG - 2014-01-18 10:02:02 --> Session Class Initialized
DEBUG - 2014-01-18 10:02:02 --> Helper loaded: string_helper
DEBUG - 2014-01-18 10:02:02 --> Session routines successfully run
DEBUG - 2014-01-18 10:02:02 --> User Agent Class Initialized
DEBUG - 2014-01-18 10:02:02 --> Form Validation Class Initialized
DEBUG - 2014-01-18 10:02:02 --> Model Class Initialized
DEBUG - 2014-01-18 10:02:02 --> Model Class Initialized
DEBUG - 2014-01-18 10:02:02 --> Controller Class Initialized
DEBUG - 2014-01-18 10:02:02 --> Model Class Initialized
DEBUG - 2014-01-18 10:02:02 --> File loaded: application/views/user/dodaj.php
DEBUG - 2014-01-18 10:02:02 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 10:02:02 --> Final output sent to browser
DEBUG - 2014-01-18 10:02:02 --> Total execution time: 0.1157
DEBUG - 2014-01-18 10:02:29 --> Config Class Initialized
DEBUG - 2014-01-18 10:02:29 --> Hooks Class Initialized
DEBUG - 2014-01-18 10:02:29 --> Utf8 Class Initialized
DEBUG - 2014-01-18 10:02:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 10:02:29 --> URI Class Initialized
DEBUG - 2014-01-18 10:02:29 --> Router Class Initialized
DEBUG - 2014-01-18 10:02:29 --> Output Class Initialized
DEBUG - 2014-01-18 10:02:29 --> Security Class Initialized
DEBUG - 2014-01-18 10:02:29 --> Input Class Initialized
DEBUG - 2014-01-18 10:02:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 10:02:29 --> Language Class Initialized
DEBUG - 2014-01-18 10:02:29 --> Loader Class Initialized
DEBUG - 2014-01-18 10:02:29 --> Helper loaded: url_helper
DEBUG - 2014-01-18 10:02:29 --> Helper loaded: form_helper
DEBUG - 2014-01-18 10:02:29 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 10:02:29 --> Database Driver Class Initialized
DEBUG - 2014-01-18 10:02:29 --> Session Class Initialized
DEBUG - 2014-01-18 10:02:29 --> Helper loaded: string_helper
DEBUG - 2014-01-18 10:02:29 --> Session routines successfully run
DEBUG - 2014-01-18 10:02:29 --> User Agent Class Initialized
DEBUG - 2014-01-18 10:02:29 --> Form Validation Class Initialized
DEBUG - 2014-01-18 10:02:29 --> Model Class Initialized
DEBUG - 2014-01-18 10:02:29 --> Model Class Initialized
DEBUG - 2014-01-18 10:02:29 --> Controller Class Initialized
DEBUG - 2014-01-18 10:02:29 --> Model Class Initialized
DEBUG - 2014-01-18 10:02:29 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 10:02:29 --> Model Class Initialized
ERROR - 2014-01-18 10:02:30 --> Severity: Notice  --> Undefined index: e-mail C:\wamp\www\Windykator1\application\models\users.php 293
DEBUG - 2014-01-18 10:02:30 --> Config Class Initialized
DEBUG - 2014-01-18 10:02:30 --> Hooks Class Initialized
DEBUG - 2014-01-18 10:02:30 --> Utf8 Class Initialized
DEBUG - 2014-01-18 10:02:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 10:02:30 --> URI Class Initialized
DEBUG - 2014-01-18 10:02:30 --> Router Class Initialized
DEBUG - 2014-01-18 10:02:30 --> Output Class Initialized
DEBUG - 2014-01-18 10:02:30 --> Security Class Initialized
DEBUG - 2014-01-18 10:02:30 --> Input Class Initialized
DEBUG - 2014-01-18 10:02:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 10:02:30 --> Language Class Initialized
DEBUG - 2014-01-18 10:02:30 --> Loader Class Initialized
DEBUG - 2014-01-18 10:02:30 --> Helper loaded: url_helper
DEBUG - 2014-01-18 10:02:30 --> Helper loaded: form_helper
DEBUG - 2014-01-18 10:02:30 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 10:02:30 --> Database Driver Class Initialized
DEBUG - 2014-01-18 10:02:30 --> Session Class Initialized
DEBUG - 2014-01-18 10:02:30 --> Helper loaded: string_helper
DEBUG - 2014-01-18 10:02:30 --> Session routines successfully run
DEBUG - 2014-01-18 10:02:30 --> User Agent Class Initialized
DEBUG - 2014-01-18 10:02:30 --> Form Validation Class Initialized
DEBUG - 2014-01-18 10:02:30 --> Model Class Initialized
DEBUG - 2014-01-18 10:02:30 --> Model Class Initialized
DEBUG - 2014-01-18 10:02:30 --> Controller Class Initialized
DEBUG - 2014-01-18 10:02:30 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 10:02:30 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 10:02:30 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 10:02:30 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 10:02:30 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 10:02:30 --> Final output sent to browser
DEBUG - 2014-01-18 10:02:30 --> Total execution time: 0.0753
DEBUG - 2014-01-18 10:03:31 --> Config Class Initialized
DEBUG - 2014-01-18 10:03:31 --> Hooks Class Initialized
DEBUG - 2014-01-18 10:03:31 --> Utf8 Class Initialized
DEBUG - 2014-01-18 10:03:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 10:03:31 --> URI Class Initialized
DEBUG - 2014-01-18 10:03:31 --> Router Class Initialized
DEBUG - 2014-01-18 10:03:31 --> Output Class Initialized
DEBUG - 2014-01-18 10:03:31 --> Security Class Initialized
DEBUG - 2014-01-18 10:03:31 --> Input Class Initialized
DEBUG - 2014-01-18 10:03:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 10:03:31 --> Language Class Initialized
DEBUG - 2014-01-18 10:03:31 --> Loader Class Initialized
DEBUG - 2014-01-18 10:03:31 --> Helper loaded: url_helper
DEBUG - 2014-01-18 10:03:31 --> Helper loaded: form_helper
DEBUG - 2014-01-18 10:03:31 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 10:03:31 --> Database Driver Class Initialized
DEBUG - 2014-01-18 10:03:31 --> Session Class Initialized
DEBUG - 2014-01-18 10:03:31 --> Helper loaded: string_helper
DEBUG - 2014-01-18 10:03:31 --> Session routines successfully run
DEBUG - 2014-01-18 10:03:31 --> User Agent Class Initialized
DEBUG - 2014-01-18 10:03:31 --> Form Validation Class Initialized
DEBUG - 2014-01-18 10:03:31 --> Model Class Initialized
DEBUG - 2014-01-18 10:03:31 --> Model Class Initialized
DEBUG - 2014-01-18 10:03:31 --> Controller Class Initialized
DEBUG - 2014-01-18 10:03:31 --> File loaded: application/views/user/podglad.php
DEBUG - 2014-01-18 10:03:31 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 10:03:31 --> Final output sent to browser
DEBUG - 2014-01-18 10:03:31 --> Total execution time: 0.0664
DEBUG - 2014-01-18 10:14:30 --> Config Class Initialized
DEBUG - 2014-01-18 10:14:30 --> Hooks Class Initialized
DEBUG - 2014-01-18 10:14:30 --> Utf8 Class Initialized
DEBUG - 2014-01-18 10:14:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 10:14:30 --> URI Class Initialized
DEBUG - 2014-01-18 10:14:30 --> Router Class Initialized
DEBUG - 2014-01-18 10:14:30 --> Output Class Initialized
DEBUG - 2014-01-18 10:14:30 --> Security Class Initialized
DEBUG - 2014-01-18 10:14:30 --> Input Class Initialized
DEBUG - 2014-01-18 10:14:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 10:14:30 --> Language Class Initialized
DEBUG - 2014-01-18 10:14:30 --> Loader Class Initialized
DEBUG - 2014-01-18 10:14:30 --> Helper loaded: url_helper
DEBUG - 2014-01-18 10:14:30 --> Helper loaded: form_helper
DEBUG - 2014-01-18 10:14:30 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 10:14:30 --> Database Driver Class Initialized
DEBUG - 2014-01-18 10:14:30 --> Session Class Initialized
DEBUG - 2014-01-18 10:14:30 --> Helper loaded: string_helper
DEBUG - 2014-01-18 10:14:30 --> Session routines successfully run
DEBUG - 2014-01-18 10:14:30 --> User Agent Class Initialized
DEBUG - 2014-01-18 10:14:30 --> Form Validation Class Initialized
DEBUG - 2014-01-18 10:14:30 --> Model Class Initialized
DEBUG - 2014-01-18 10:14:30 --> Model Class Initialized
DEBUG - 2014-01-18 10:14:30 --> Controller Class Initialized
DEBUG - 2014-01-18 10:14:30 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 10:14:30 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 10:14:30 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 10:14:30 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 10:14:30 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 10:14:30 --> Final output sent to browser
DEBUG - 2014-01-18 10:14:30 --> Total execution time: 0.0634
DEBUG - 2014-01-18 10:14:33 --> Config Class Initialized
DEBUG - 2014-01-18 10:14:33 --> Hooks Class Initialized
DEBUG - 2014-01-18 10:14:33 --> Utf8 Class Initialized
DEBUG - 2014-01-18 10:14:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 10:14:33 --> URI Class Initialized
DEBUG - 2014-01-18 10:14:33 --> Router Class Initialized
DEBUG - 2014-01-18 10:14:33 --> Output Class Initialized
DEBUG - 2014-01-18 10:14:33 --> Security Class Initialized
DEBUG - 2014-01-18 10:14:33 --> Input Class Initialized
DEBUG - 2014-01-18 10:14:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 10:14:33 --> Language Class Initialized
DEBUG - 2014-01-18 10:14:33 --> Loader Class Initialized
DEBUG - 2014-01-18 10:14:33 --> Helper loaded: url_helper
DEBUG - 2014-01-18 10:14:33 --> Helper loaded: form_helper
DEBUG - 2014-01-18 10:14:33 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 10:14:33 --> Database Driver Class Initialized
DEBUG - 2014-01-18 10:14:33 --> Session Class Initialized
DEBUG - 2014-01-18 10:14:33 --> Helper loaded: string_helper
DEBUG - 2014-01-18 10:14:33 --> Session routines successfully run
DEBUG - 2014-01-18 10:14:33 --> User Agent Class Initialized
DEBUG - 2014-01-18 10:14:33 --> Form Validation Class Initialized
DEBUG - 2014-01-18 10:14:33 --> Model Class Initialized
DEBUG - 2014-01-18 10:14:33 --> Model Class Initialized
DEBUG - 2014-01-18 10:14:33 --> Controller Class Initialized
DEBUG - 2014-01-18 10:14:33 --> Model Class Initialized
DEBUG - 2014-01-18 10:14:33 --> File loaded: application/views/user/edytuj.php
DEBUG - 2014-01-18 10:14:33 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 10:14:33 --> Final output sent to browser
DEBUG - 2014-01-18 10:14:33 --> Total execution time: 0.0614
DEBUG - 2014-01-18 10:14:38 --> Config Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Hooks Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Utf8 Class Initialized
DEBUG - 2014-01-18 10:14:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 10:14:38 --> URI Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Router Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Output Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Security Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Input Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 10:14:38 --> Language Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Loader Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Helper loaded: url_helper
DEBUG - 2014-01-18 10:14:38 --> Helper loaded: form_helper
DEBUG - 2014-01-18 10:14:38 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 10:14:38 --> Database Driver Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Session Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Helper loaded: string_helper
DEBUG - 2014-01-18 10:14:38 --> Session routines successfully run
DEBUG - 2014-01-18 10:14:38 --> User Agent Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Form Validation Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Model Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Model Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Controller Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Model Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 10:14:38 --> Config Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Hooks Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Utf8 Class Initialized
DEBUG - 2014-01-18 10:14:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 10:14:38 --> URI Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Router Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Output Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Security Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Input Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 10:14:38 --> Language Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Loader Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Helper loaded: url_helper
DEBUG - 2014-01-18 10:14:38 --> Helper loaded: form_helper
DEBUG - 2014-01-18 10:14:38 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 10:14:38 --> Database Driver Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Session Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Helper loaded: string_helper
DEBUG - 2014-01-18 10:14:38 --> Session routines successfully run
DEBUG - 2014-01-18 10:14:38 --> User Agent Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Form Validation Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Model Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Model Class Initialized
DEBUG - 2014-01-18 10:14:38 --> Controller Class Initialized
DEBUG - 2014-01-18 10:14:38 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 10:14:38 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 10:14:38 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 10:14:38 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 10:14:38 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 10:14:38 --> Final output sent to browser
DEBUG - 2014-01-18 10:14:38 --> Total execution time: 0.0605
DEBUG - 2014-01-18 10:14:46 --> Config Class Initialized
DEBUG - 2014-01-18 10:14:46 --> Hooks Class Initialized
DEBUG - 2014-01-18 10:14:46 --> Utf8 Class Initialized
DEBUG - 2014-01-18 10:14:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 10:14:46 --> URI Class Initialized
DEBUG - 2014-01-18 10:14:46 --> Router Class Initialized
DEBUG - 2014-01-18 10:14:46 --> Output Class Initialized
DEBUG - 2014-01-18 10:14:46 --> Security Class Initialized
DEBUG - 2014-01-18 10:14:46 --> Input Class Initialized
DEBUG - 2014-01-18 10:14:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 10:14:46 --> Language Class Initialized
DEBUG - 2014-01-18 10:14:46 --> Loader Class Initialized
DEBUG - 2014-01-18 10:14:46 --> Helper loaded: url_helper
DEBUG - 2014-01-18 10:14:46 --> Helper loaded: form_helper
DEBUG - 2014-01-18 10:14:46 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 10:14:46 --> Database Driver Class Initialized
DEBUG - 2014-01-18 10:14:46 --> Session Class Initialized
DEBUG - 2014-01-18 10:14:46 --> Helper loaded: string_helper
DEBUG - 2014-01-18 10:14:46 --> Session routines successfully run
DEBUG - 2014-01-18 10:14:46 --> User Agent Class Initialized
DEBUG - 2014-01-18 10:14:46 --> Form Validation Class Initialized
DEBUG - 2014-01-18 10:14:46 --> Model Class Initialized
DEBUG - 2014-01-18 10:14:46 --> Model Class Initialized
DEBUG - 2014-01-18 10:14:46 --> Controller Class Initialized
DEBUG - 2014-01-18 10:14:46 --> File loaded: application/views/user/podglad.php
DEBUG - 2014-01-18 10:14:46 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 10:14:46 --> Final output sent to browser
DEBUG - 2014-01-18 10:14:46 --> Total execution time: 0.0649
DEBUG - 2014-01-18 10:15:47 --> Config Class Initialized
DEBUG - 2014-01-18 10:15:47 --> Hooks Class Initialized
DEBUG - 2014-01-18 10:15:47 --> Utf8 Class Initialized
DEBUG - 2014-01-18 10:15:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 10:15:47 --> URI Class Initialized
DEBUG - 2014-01-18 10:15:47 --> Router Class Initialized
DEBUG - 2014-01-18 10:15:47 --> Output Class Initialized
DEBUG - 2014-01-18 10:15:47 --> Security Class Initialized
DEBUG - 2014-01-18 10:15:47 --> Input Class Initialized
DEBUG - 2014-01-18 10:15:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 10:15:47 --> Language Class Initialized
DEBUG - 2014-01-18 10:15:47 --> Loader Class Initialized
DEBUG - 2014-01-18 10:15:47 --> Helper loaded: url_helper
DEBUG - 2014-01-18 10:15:47 --> Helper loaded: form_helper
DEBUG - 2014-01-18 10:15:47 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 10:15:47 --> Database Driver Class Initialized
DEBUG - 2014-01-18 10:15:47 --> Session Class Initialized
DEBUG - 2014-01-18 10:15:47 --> Helper loaded: string_helper
DEBUG - 2014-01-18 10:15:47 --> Session routines successfully run
DEBUG - 2014-01-18 10:15:47 --> User Agent Class Initialized
DEBUG - 2014-01-18 10:15:47 --> Form Validation Class Initialized
DEBUG - 2014-01-18 10:15:47 --> Model Class Initialized
DEBUG - 2014-01-18 10:15:47 --> Model Class Initialized
DEBUG - 2014-01-18 10:15:47 --> Controller Class Initialized
DEBUG - 2014-01-18 10:15:47 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 10:15:47 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 10:15:47 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 10:15:47 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 10:15:47 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 10:15:47 --> Final output sent to browser
DEBUG - 2014-01-18 10:15:47 --> Total execution time: 0.0698
DEBUG - 2014-01-18 10:15:50 --> Config Class Initialized
DEBUG - 2014-01-18 10:15:50 --> Hooks Class Initialized
DEBUG - 2014-01-18 10:15:50 --> Utf8 Class Initialized
DEBUG - 2014-01-18 10:15:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 10:15:50 --> URI Class Initialized
DEBUG - 2014-01-18 10:15:50 --> Router Class Initialized
DEBUG - 2014-01-18 10:15:50 --> Output Class Initialized
DEBUG - 2014-01-18 10:15:50 --> Security Class Initialized
DEBUG - 2014-01-18 10:15:50 --> Input Class Initialized
DEBUG - 2014-01-18 10:15:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 10:15:50 --> Language Class Initialized
DEBUG - 2014-01-18 10:15:50 --> Loader Class Initialized
DEBUG - 2014-01-18 10:15:50 --> Helper loaded: url_helper
DEBUG - 2014-01-18 10:15:50 --> Helper loaded: form_helper
DEBUG - 2014-01-18 10:15:50 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 10:15:50 --> Database Driver Class Initialized
DEBUG - 2014-01-18 10:15:50 --> Session Class Initialized
DEBUG - 2014-01-18 10:15:50 --> Helper loaded: string_helper
DEBUG - 2014-01-18 10:15:50 --> Session routines successfully run
DEBUG - 2014-01-18 10:15:50 --> User Agent Class Initialized
DEBUG - 2014-01-18 10:15:50 --> Form Validation Class Initialized
DEBUG - 2014-01-18 10:15:50 --> Model Class Initialized
DEBUG - 2014-01-18 10:15:50 --> Model Class Initialized
DEBUG - 2014-01-18 10:15:50 --> Controller Class Initialized
DEBUG - 2014-01-18 10:15:50 --> Model Class Initialized
DEBUG - 2014-01-18 10:15:50 --> File loaded: application/views/user/dodaj.php
DEBUG - 2014-01-18 10:15:50 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 10:15:50 --> Final output sent to browser
DEBUG - 2014-01-18 10:15:50 --> Total execution time: 0.0639
DEBUG - 2014-01-18 10:17:04 --> Config Class Initialized
DEBUG - 2014-01-18 10:17:04 --> Hooks Class Initialized
DEBUG - 2014-01-18 10:17:04 --> Utf8 Class Initialized
DEBUG - 2014-01-18 10:17:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 10:17:04 --> URI Class Initialized
DEBUG - 2014-01-18 10:17:04 --> Router Class Initialized
DEBUG - 2014-01-18 10:17:04 --> Output Class Initialized
DEBUG - 2014-01-18 10:17:04 --> Security Class Initialized
DEBUG - 2014-01-18 10:17:04 --> Input Class Initialized
DEBUG - 2014-01-18 10:17:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 10:17:04 --> Language Class Initialized
DEBUG - 2014-01-18 10:17:04 --> Loader Class Initialized
DEBUG - 2014-01-18 10:17:04 --> Helper loaded: url_helper
DEBUG - 2014-01-18 10:17:04 --> Helper loaded: form_helper
DEBUG - 2014-01-18 10:17:04 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 10:17:04 --> Database Driver Class Initialized
DEBUG - 2014-01-18 10:17:04 --> Session Class Initialized
DEBUG - 2014-01-18 10:17:04 --> Helper loaded: string_helper
DEBUG - 2014-01-18 10:17:04 --> Session routines successfully run
DEBUG - 2014-01-18 10:17:04 --> User Agent Class Initialized
DEBUG - 2014-01-18 10:17:04 --> Form Validation Class Initialized
DEBUG - 2014-01-18 10:17:04 --> Model Class Initialized
DEBUG - 2014-01-18 10:17:04 --> Model Class Initialized
DEBUG - 2014-01-18 10:17:04 --> Controller Class Initialized
DEBUG - 2014-01-18 10:17:04 --> Model Class Initialized
DEBUG - 2014-01-18 10:17:04 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 10:17:04 --> Model Class Initialized
ERROR - 2014-01-18 10:17:06 --> Severity: Notice  --> Undefined index: e-mail C:\wamp\www\Windykator1\application\models\users.php 293
DEBUG - 2014-01-18 10:17:06 --> Config Class Initialized
DEBUG - 2014-01-18 10:17:06 --> Hooks Class Initialized
DEBUG - 2014-01-18 10:17:06 --> Utf8 Class Initialized
DEBUG - 2014-01-18 10:17:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 10:17:06 --> URI Class Initialized
DEBUG - 2014-01-18 10:17:06 --> Router Class Initialized
DEBUG - 2014-01-18 10:17:06 --> Output Class Initialized
DEBUG - 2014-01-18 10:17:06 --> Security Class Initialized
DEBUG - 2014-01-18 10:17:06 --> Input Class Initialized
DEBUG - 2014-01-18 10:17:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 10:17:06 --> Language Class Initialized
DEBUG - 2014-01-18 10:17:06 --> Loader Class Initialized
DEBUG - 2014-01-18 10:17:06 --> Helper loaded: url_helper
DEBUG - 2014-01-18 10:17:06 --> Helper loaded: form_helper
DEBUG - 2014-01-18 10:17:06 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 10:17:06 --> Database Driver Class Initialized
DEBUG - 2014-01-18 10:17:06 --> Session Class Initialized
DEBUG - 2014-01-18 10:17:06 --> Helper loaded: string_helper
DEBUG - 2014-01-18 10:17:06 --> Session routines successfully run
DEBUG - 2014-01-18 10:17:06 --> User Agent Class Initialized
DEBUG - 2014-01-18 10:17:06 --> Form Validation Class Initialized
DEBUG - 2014-01-18 10:17:06 --> Model Class Initialized
DEBUG - 2014-01-18 10:17:06 --> Model Class Initialized
DEBUG - 2014-01-18 10:17:06 --> Controller Class Initialized
DEBUG - 2014-01-18 10:17:06 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 10:17:06 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 10:17:06 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 10:17:06 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 10:17:06 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 10:17:06 --> Final output sent to browser
DEBUG - 2014-01-18 10:17:06 --> Total execution time: 0.0772
DEBUG - 2014-01-18 10:17:22 --> Config Class Initialized
DEBUG - 2014-01-18 10:17:22 --> Hooks Class Initialized
DEBUG - 2014-01-18 10:17:22 --> Utf8 Class Initialized
DEBUG - 2014-01-18 10:17:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 10:17:22 --> URI Class Initialized
DEBUG - 2014-01-18 10:17:22 --> Router Class Initialized
DEBUG - 2014-01-18 10:17:22 --> Output Class Initialized
DEBUG - 2014-01-18 10:17:22 --> Security Class Initialized
DEBUG - 2014-01-18 10:17:22 --> Input Class Initialized
DEBUG - 2014-01-18 10:17:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 10:17:22 --> Language Class Initialized
DEBUG - 2014-01-18 10:17:22 --> Loader Class Initialized
DEBUG - 2014-01-18 10:17:22 --> Helper loaded: url_helper
DEBUG - 2014-01-18 10:17:22 --> Helper loaded: form_helper
DEBUG - 2014-01-18 10:17:22 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 10:17:22 --> Database Driver Class Initialized
DEBUG - 2014-01-18 10:17:22 --> Session Class Initialized
DEBUG - 2014-01-18 10:17:22 --> Helper loaded: string_helper
DEBUG - 2014-01-18 10:17:22 --> Session routines successfully run
DEBUG - 2014-01-18 10:17:22 --> User Agent Class Initialized
DEBUG - 2014-01-18 10:17:22 --> Form Validation Class Initialized
DEBUG - 2014-01-18 10:17:22 --> Model Class Initialized
DEBUG - 2014-01-18 10:17:22 --> Model Class Initialized
DEBUG - 2014-01-18 10:17:22 --> Controller Class Initialized
DEBUG - 2014-01-18 10:17:22 --> File loaded: application/views/user/podglad.php
DEBUG - 2014-01-18 10:17:22 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 10:17:22 --> Final output sent to browser
DEBUG - 2014-01-18 10:17:22 --> Total execution time: 0.0630
DEBUG - 2014-01-18 14:13:24 --> Config Class Initialized
DEBUG - 2014-01-18 14:13:24 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:13:24 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:13:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:13:24 --> URI Class Initialized
DEBUG - 2014-01-18 14:13:24 --> Router Class Initialized
DEBUG - 2014-01-18 14:13:24 --> No URI present. Default controller set.
DEBUG - 2014-01-18 14:13:24 --> Output Class Initialized
DEBUG - 2014-01-18 14:13:24 --> Security Class Initialized
DEBUG - 2014-01-18 14:13:24 --> Input Class Initialized
DEBUG - 2014-01-18 14:13:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:13:24 --> Language Class Initialized
DEBUG - 2014-01-18 14:13:24 --> Loader Class Initialized
DEBUG - 2014-01-18 14:13:24 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:13:24 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:13:24 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:13:24 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:13:24 --> Session Class Initialized
DEBUG - 2014-01-18 14:13:24 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:13:24 --> A session cookie was not found.
DEBUG - 2014-01-18 14:13:24 --> Session routines successfully run
DEBUG - 2014-01-18 14:13:24 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:13:24 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:13:24 --> Model Class Initialized
DEBUG - 2014-01-18 14:13:24 --> Model Class Initialized
DEBUG - 2014-01-18 14:13:24 --> Controller Class Initialized
DEBUG - 2014-01-18 14:13:24 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 14:13:24 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:13:24 --> Final output sent to browser
DEBUG - 2014-01-18 14:13:24 --> Total execution time: 0.2879
DEBUG - 2014-01-18 14:13:28 --> Config Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:13:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:13:28 --> URI Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Router Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Output Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Security Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Input Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:13:28 --> Language Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Loader Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:13:28 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:13:28 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:13:28 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Session Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:13:28 --> Session routines successfully run
DEBUG - 2014-01-18 14:13:28 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Model Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Model Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Controller Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 14:13:28 --> Config Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:13:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:13:28 --> URI Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Router Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Output Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Security Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Input Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:13:28 --> Language Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Loader Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:13:28 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:13:28 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:13:28 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Session Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:13:28 --> Session routines successfully run
DEBUG - 2014-01-18 14:13:28 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Model Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Model Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Controller Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Model Class Initialized
DEBUG - 2014-01-18 14:13:28 --> Model Class Initialized
DEBUG - 2014-01-18 14:13:29 --> File loaded: application/views/wniosek/lista.php
DEBUG - 2014-01-18 14:13:29 --> File loaded: application/views/user/aktualnosci.php
DEBUG - 2014-01-18 14:13:29 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:13:29 --> Final output sent to browser
DEBUG - 2014-01-18 14:13:29 --> Total execution time: 0.4576
DEBUG - 2014-01-18 14:13:31 --> Config Class Initialized
DEBUG - 2014-01-18 14:13:31 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:13:31 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:13:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:13:31 --> URI Class Initialized
DEBUG - 2014-01-18 14:13:31 --> Router Class Initialized
DEBUG - 2014-01-18 14:13:31 --> Output Class Initialized
DEBUG - 2014-01-18 14:13:31 --> Security Class Initialized
DEBUG - 2014-01-18 14:13:31 --> Input Class Initialized
DEBUG - 2014-01-18 14:13:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:13:31 --> Language Class Initialized
DEBUG - 2014-01-18 14:13:31 --> Loader Class Initialized
DEBUG - 2014-01-18 14:13:31 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:13:31 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:13:31 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:13:31 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:13:31 --> Session Class Initialized
DEBUG - 2014-01-18 14:13:31 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:13:31 --> Session routines successfully run
DEBUG - 2014-01-18 14:13:31 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:13:31 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:13:31 --> Model Class Initialized
DEBUG - 2014-01-18 14:13:31 --> Model Class Initialized
DEBUG - 2014-01-18 14:13:31 --> Controller Class Initialized
DEBUG - 2014-01-18 14:13:31 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 14:13:31 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 14:13:31 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 14:13:31 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 14:13:31 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:13:31 --> Final output sent to browser
DEBUG - 2014-01-18 14:13:31 --> Total execution time: 0.0743
DEBUG - 2014-01-18 14:16:28 --> Config Class Initialized
DEBUG - 2014-01-18 14:16:28 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:16:28 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:16:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:16:28 --> URI Class Initialized
DEBUG - 2014-01-18 14:16:28 --> Router Class Initialized
DEBUG - 2014-01-18 14:16:28 --> Output Class Initialized
DEBUG - 2014-01-18 14:16:28 --> Security Class Initialized
DEBUG - 2014-01-18 14:16:28 --> Input Class Initialized
DEBUG - 2014-01-18 14:16:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:16:28 --> Language Class Initialized
DEBUG - 2014-01-18 14:16:28 --> Loader Class Initialized
DEBUG - 2014-01-18 14:16:28 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:16:28 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:16:28 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:16:28 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:16:28 --> Session Class Initialized
DEBUG - 2014-01-18 14:16:28 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:16:28 --> Session routines successfully run
DEBUG - 2014-01-18 14:16:28 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:16:28 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:16:28 --> Model Class Initialized
DEBUG - 2014-01-18 14:16:28 --> Model Class Initialized
DEBUG - 2014-01-18 14:16:28 --> Controller Class Initialized
DEBUG - 2014-01-18 14:16:28 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 14:16:28 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 14:16:28 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 14:16:28 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 14:16:28 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:16:28 --> Final output sent to browser
DEBUG - 2014-01-18 14:16:28 --> Total execution time: 0.0644
DEBUG - 2014-01-18 14:16:30 --> Config Class Initialized
DEBUG - 2014-01-18 14:16:30 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:16:30 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:16:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:16:30 --> URI Class Initialized
DEBUG - 2014-01-18 14:16:30 --> Router Class Initialized
DEBUG - 2014-01-18 14:16:30 --> Output Class Initialized
DEBUG - 2014-01-18 14:16:30 --> Security Class Initialized
DEBUG - 2014-01-18 14:16:30 --> Input Class Initialized
DEBUG - 2014-01-18 14:16:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:16:30 --> Language Class Initialized
DEBUG - 2014-01-18 14:16:30 --> Loader Class Initialized
DEBUG - 2014-01-18 14:16:30 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:16:30 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:16:30 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:16:30 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:16:30 --> Session Class Initialized
DEBUG - 2014-01-18 14:16:30 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:16:30 --> Session routines successfully run
DEBUG - 2014-01-18 14:16:30 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:16:30 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:16:30 --> Model Class Initialized
DEBUG - 2014-01-18 14:16:30 --> Model Class Initialized
DEBUG - 2014-01-18 14:16:30 --> Controller Class Initialized
DEBUG - 2014-01-18 14:16:30 --> File loaded: application/views/user/podglad.php
DEBUG - 2014-01-18 14:16:30 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:16:30 --> Final output sent to browser
DEBUG - 2014-01-18 14:16:30 --> Total execution time: 0.0922
DEBUG - 2014-01-18 14:16:32 --> Config Class Initialized
DEBUG - 2014-01-18 14:16:32 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:16:32 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:16:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:16:32 --> URI Class Initialized
DEBUG - 2014-01-18 14:16:32 --> Router Class Initialized
DEBUG - 2014-01-18 14:16:32 --> Output Class Initialized
DEBUG - 2014-01-18 14:16:32 --> Security Class Initialized
DEBUG - 2014-01-18 14:16:32 --> Input Class Initialized
DEBUG - 2014-01-18 14:16:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:16:32 --> Language Class Initialized
DEBUG - 2014-01-18 14:16:32 --> Loader Class Initialized
DEBUG - 2014-01-18 14:16:32 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:16:32 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:16:32 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:16:32 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:16:32 --> Session Class Initialized
DEBUG - 2014-01-18 14:16:32 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:16:32 --> Session routines successfully run
DEBUG - 2014-01-18 14:16:32 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:16:32 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:16:32 --> Model Class Initialized
DEBUG - 2014-01-18 14:16:32 --> Model Class Initialized
DEBUG - 2014-01-18 14:16:32 --> Controller Class Initialized
DEBUG - 2014-01-18 14:16:32 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 14:16:32 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 14:16:32 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 14:16:32 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 14:16:32 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:16:32 --> Final output sent to browser
DEBUG - 2014-01-18 14:16:32 --> Total execution time: 0.0781
DEBUG - 2014-01-18 14:16:33 --> Config Class Initialized
DEBUG - 2014-01-18 14:16:33 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:16:33 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:16:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:16:33 --> URI Class Initialized
DEBUG - 2014-01-18 14:16:33 --> Router Class Initialized
DEBUG - 2014-01-18 14:16:33 --> Output Class Initialized
DEBUG - 2014-01-18 14:16:33 --> Security Class Initialized
DEBUG - 2014-01-18 14:16:33 --> Input Class Initialized
DEBUG - 2014-01-18 14:16:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:16:33 --> Language Class Initialized
DEBUG - 2014-01-18 14:16:33 --> Loader Class Initialized
DEBUG - 2014-01-18 14:16:33 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:16:33 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:16:33 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:16:33 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:16:34 --> Session Class Initialized
DEBUG - 2014-01-18 14:16:34 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:16:34 --> Session routines successfully run
DEBUG - 2014-01-18 14:16:34 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:16:34 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:16:34 --> Model Class Initialized
DEBUG - 2014-01-18 14:16:34 --> Model Class Initialized
DEBUG - 2014-01-18 14:16:34 --> Controller Class Initialized
DEBUG - 2014-01-18 14:16:34 --> Model Class Initialized
DEBUG - 2014-01-18 14:16:34 --> File loaded: application/views/user/edytuj.php
DEBUG - 2014-01-18 14:16:34 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:16:34 --> Final output sent to browser
DEBUG - 2014-01-18 14:16:34 --> Total execution time: 0.0937
DEBUG - 2014-01-18 14:16:36 --> Config Class Initialized
DEBUG - 2014-01-18 14:16:36 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:16:36 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:16:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:16:36 --> URI Class Initialized
DEBUG - 2014-01-18 14:16:36 --> Router Class Initialized
DEBUG - 2014-01-18 14:16:36 --> Output Class Initialized
DEBUG - 2014-01-18 14:16:36 --> Security Class Initialized
DEBUG - 2014-01-18 14:16:36 --> Input Class Initialized
DEBUG - 2014-01-18 14:16:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:16:36 --> Language Class Initialized
DEBUG - 2014-01-18 14:16:36 --> Loader Class Initialized
DEBUG - 2014-01-18 14:16:36 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:16:36 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:16:36 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:16:36 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:16:36 --> Session Class Initialized
DEBUG - 2014-01-18 14:16:36 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:16:36 --> Session routines successfully run
DEBUG - 2014-01-18 14:16:36 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:16:36 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:16:36 --> Model Class Initialized
DEBUG - 2014-01-18 14:16:36 --> Model Class Initialized
DEBUG - 2014-01-18 14:16:36 --> Controller Class Initialized
DEBUG - 2014-01-18 14:16:36 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 14:16:36 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 14:16:36 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 14:16:36 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 14:16:36 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:16:36 --> Final output sent to browser
DEBUG - 2014-01-18 14:16:36 --> Total execution time: 0.0945
DEBUG - 2014-01-18 14:16:38 --> Config Class Initialized
DEBUG - 2014-01-18 14:16:38 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:16:38 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:16:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:16:38 --> URI Class Initialized
DEBUG - 2014-01-18 14:16:38 --> Router Class Initialized
DEBUG - 2014-01-18 14:16:38 --> Output Class Initialized
DEBUG - 2014-01-18 14:16:38 --> Security Class Initialized
DEBUG - 2014-01-18 14:16:38 --> Input Class Initialized
DEBUG - 2014-01-18 14:16:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:16:38 --> Language Class Initialized
DEBUG - 2014-01-18 14:16:38 --> Loader Class Initialized
DEBUG - 2014-01-18 14:16:38 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:16:38 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:16:38 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:16:38 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:16:38 --> Session Class Initialized
DEBUG - 2014-01-18 14:16:38 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:16:38 --> Session routines successfully run
DEBUG - 2014-01-18 14:16:38 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:16:38 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:16:38 --> Model Class Initialized
DEBUG - 2014-01-18 14:16:38 --> Model Class Initialized
DEBUG - 2014-01-18 14:16:38 --> Controller Class Initialized
DEBUG - 2014-01-18 14:16:38 --> Model Class Initialized
DEBUG - 2014-01-18 14:16:38 --> File loaded: application/views/stopa/lista.php
DEBUG - 2014-01-18 14:16:38 --> File loaded: application/views/stopa/zarzadzanie.php
DEBUG - 2014-01-18 14:16:38 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:16:38 --> Final output sent to browser
DEBUG - 2014-01-18 14:16:38 --> Total execution time: 0.2227
DEBUG - 2014-01-18 14:27:28 --> Config Class Initialized
DEBUG - 2014-01-18 14:27:28 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:27:28 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:27:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:27:28 --> URI Class Initialized
DEBUG - 2014-01-18 14:27:28 --> Router Class Initialized
DEBUG - 2014-01-18 14:27:28 --> Output Class Initialized
DEBUG - 2014-01-18 14:27:28 --> Security Class Initialized
DEBUG - 2014-01-18 14:27:28 --> Input Class Initialized
DEBUG - 2014-01-18 14:27:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:27:28 --> Language Class Initialized
DEBUG - 2014-01-18 14:27:28 --> Loader Class Initialized
DEBUG - 2014-01-18 14:27:28 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:27:28 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:27:28 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:27:28 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:27:28 --> Session Class Initialized
DEBUG - 2014-01-18 14:27:28 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:27:28 --> Session routines successfully run
DEBUG - 2014-01-18 14:27:28 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:27:28 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:27:28 --> Model Class Initialized
DEBUG - 2014-01-18 14:27:28 --> Model Class Initialized
DEBUG - 2014-01-18 14:27:28 --> Controller Class Initialized
DEBUG - 2014-01-18 14:27:28 --> Config Class Initialized
DEBUG - 2014-01-18 14:27:28 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:27:28 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:27:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:27:28 --> URI Class Initialized
DEBUG - 2014-01-18 14:27:28 --> Router Class Initialized
DEBUG - 2014-01-18 14:27:28 --> No URI present. Default controller set.
DEBUG - 2014-01-18 14:27:28 --> Output Class Initialized
DEBUG - 2014-01-18 14:27:28 --> Security Class Initialized
DEBUG - 2014-01-18 14:27:28 --> Input Class Initialized
DEBUG - 2014-01-18 14:27:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:27:28 --> Language Class Initialized
DEBUG - 2014-01-18 14:27:28 --> Loader Class Initialized
DEBUG - 2014-01-18 14:27:28 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:27:28 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:27:28 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:27:28 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:27:28 --> Session Class Initialized
DEBUG - 2014-01-18 14:27:28 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:27:28 --> Session routines successfully run
DEBUG - 2014-01-18 14:27:28 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:27:28 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:27:28 --> Model Class Initialized
DEBUG - 2014-01-18 14:27:28 --> Model Class Initialized
DEBUG - 2014-01-18 14:27:28 --> Controller Class Initialized
DEBUG - 2014-01-18 14:27:28 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 14:27:28 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:27:28 --> Final output sent to browser
DEBUG - 2014-01-18 14:27:28 --> Total execution time: 0.0499
DEBUG - 2014-01-18 14:30:17 --> Config Class Initialized
DEBUG - 2014-01-18 14:30:17 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:30:17 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:30:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:30:17 --> URI Class Initialized
DEBUG - 2014-01-18 14:30:17 --> Router Class Initialized
DEBUG - 2014-01-18 14:30:17 --> No URI present. Default controller set.
DEBUG - 2014-01-18 14:30:17 --> Output Class Initialized
DEBUG - 2014-01-18 14:30:17 --> Security Class Initialized
DEBUG - 2014-01-18 14:30:17 --> Input Class Initialized
DEBUG - 2014-01-18 14:30:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:30:17 --> Language Class Initialized
DEBUG - 2014-01-18 14:30:17 --> Loader Class Initialized
DEBUG - 2014-01-18 14:30:17 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:30:17 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:30:17 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:30:17 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:30:17 --> Session Class Initialized
DEBUG - 2014-01-18 14:30:17 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:30:17 --> Session routines successfully run
DEBUG - 2014-01-18 14:30:17 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:30:17 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:30:17 --> Model Class Initialized
DEBUG - 2014-01-18 14:30:17 --> Model Class Initialized
DEBUG - 2014-01-18 14:30:17 --> Controller Class Initialized
DEBUG - 2014-01-18 14:30:17 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 14:30:17 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:30:17 --> Final output sent to browser
DEBUG - 2014-01-18 14:30:17 --> Total execution time: 0.0614
DEBUG - 2014-01-18 14:30:23 --> Config Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:30:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:30:23 --> URI Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Router Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Output Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Security Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Input Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:30:23 --> Language Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Loader Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:30:23 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:30:23 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:30:23 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Session Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:30:23 --> Session routines successfully run
DEBUG - 2014-01-18 14:30:23 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Model Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Model Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Controller Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 14:30:23 --> Config Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:30:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:30:23 --> URI Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Router Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Output Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Security Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Input Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:30:23 --> Language Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Loader Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:30:23 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:30:23 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:30:23 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Session Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:30:23 --> Session routines successfully run
DEBUG - 2014-01-18 14:30:23 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Model Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Model Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Controller Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Model Class Initialized
DEBUG - 2014-01-18 14:30:23 --> Model Class Initialized
DEBUG - 2014-01-18 14:30:23 --> File loaded: application/views/wniosek/lista.php
DEBUG - 2014-01-18 14:30:23 --> File loaded: application/views/user/aktualnosci.php
DEBUG - 2014-01-18 14:30:23 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:30:23 --> Final output sent to browser
DEBUG - 2014-01-18 14:30:23 --> Total execution time: 0.0582
DEBUG - 2014-01-18 14:30:25 --> Config Class Initialized
DEBUG - 2014-01-18 14:30:25 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:30:25 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:30:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:30:25 --> URI Class Initialized
DEBUG - 2014-01-18 14:30:25 --> Router Class Initialized
DEBUG - 2014-01-18 14:30:25 --> Output Class Initialized
DEBUG - 2014-01-18 14:30:25 --> Security Class Initialized
DEBUG - 2014-01-18 14:30:25 --> Input Class Initialized
DEBUG - 2014-01-18 14:30:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:30:25 --> Language Class Initialized
DEBUG - 2014-01-18 14:30:25 --> Loader Class Initialized
DEBUG - 2014-01-18 14:30:25 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:30:25 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:30:25 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:30:25 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:30:25 --> Session Class Initialized
DEBUG - 2014-01-18 14:30:25 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:30:25 --> Session routines successfully run
DEBUG - 2014-01-18 14:30:25 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:30:25 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:30:25 --> Model Class Initialized
DEBUG - 2014-01-18 14:30:25 --> Model Class Initialized
DEBUG - 2014-01-18 14:30:25 --> Controller Class Initialized
DEBUG - 2014-01-18 14:30:25 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 14:30:25 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 14:30:25 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 14:30:25 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 14:30:25 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:30:25 --> Final output sent to browser
DEBUG - 2014-01-18 14:30:25 --> Total execution time: 0.0865
DEBUG - 2014-01-18 14:30:27 --> Config Class Initialized
DEBUG - 2014-01-18 14:30:27 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:30:27 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:30:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:30:27 --> URI Class Initialized
DEBUG - 2014-01-18 14:30:27 --> Router Class Initialized
DEBUG - 2014-01-18 14:30:27 --> Output Class Initialized
DEBUG - 2014-01-18 14:30:27 --> Security Class Initialized
DEBUG - 2014-01-18 14:30:27 --> Input Class Initialized
DEBUG - 2014-01-18 14:30:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:30:27 --> Language Class Initialized
DEBUG - 2014-01-18 14:30:27 --> Loader Class Initialized
DEBUG - 2014-01-18 14:30:27 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:30:27 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:30:27 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:30:27 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:30:27 --> Session Class Initialized
DEBUG - 2014-01-18 14:30:27 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:30:27 --> Session routines successfully run
DEBUG - 2014-01-18 14:30:27 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:30:27 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:30:27 --> Model Class Initialized
DEBUG - 2014-01-18 14:30:27 --> Model Class Initialized
DEBUG - 2014-01-18 14:30:27 --> Controller Class Initialized
DEBUG - 2014-01-18 14:30:27 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 14:30:27 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 14:30:27 --> File loaded: application/views/user/listaZablokowanych.php
DEBUG - 2014-01-18 14:30:27 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 14:30:27 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:30:27 --> Final output sent to browser
DEBUG - 2014-01-18 14:30:27 --> Total execution time: 0.0787
DEBUG - 2014-01-18 14:30:32 --> Config Class Initialized
DEBUG - 2014-01-18 14:30:32 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:30:32 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:30:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:30:32 --> URI Class Initialized
DEBUG - 2014-01-18 14:30:32 --> Router Class Initialized
DEBUG - 2014-01-18 14:30:32 --> Output Class Initialized
DEBUG - 2014-01-18 14:30:32 --> Security Class Initialized
DEBUG - 2014-01-18 14:30:32 --> Input Class Initialized
DEBUG - 2014-01-18 14:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:30:32 --> Language Class Initialized
DEBUG - 2014-01-18 14:30:32 --> Loader Class Initialized
DEBUG - 2014-01-18 14:30:32 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:30:32 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:30:32 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:30:32 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:30:32 --> Session Class Initialized
DEBUG - 2014-01-18 14:30:32 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:30:32 --> Session routines successfully run
DEBUG - 2014-01-18 14:30:32 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:30:32 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:30:32 --> Model Class Initialized
DEBUG - 2014-01-18 14:30:32 --> Model Class Initialized
DEBUG - 2014-01-18 14:30:32 --> Controller Class Initialized
DEBUG - 2014-01-18 14:30:32 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 14:30:32 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 14:30:32 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 14:30:32 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 14:30:32 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:30:32 --> Final output sent to browser
DEBUG - 2014-01-18 14:30:32 --> Total execution time: 0.0552
DEBUG - 2014-01-18 14:30:53 --> Config Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:30:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:30:53 --> URI Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Router Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Output Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Security Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Input Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:30:53 --> Language Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Loader Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:30:53 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:30:53 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:30:53 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Session Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:30:53 --> Session routines successfully run
DEBUG - 2014-01-18 14:30:53 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Model Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Model Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Controller Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Config Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:30:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:30:53 --> URI Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Router Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Output Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Security Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Input Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:30:53 --> Language Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Loader Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:30:53 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:30:53 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:30:53 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Session Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:30:53 --> Session routines successfully run
DEBUG - 2014-01-18 14:30:53 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Model Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Model Class Initialized
DEBUG - 2014-01-18 14:30:53 --> Controller Class Initialized
DEBUG - 2014-01-18 14:30:53 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 14:30:53 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 14:30:53 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 14:30:53 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 14:30:53 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:30:53 --> Final output sent to browser
DEBUG - 2014-01-18 14:30:53 --> Total execution time: 0.0635
DEBUG - 2014-01-18 14:30:56 --> Config Class Initialized
DEBUG - 2014-01-18 14:30:56 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:30:56 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:30:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:30:56 --> URI Class Initialized
DEBUG - 2014-01-18 14:30:56 --> Router Class Initialized
DEBUG - 2014-01-18 14:30:56 --> Output Class Initialized
DEBUG - 2014-01-18 14:30:56 --> Security Class Initialized
DEBUG - 2014-01-18 14:30:56 --> Input Class Initialized
DEBUG - 2014-01-18 14:30:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:30:56 --> Language Class Initialized
DEBUG - 2014-01-18 14:30:56 --> Loader Class Initialized
DEBUG - 2014-01-18 14:30:56 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:30:56 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:30:56 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:30:56 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:30:56 --> Session Class Initialized
DEBUG - 2014-01-18 14:30:56 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:30:56 --> Session routines successfully run
DEBUG - 2014-01-18 14:30:56 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:30:56 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:30:56 --> Model Class Initialized
DEBUG - 2014-01-18 14:30:56 --> Model Class Initialized
DEBUG - 2014-01-18 14:30:56 --> Controller Class Initialized
DEBUG - 2014-01-18 14:30:56 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 14:30:56 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 14:30:56 --> File loaded: application/views/user/listaZablokowanych.php
DEBUG - 2014-01-18 14:30:56 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 14:30:56 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:30:56 --> Final output sent to browser
DEBUG - 2014-01-18 14:30:56 --> Total execution time: 0.0720
DEBUG - 2014-01-18 14:31:19 --> Config Class Initialized
DEBUG - 2014-01-18 14:31:19 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:31:19 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:31:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:31:19 --> URI Class Initialized
DEBUG - 2014-01-18 14:31:19 --> Router Class Initialized
DEBUG - 2014-01-18 14:31:19 --> Output Class Initialized
DEBUG - 2014-01-18 14:31:19 --> Security Class Initialized
DEBUG - 2014-01-18 14:31:19 --> Input Class Initialized
DEBUG - 2014-01-18 14:31:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:31:19 --> Language Class Initialized
DEBUG - 2014-01-18 14:31:19 --> Loader Class Initialized
DEBUG - 2014-01-18 14:31:19 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:31:19 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:31:19 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:31:19 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:31:19 --> Session Class Initialized
DEBUG - 2014-01-18 14:31:19 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:31:19 --> Session routines successfully run
DEBUG - 2014-01-18 14:31:19 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:31:19 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:31:19 --> Model Class Initialized
DEBUG - 2014-01-18 14:31:19 --> Model Class Initialized
DEBUG - 2014-01-18 14:31:19 --> Controller Class Initialized
DEBUG - 2014-01-18 14:31:19 --> Config Class Initialized
DEBUG - 2014-01-18 14:31:19 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:31:19 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:31:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:31:19 --> URI Class Initialized
DEBUG - 2014-01-18 14:31:19 --> Router Class Initialized
DEBUG - 2014-01-18 14:31:19 --> No URI present. Default controller set.
DEBUG - 2014-01-18 14:31:19 --> Output Class Initialized
DEBUG - 2014-01-18 14:31:19 --> Security Class Initialized
DEBUG - 2014-01-18 14:31:19 --> Input Class Initialized
DEBUG - 2014-01-18 14:31:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:31:19 --> Language Class Initialized
DEBUG - 2014-01-18 14:31:19 --> Loader Class Initialized
DEBUG - 2014-01-18 14:31:19 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:31:19 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:31:19 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:31:19 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:31:19 --> Session Class Initialized
DEBUG - 2014-01-18 14:31:19 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:31:19 --> Session routines successfully run
DEBUG - 2014-01-18 14:31:19 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:31:19 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:31:19 --> Model Class Initialized
DEBUG - 2014-01-18 14:31:19 --> Model Class Initialized
DEBUG - 2014-01-18 14:31:19 --> Controller Class Initialized
DEBUG - 2014-01-18 14:31:19 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 14:31:19 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:31:19 --> Final output sent to browser
DEBUG - 2014-01-18 14:31:19 --> Total execution time: 0.0462
DEBUG - 2014-01-18 14:32:43 --> Config Class Initialized
DEBUG - 2014-01-18 14:32:43 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:32:43 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:32:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:32:43 --> URI Class Initialized
DEBUG - 2014-01-18 14:32:43 --> Router Class Initialized
DEBUG - 2014-01-18 14:32:43 --> Output Class Initialized
DEBUG - 2014-01-18 14:32:43 --> Security Class Initialized
DEBUG - 2014-01-18 14:32:43 --> Input Class Initialized
DEBUG - 2014-01-18 14:32:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:32:43 --> Language Class Initialized
DEBUG - 2014-01-18 14:32:43 --> Loader Class Initialized
DEBUG - 2014-01-18 14:32:43 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:32:43 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:32:43 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:32:43 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:32:43 --> Session Class Initialized
DEBUG - 2014-01-18 14:32:43 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:32:43 --> Session routines successfully run
DEBUG - 2014-01-18 14:32:43 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:32:43 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:32:43 --> Model Class Initialized
DEBUG - 2014-01-18 14:32:43 --> Model Class Initialized
DEBUG - 2014-01-18 14:32:43 --> Controller Class Initialized
DEBUG - 2014-01-18 14:32:43 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 14:32:43 --> Config Class Initialized
DEBUG - 2014-01-18 14:32:43 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:32:43 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:32:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:32:43 --> URI Class Initialized
DEBUG - 2014-01-18 14:32:43 --> Router Class Initialized
DEBUG - 2014-01-18 14:32:43 --> Output Class Initialized
DEBUG - 2014-01-18 14:32:43 --> Security Class Initialized
DEBUG - 2014-01-18 14:32:43 --> Input Class Initialized
DEBUG - 2014-01-18 14:32:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:32:43 --> Language Class Initialized
DEBUG - 2014-01-18 14:32:43 --> Loader Class Initialized
DEBUG - 2014-01-18 14:32:43 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:32:43 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:32:43 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:32:44 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:32:44 --> Session Class Initialized
DEBUG - 2014-01-18 14:32:44 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:32:44 --> Session routines successfully run
DEBUG - 2014-01-18 14:32:44 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:32:44 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:32:44 --> Model Class Initialized
DEBUG - 2014-01-18 14:32:44 --> Model Class Initialized
DEBUG - 2014-01-18 14:32:44 --> Controller Class Initialized
DEBUG - 2014-01-18 14:32:44 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 14:32:44 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:32:44 --> Final output sent to browser
DEBUG - 2014-01-18 14:32:44 --> Total execution time: 0.0521
DEBUG - 2014-01-18 14:33:50 --> Config Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:33:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:33:50 --> URI Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Router Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Output Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Security Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Input Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:33:50 --> Language Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Loader Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:33:50 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:33:50 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:33:50 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Session Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:33:50 --> Session routines successfully run
DEBUG - 2014-01-18 14:33:50 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Model Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Model Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Controller Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 14:33:50 --> Config Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:33:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:33:50 --> URI Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Router Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Output Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Security Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Input Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:33:50 --> Language Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Loader Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:33:50 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:33:50 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:33:50 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Session Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:33:50 --> Session routines successfully run
DEBUG - 2014-01-18 14:33:50 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Model Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Model Class Initialized
DEBUG - 2014-01-18 14:33:50 --> Controller Class Initialized
DEBUG - 2014-01-18 14:33:50 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 14:33:50 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:33:50 --> Final output sent to browser
DEBUG - 2014-01-18 14:33:50 --> Total execution time: 0.0595
DEBUG - 2014-01-18 14:33:52 --> Config Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:33:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:33:52 --> URI Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Router Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Output Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Security Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Input Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:33:52 --> Language Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Loader Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:33:52 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:33:52 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:33:52 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Session Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:33:52 --> Session routines successfully run
DEBUG - 2014-01-18 14:33:52 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Model Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Model Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Controller Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 14:33:52 --> Config Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:33:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:33:52 --> URI Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Router Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Output Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Security Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Input Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:33:52 --> Language Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Loader Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:33:52 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:33:52 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:33:52 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Session Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:33:52 --> Session routines successfully run
DEBUG - 2014-01-18 14:33:52 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Model Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Model Class Initialized
DEBUG - 2014-01-18 14:33:52 --> Controller Class Initialized
DEBUG - 2014-01-18 14:33:52 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 14:33:52 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:33:52 --> Final output sent to browser
DEBUG - 2014-01-18 14:33:52 --> Total execution time: 0.0511
DEBUG - 2014-01-18 14:34:10 --> Config Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:34:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:34:10 --> URI Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Router Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Output Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Security Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Input Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:34:10 --> Language Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Loader Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:34:10 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:34:10 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:34:10 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Session Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:34:10 --> Session routines successfully run
DEBUG - 2014-01-18 14:34:10 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Model Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Model Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Controller Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 14:34:10 --> Config Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:34:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:34:10 --> URI Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Router Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Output Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Security Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Input Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:34:10 --> Language Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Loader Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:34:10 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:34:10 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:34:10 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Session Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:34:10 --> Session routines successfully run
DEBUG - 2014-01-18 14:34:10 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Model Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Model Class Initialized
DEBUG - 2014-01-18 14:34:10 --> Controller Class Initialized
DEBUG - 2014-01-18 14:34:10 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 14:34:10 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:34:10 --> Final output sent to browser
DEBUG - 2014-01-18 14:34:10 --> Total execution time: 0.0529
DEBUG - 2014-01-18 14:35:35 --> Config Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:35:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:35:35 --> URI Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Router Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Output Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Security Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Input Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:35:35 --> Language Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Loader Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:35:35 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:35:35 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:35:35 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Session Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:35:35 --> Session routines successfully run
DEBUG - 2014-01-18 14:35:35 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Model Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Model Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Controller Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 14:35:35 --> Config Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:35:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:35:35 --> URI Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Router Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Output Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Security Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Input Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:35:35 --> Language Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Loader Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:35:35 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:35:35 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:35:35 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Session Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:35:35 --> Session routines successfully run
DEBUG - 2014-01-18 14:35:35 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Model Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Model Class Initialized
DEBUG - 2014-01-18 14:35:35 --> Controller Class Initialized
DEBUG - 2014-01-18 14:35:35 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 14:35:35 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:35:35 --> Final output sent to browser
DEBUG - 2014-01-18 14:35:35 --> Total execution time: 0.0544
DEBUG - 2014-01-18 14:36:00 --> Config Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:36:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:36:00 --> URI Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Router Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Output Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Security Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Input Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:36:00 --> Language Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Loader Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:36:00 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:36:00 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:36:00 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Session Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:36:00 --> Session routines successfully run
DEBUG - 2014-01-18 14:36:00 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Model Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Model Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Controller Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 14:36:00 --> Config Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:36:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:36:00 --> URI Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Router Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Output Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Security Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Input Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:36:00 --> Language Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Loader Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:36:00 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:36:00 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:36:00 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Session Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:36:00 --> Session routines successfully run
DEBUG - 2014-01-18 14:36:00 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Model Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Model Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Controller Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Model Class Initialized
DEBUG - 2014-01-18 14:36:00 --> Model Class Initialized
DEBUG - 2014-01-18 14:36:00 --> File loaded: application/views/wniosek/lista.php
DEBUG - 2014-01-18 14:36:00 --> File loaded: application/views/user/aktualnosci.php
DEBUG - 2014-01-18 14:36:00 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:36:00 --> Final output sent to browser
DEBUG - 2014-01-18 14:36:00 --> Total execution time: 0.0770
DEBUG - 2014-01-18 14:36:03 --> Config Class Initialized
DEBUG - 2014-01-18 14:36:03 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:36:03 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:36:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:36:03 --> URI Class Initialized
DEBUG - 2014-01-18 14:36:03 --> Router Class Initialized
DEBUG - 2014-01-18 14:36:03 --> Output Class Initialized
DEBUG - 2014-01-18 14:36:03 --> Security Class Initialized
DEBUG - 2014-01-18 14:36:03 --> Input Class Initialized
DEBUG - 2014-01-18 14:36:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:36:03 --> Language Class Initialized
DEBUG - 2014-01-18 14:36:03 --> Loader Class Initialized
DEBUG - 2014-01-18 14:36:03 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:36:03 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:36:03 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:36:03 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:36:03 --> Session Class Initialized
DEBUG - 2014-01-18 14:36:03 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:36:03 --> Session routines successfully run
DEBUG - 2014-01-18 14:36:03 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:36:03 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:36:03 --> Model Class Initialized
DEBUG - 2014-01-18 14:36:03 --> Model Class Initialized
DEBUG - 2014-01-18 14:36:03 --> Controller Class Initialized
DEBUG - 2014-01-18 14:36:03 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 14:36:03 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 14:36:03 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 14:36:03 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 14:36:03 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:36:03 --> Final output sent to browser
DEBUG - 2014-01-18 14:36:03 --> Total execution time: 0.0705
DEBUG - 2014-01-18 14:36:15 --> Config Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:36:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:36:15 --> URI Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Router Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Output Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Security Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Input Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:36:15 --> Language Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Loader Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:36:15 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:36:15 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:36:15 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Session Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:36:15 --> Session routines successfully run
DEBUG - 2014-01-18 14:36:15 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Model Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Model Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Controller Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Config Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:36:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:36:15 --> URI Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Router Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Output Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Security Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Input Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:36:15 --> Language Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Loader Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:36:15 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:36:15 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:36:15 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Session Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:36:15 --> Session routines successfully run
DEBUG - 2014-01-18 14:36:15 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Model Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Model Class Initialized
DEBUG - 2014-01-18 14:36:15 --> Controller Class Initialized
DEBUG - 2014-01-18 14:36:15 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 14:36:15 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 14:36:15 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 14:36:15 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 14:36:15 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:36:15 --> Final output sent to browser
DEBUG - 2014-01-18 14:36:15 --> Total execution time: 0.0692
DEBUG - 2014-01-18 14:36:18 --> Config Class Initialized
DEBUG - 2014-01-18 14:36:18 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:36:18 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:36:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:36:18 --> URI Class Initialized
DEBUG - 2014-01-18 14:36:18 --> Router Class Initialized
DEBUG - 2014-01-18 14:36:18 --> Output Class Initialized
DEBUG - 2014-01-18 14:36:18 --> Security Class Initialized
DEBUG - 2014-01-18 14:36:18 --> Input Class Initialized
DEBUG - 2014-01-18 14:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:36:18 --> Language Class Initialized
DEBUG - 2014-01-18 14:36:18 --> Loader Class Initialized
DEBUG - 2014-01-18 14:36:18 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:36:18 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:36:18 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:36:18 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:36:18 --> Session Class Initialized
DEBUG - 2014-01-18 14:36:18 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:36:18 --> Session routines successfully run
DEBUG - 2014-01-18 14:36:18 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:36:18 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:36:18 --> Model Class Initialized
DEBUG - 2014-01-18 14:36:18 --> Model Class Initialized
DEBUG - 2014-01-18 14:36:18 --> Controller Class Initialized
DEBUG - 2014-01-18 14:36:18 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 14:36:18 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 14:36:18 --> File loaded: application/views/user/listaZablokowanych.php
DEBUG - 2014-01-18 14:36:18 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 14:36:18 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:36:18 --> Final output sent to browser
DEBUG - 2014-01-18 14:36:18 --> Total execution time: 0.0675
DEBUG - 2014-01-18 14:36:26 --> Config Class Initialized
DEBUG - 2014-01-18 14:36:26 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:36:26 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:36:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:36:26 --> URI Class Initialized
DEBUG - 2014-01-18 14:36:26 --> Router Class Initialized
DEBUG - 2014-01-18 14:36:26 --> Output Class Initialized
DEBUG - 2014-01-18 14:36:26 --> Security Class Initialized
DEBUG - 2014-01-18 14:36:26 --> Input Class Initialized
DEBUG - 2014-01-18 14:36:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:36:26 --> Language Class Initialized
DEBUG - 2014-01-18 14:36:26 --> Loader Class Initialized
DEBUG - 2014-01-18 14:36:26 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:36:26 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:36:26 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:36:26 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:36:26 --> Session Class Initialized
DEBUG - 2014-01-18 14:36:26 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:36:26 --> Session routines successfully run
DEBUG - 2014-01-18 14:36:26 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:36:26 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:36:26 --> Model Class Initialized
DEBUG - 2014-01-18 14:36:26 --> Model Class Initialized
DEBUG - 2014-01-18 14:36:26 --> Controller Class Initialized
DEBUG - 2014-01-18 14:36:26 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 14:36:26 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 14:36:26 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 14:36:26 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 14:36:26 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:36:26 --> Final output sent to browser
DEBUG - 2014-01-18 14:36:26 --> Total execution time: 0.0553
DEBUG - 2014-01-18 14:36:33 --> Config Class Initialized
DEBUG - 2014-01-18 14:36:33 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:36:33 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:36:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:36:33 --> URI Class Initialized
DEBUG - 2014-01-18 14:36:33 --> Router Class Initialized
DEBUG - 2014-01-18 14:36:33 --> Output Class Initialized
DEBUG - 2014-01-18 14:36:33 --> Security Class Initialized
DEBUG - 2014-01-18 14:36:33 --> Input Class Initialized
DEBUG - 2014-01-18 14:36:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:36:33 --> Language Class Initialized
DEBUG - 2014-01-18 14:36:33 --> Loader Class Initialized
DEBUG - 2014-01-18 14:36:33 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:36:33 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:36:33 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:36:33 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:36:33 --> Session Class Initialized
DEBUG - 2014-01-18 14:36:33 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:36:33 --> Session routines successfully run
DEBUG - 2014-01-18 14:36:33 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:36:33 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:36:33 --> Model Class Initialized
DEBUG - 2014-01-18 14:36:33 --> Model Class Initialized
DEBUG - 2014-01-18 14:36:33 --> Controller Class Initialized
DEBUG - 2014-01-18 14:36:33 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 14:36:33 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 14:36:33 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 14:36:33 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 14:36:33 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:36:33 --> Final output sent to browser
DEBUG - 2014-01-18 14:36:33 --> Total execution time: 0.0646
DEBUG - 2014-01-18 14:36:36 --> Config Class Initialized
DEBUG - 2014-01-18 14:36:36 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:36:36 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:36:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:36:36 --> URI Class Initialized
DEBUG - 2014-01-18 14:36:36 --> Router Class Initialized
DEBUG - 2014-01-18 14:36:36 --> Output Class Initialized
DEBUG - 2014-01-18 14:36:36 --> Security Class Initialized
DEBUG - 2014-01-18 14:36:36 --> Input Class Initialized
DEBUG - 2014-01-18 14:36:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:36:36 --> Language Class Initialized
DEBUG - 2014-01-18 14:36:36 --> Loader Class Initialized
DEBUG - 2014-01-18 14:36:36 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:36:36 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:36:36 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:36:36 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:36:36 --> Session Class Initialized
DEBUG - 2014-01-18 14:36:36 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:36:36 --> Session routines successfully run
DEBUG - 2014-01-18 14:36:36 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:36:36 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:36:36 --> Model Class Initialized
DEBUG - 2014-01-18 14:36:36 --> Model Class Initialized
DEBUG - 2014-01-18 14:36:36 --> Controller Class Initialized
DEBUG - 2014-01-18 14:36:36 --> Model Class Initialized
DEBUG - 2014-01-18 14:36:36 --> File loaded: application/views/user/dodaj.php
DEBUG - 2014-01-18 14:36:36 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:36:36 --> Final output sent to browser
DEBUG - 2014-01-18 14:36:36 --> Total execution time: 0.0706
DEBUG - 2014-01-18 14:37:13 --> Config Class Initialized
DEBUG - 2014-01-18 14:37:13 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:37:13 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:37:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:37:13 --> URI Class Initialized
DEBUG - 2014-01-18 14:37:13 --> Router Class Initialized
DEBUG - 2014-01-18 14:37:13 --> Output Class Initialized
DEBUG - 2014-01-18 14:37:13 --> Security Class Initialized
DEBUG - 2014-01-18 14:37:13 --> Input Class Initialized
DEBUG - 2014-01-18 14:37:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:37:13 --> Language Class Initialized
DEBUG - 2014-01-18 14:37:13 --> Loader Class Initialized
DEBUG - 2014-01-18 14:37:13 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:37:13 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:37:13 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:37:13 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:37:13 --> Session Class Initialized
DEBUG - 2014-01-18 14:37:13 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:37:13 --> Session routines successfully run
DEBUG - 2014-01-18 14:37:13 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:37:13 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:37:13 --> Model Class Initialized
DEBUG - 2014-01-18 14:37:13 --> Model Class Initialized
DEBUG - 2014-01-18 14:37:13 --> Controller Class Initialized
DEBUG - 2014-01-18 14:37:13 --> Model Class Initialized
DEBUG - 2014-01-18 14:37:13 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 14:37:13 --> File loaded: application/views/user/dodaj.php
DEBUG - 2014-01-18 14:37:13 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:37:13 --> Final output sent to browser
DEBUG - 2014-01-18 14:37:13 --> Total execution time: 0.0585
DEBUG - 2014-01-18 14:37:32 --> Config Class Initialized
DEBUG - 2014-01-18 14:37:32 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:37:32 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:37:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:37:32 --> URI Class Initialized
DEBUG - 2014-01-18 14:37:32 --> Router Class Initialized
DEBUG - 2014-01-18 14:37:32 --> Output Class Initialized
DEBUG - 2014-01-18 14:37:32 --> Security Class Initialized
DEBUG - 2014-01-18 14:37:32 --> Input Class Initialized
DEBUG - 2014-01-18 14:37:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:37:32 --> Language Class Initialized
DEBUG - 2014-01-18 14:37:32 --> Loader Class Initialized
DEBUG - 2014-01-18 14:37:32 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:37:32 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:37:32 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:37:32 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:37:32 --> Session Class Initialized
DEBUG - 2014-01-18 14:37:32 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:37:32 --> Session routines successfully run
DEBUG - 2014-01-18 14:37:32 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:37:32 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:37:32 --> Model Class Initialized
DEBUG - 2014-01-18 14:37:32 --> Model Class Initialized
DEBUG - 2014-01-18 14:37:32 --> Controller Class Initialized
DEBUG - 2014-01-18 14:37:32 --> Model Class Initialized
DEBUG - 2014-01-18 14:37:32 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 14:37:32 --> File loaded: application/views/user/dodaj.php
DEBUG - 2014-01-18 14:37:32 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:37:32 --> Final output sent to browser
DEBUG - 2014-01-18 14:37:32 --> Total execution time: 0.0681
DEBUG - 2014-01-18 14:37:34 --> Config Class Initialized
DEBUG - 2014-01-18 14:37:34 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:37:34 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:37:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:37:34 --> URI Class Initialized
DEBUG - 2014-01-18 14:37:34 --> Router Class Initialized
DEBUG - 2014-01-18 14:37:34 --> Output Class Initialized
DEBUG - 2014-01-18 14:37:34 --> Security Class Initialized
DEBUG - 2014-01-18 14:37:34 --> Input Class Initialized
DEBUG - 2014-01-18 14:37:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:37:34 --> Language Class Initialized
DEBUG - 2014-01-18 14:37:34 --> Loader Class Initialized
DEBUG - 2014-01-18 14:37:34 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:37:34 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:37:34 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:37:34 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:37:34 --> Session Class Initialized
DEBUG - 2014-01-18 14:37:34 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:37:34 --> Session routines successfully run
DEBUG - 2014-01-18 14:37:34 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:37:34 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:37:34 --> Model Class Initialized
DEBUG - 2014-01-18 14:37:34 --> Model Class Initialized
DEBUG - 2014-01-18 14:37:34 --> Controller Class Initialized
DEBUG - 2014-01-18 14:37:34 --> Model Class Initialized
DEBUG - 2014-01-18 14:37:34 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 14:37:34 --> File loaded: application/views/user/dodaj.php
DEBUG - 2014-01-18 14:37:34 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:37:34 --> Final output sent to browser
DEBUG - 2014-01-18 14:37:34 --> Total execution time: 0.0710
DEBUG - 2014-01-18 14:39:22 --> Config Class Initialized
DEBUG - 2014-01-18 14:39:22 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:39:22 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:39:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:39:22 --> URI Class Initialized
DEBUG - 2014-01-18 14:39:22 --> Router Class Initialized
DEBUG - 2014-01-18 14:39:22 --> Output Class Initialized
DEBUG - 2014-01-18 14:39:22 --> Security Class Initialized
DEBUG - 2014-01-18 14:39:22 --> Input Class Initialized
DEBUG - 2014-01-18 14:39:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:39:22 --> Language Class Initialized
DEBUG - 2014-01-18 14:39:22 --> Loader Class Initialized
DEBUG - 2014-01-18 14:39:22 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:39:22 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:39:22 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:39:22 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:39:22 --> Session Class Initialized
DEBUG - 2014-01-18 14:39:22 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:39:22 --> Session routines successfully run
DEBUG - 2014-01-18 14:39:22 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:39:22 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:39:22 --> Model Class Initialized
DEBUG - 2014-01-18 14:39:22 --> Model Class Initialized
DEBUG - 2014-01-18 14:39:22 --> Controller Class Initialized
DEBUG - 2014-01-18 14:39:22 --> Model Class Initialized
DEBUG - 2014-01-18 14:39:22 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 14:39:22 --> Model Class Initialized
ERROR - 2014-01-18 14:39:29 --> Severity: Notice  --> Undefined index: e-mail C:\wamp\www\Windykator1\application\models\users.php 293
DEBUG - 2014-01-18 14:39:29 --> Config Class Initialized
DEBUG - 2014-01-18 14:39:29 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:39:29 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:39:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:39:29 --> URI Class Initialized
DEBUG - 2014-01-18 14:39:29 --> Router Class Initialized
DEBUG - 2014-01-18 14:39:29 --> Output Class Initialized
DEBUG - 2014-01-18 14:39:29 --> Security Class Initialized
DEBUG - 2014-01-18 14:39:29 --> Input Class Initialized
DEBUG - 2014-01-18 14:39:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:39:29 --> Language Class Initialized
DEBUG - 2014-01-18 14:39:29 --> Loader Class Initialized
DEBUG - 2014-01-18 14:39:29 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:39:29 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:39:29 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:39:29 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:39:29 --> Session Class Initialized
DEBUG - 2014-01-18 14:39:29 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:39:29 --> Session routines successfully run
DEBUG - 2014-01-18 14:39:29 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:39:29 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:39:29 --> Model Class Initialized
DEBUG - 2014-01-18 14:39:29 --> Model Class Initialized
DEBUG - 2014-01-18 14:39:29 --> Controller Class Initialized
DEBUG - 2014-01-18 14:39:29 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 14:39:29 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 14:39:29 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 14:39:29 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 14:39:29 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:39:29 --> Final output sent to browser
DEBUG - 2014-01-18 14:39:29 --> Total execution time: 0.0728
DEBUG - 2014-01-18 14:39:46 --> Config Class Initialized
DEBUG - 2014-01-18 14:39:46 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:39:46 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:39:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:39:46 --> URI Class Initialized
DEBUG - 2014-01-18 14:39:46 --> Router Class Initialized
DEBUG - 2014-01-18 14:39:46 --> Output Class Initialized
DEBUG - 2014-01-18 14:39:46 --> Security Class Initialized
DEBUG - 2014-01-18 14:39:46 --> Input Class Initialized
DEBUG - 2014-01-18 14:39:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:39:46 --> Language Class Initialized
DEBUG - 2014-01-18 14:39:46 --> Loader Class Initialized
DEBUG - 2014-01-18 14:39:46 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:39:46 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:39:46 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:39:46 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:39:46 --> Session Class Initialized
DEBUG - 2014-01-18 14:39:46 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:39:46 --> Session routines successfully run
DEBUG - 2014-01-18 14:39:46 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:39:46 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:39:46 --> Model Class Initialized
DEBUG - 2014-01-18 14:39:46 --> Model Class Initialized
DEBUG - 2014-01-18 14:39:46 --> Controller Class Initialized
DEBUG - 2014-01-18 14:39:46 --> File loaded: application/views/user/podglad.php
DEBUG - 2014-01-18 14:39:46 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:39:46 --> Final output sent to browser
DEBUG - 2014-01-18 14:39:46 --> Total execution time: 0.0540
DEBUG - 2014-01-18 14:40:20 --> Config Class Initialized
DEBUG - 2014-01-18 14:40:20 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:40:20 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:40:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:40:20 --> URI Class Initialized
DEBUG - 2014-01-18 14:40:20 --> Router Class Initialized
DEBUG - 2014-01-18 14:40:20 --> Output Class Initialized
DEBUG - 2014-01-18 14:40:20 --> Security Class Initialized
DEBUG - 2014-01-18 14:40:20 --> Input Class Initialized
DEBUG - 2014-01-18 14:40:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:40:20 --> Language Class Initialized
DEBUG - 2014-01-18 14:40:20 --> Loader Class Initialized
DEBUG - 2014-01-18 14:40:20 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:40:20 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:40:20 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:40:20 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:40:20 --> Session Class Initialized
DEBUG - 2014-01-18 14:40:20 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:40:20 --> Session routines successfully run
DEBUG - 2014-01-18 14:40:20 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:40:20 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:40:20 --> Model Class Initialized
DEBUG - 2014-01-18 14:40:20 --> Model Class Initialized
DEBUG - 2014-01-18 14:40:20 --> Controller Class Initialized
DEBUG - 2014-01-18 14:40:20 --> Config Class Initialized
DEBUG - 2014-01-18 14:40:20 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:40:20 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:40:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:40:20 --> URI Class Initialized
DEBUG - 2014-01-18 14:40:20 --> Router Class Initialized
DEBUG - 2014-01-18 14:40:20 --> No URI present. Default controller set.
DEBUG - 2014-01-18 14:40:20 --> Output Class Initialized
DEBUG - 2014-01-18 14:40:20 --> Security Class Initialized
DEBUG - 2014-01-18 14:40:20 --> Input Class Initialized
DEBUG - 2014-01-18 14:40:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:40:20 --> Language Class Initialized
DEBUG - 2014-01-18 14:40:20 --> Loader Class Initialized
DEBUG - 2014-01-18 14:40:20 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:40:20 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:40:20 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:40:20 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:40:20 --> Session Class Initialized
DEBUG - 2014-01-18 14:40:20 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:40:20 --> Session routines successfully run
DEBUG - 2014-01-18 14:40:20 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:40:20 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:40:20 --> Model Class Initialized
DEBUG - 2014-01-18 14:40:20 --> Model Class Initialized
DEBUG - 2014-01-18 14:40:20 --> Controller Class Initialized
DEBUG - 2014-01-18 14:40:20 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 14:40:20 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:40:20 --> Final output sent to browser
DEBUG - 2014-01-18 14:40:20 --> Total execution time: 0.0562
DEBUG - 2014-01-18 14:40:29 --> Config Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:40:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:40:29 --> URI Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Router Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Output Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Security Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Input Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:40:29 --> Language Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Loader Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:40:29 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:40:29 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:40:29 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Session Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:40:29 --> Session routines successfully run
DEBUG - 2014-01-18 14:40:29 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Model Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Model Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Controller Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 14:40:29 --> Config Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:40:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:40:29 --> URI Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Router Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Output Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Security Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Input Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:40:29 --> Language Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Loader Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:40:29 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:40:29 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:40:29 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Session Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:40:29 --> Session routines successfully run
DEBUG - 2014-01-18 14:40:29 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Model Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Model Class Initialized
DEBUG - 2014-01-18 14:40:29 --> Controller Class Initialized
DEBUG - 2014-01-18 14:40:29 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 14:40:29 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:40:29 --> Final output sent to browser
DEBUG - 2014-01-18 14:40:29 --> Total execution time: 0.0539
DEBUG - 2014-01-18 14:41:30 --> Config Class Initialized
DEBUG - 2014-01-18 14:41:30 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:41:30 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:41:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:41:30 --> URI Class Initialized
DEBUG - 2014-01-18 14:41:30 --> Router Class Initialized
DEBUG - 2014-01-18 14:41:30 --> No URI present. Default controller set.
DEBUG - 2014-01-18 14:41:30 --> Output Class Initialized
DEBUG - 2014-01-18 14:41:30 --> Security Class Initialized
DEBUG - 2014-01-18 14:41:30 --> Input Class Initialized
DEBUG - 2014-01-18 14:41:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:41:30 --> Language Class Initialized
DEBUG - 2014-01-18 14:41:30 --> Loader Class Initialized
DEBUG - 2014-01-18 14:41:30 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:41:30 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:41:30 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:41:30 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:41:30 --> Session Class Initialized
DEBUG - 2014-01-18 14:41:30 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:41:30 --> Session routines successfully run
DEBUG - 2014-01-18 14:41:30 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:41:30 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:41:30 --> Model Class Initialized
DEBUG - 2014-01-18 14:41:30 --> Model Class Initialized
DEBUG - 2014-01-18 14:41:30 --> Controller Class Initialized
DEBUG - 2014-01-18 14:41:30 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 14:41:30 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:41:30 --> Final output sent to browser
DEBUG - 2014-01-18 14:41:30 --> Total execution time: 0.0781
DEBUG - 2014-01-18 14:42:32 --> Config Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:42:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:42:32 --> URI Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Router Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Output Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Security Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Input Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:42:32 --> Language Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Loader Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:42:32 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:42:32 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:42:32 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Session Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:42:32 --> Session routines successfully run
DEBUG - 2014-01-18 14:42:32 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Model Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Model Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Controller Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 14:42:32 --> Config Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:42:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:42:32 --> URI Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Router Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Output Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Security Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Input Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:42:32 --> Language Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Loader Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:42:32 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:42:32 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:42:32 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Session Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:42:32 --> Session routines successfully run
DEBUG - 2014-01-18 14:42:32 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Model Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Model Class Initialized
DEBUG - 2014-01-18 14:42:32 --> Controller Class Initialized
DEBUG - 2014-01-18 14:42:32 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 14:42:32 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:42:32 --> Final output sent to browser
DEBUG - 2014-01-18 14:42:32 --> Total execution time: 0.0516
DEBUG - 2014-01-18 14:42:52 --> Config Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:42:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:42:52 --> URI Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Router Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Output Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Security Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Input Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:42:52 --> Language Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Loader Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:42:52 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:42:52 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:42:52 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Session Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:42:52 --> Session routines successfully run
DEBUG - 2014-01-18 14:42:52 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Model Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Model Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Controller Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 14:42:52 --> Config Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:42:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:42:52 --> URI Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Router Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Output Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Security Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Input Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:42:52 --> Language Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Loader Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:42:52 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:42:52 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:42:52 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Session Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:42:52 --> Session routines successfully run
DEBUG - 2014-01-18 14:42:52 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Model Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Model Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Controller Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Model Class Initialized
DEBUG - 2014-01-18 14:42:52 --> Model Class Initialized
DEBUG - 2014-01-18 14:42:52 --> File loaded: application/views/wniosek/lista.php
DEBUG - 2014-01-18 14:42:52 --> File loaded: application/views/user/aktualnosci.php
DEBUG - 2014-01-18 14:42:52 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:42:52 --> Final output sent to browser
DEBUG - 2014-01-18 14:42:52 --> Total execution time: 0.0603
DEBUG - 2014-01-18 14:42:57 --> Config Class Initialized
DEBUG - 2014-01-18 14:42:57 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:42:57 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:42:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:42:57 --> URI Class Initialized
DEBUG - 2014-01-18 14:42:57 --> Router Class Initialized
DEBUG - 2014-01-18 14:42:57 --> Output Class Initialized
DEBUG - 2014-01-18 14:42:57 --> Security Class Initialized
DEBUG - 2014-01-18 14:42:57 --> Input Class Initialized
DEBUG - 2014-01-18 14:42:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:42:57 --> Language Class Initialized
DEBUG - 2014-01-18 14:42:57 --> Loader Class Initialized
DEBUG - 2014-01-18 14:42:57 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:42:57 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:42:57 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:42:57 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:42:57 --> Session Class Initialized
DEBUG - 2014-01-18 14:42:57 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:42:57 --> Session routines successfully run
DEBUG - 2014-01-18 14:42:57 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:42:57 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:42:57 --> Model Class Initialized
DEBUG - 2014-01-18 14:42:57 --> Model Class Initialized
DEBUG - 2014-01-18 14:42:57 --> Controller Class Initialized
DEBUG - 2014-01-18 14:42:57 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 14:42:57 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 14:42:57 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 14:42:57 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 14:42:57 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:42:57 --> Final output sent to browser
DEBUG - 2014-01-18 14:42:57 --> Total execution time: 0.0789
DEBUG - 2014-01-18 14:43:12 --> Config Class Initialized
DEBUG - 2014-01-18 14:43:12 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:43:12 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:43:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:43:12 --> URI Class Initialized
DEBUG - 2014-01-18 14:43:12 --> Router Class Initialized
DEBUG - 2014-01-18 14:43:12 --> Output Class Initialized
DEBUG - 2014-01-18 14:43:12 --> Security Class Initialized
DEBUG - 2014-01-18 14:43:12 --> Input Class Initialized
DEBUG - 2014-01-18 14:43:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:43:12 --> Language Class Initialized
DEBUG - 2014-01-18 14:43:12 --> Loader Class Initialized
DEBUG - 2014-01-18 14:43:12 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:43:12 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:43:12 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:43:12 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:43:12 --> Session Class Initialized
DEBUG - 2014-01-18 14:43:12 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:43:12 --> Session routines successfully run
DEBUG - 2014-01-18 14:43:12 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:43:12 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:43:12 --> Model Class Initialized
DEBUG - 2014-01-18 14:43:12 --> Model Class Initialized
DEBUG - 2014-01-18 14:43:12 --> Controller Class Initialized
DEBUG - 2014-01-18 14:43:12 --> Model Class Initialized
DEBUG - 2014-01-18 14:43:12 --> File loaded: application/views/user/edytuj.php
DEBUG - 2014-01-18 14:43:12 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:43:12 --> Final output sent to browser
DEBUG - 2014-01-18 14:43:12 --> Total execution time: 0.0624
DEBUG - 2014-01-18 14:43:22 --> Config Class Initialized
DEBUG - 2014-01-18 14:43:22 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:43:22 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:43:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:43:22 --> URI Class Initialized
DEBUG - 2014-01-18 14:43:22 --> Router Class Initialized
DEBUG - 2014-01-18 14:43:22 --> Output Class Initialized
DEBUG - 2014-01-18 14:43:22 --> Security Class Initialized
DEBUG - 2014-01-18 14:43:22 --> Input Class Initialized
DEBUG - 2014-01-18 14:43:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:43:22 --> Language Class Initialized
DEBUG - 2014-01-18 14:43:22 --> Loader Class Initialized
DEBUG - 2014-01-18 14:43:22 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:43:22 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:43:22 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:43:22 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:43:22 --> Session Class Initialized
DEBUG - 2014-01-18 14:43:22 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:43:22 --> Session routines successfully run
DEBUG - 2014-01-18 14:43:22 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:43:22 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:43:22 --> Model Class Initialized
DEBUG - 2014-01-18 14:43:22 --> Model Class Initialized
DEBUG - 2014-01-18 14:43:22 --> Controller Class Initialized
DEBUG - 2014-01-18 14:43:22 --> Config Class Initialized
DEBUG - 2014-01-18 14:43:22 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:43:22 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:43:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:43:22 --> URI Class Initialized
DEBUG - 2014-01-18 14:43:22 --> Router Class Initialized
DEBUG - 2014-01-18 14:43:22 --> No URI present. Default controller set.
DEBUG - 2014-01-18 14:43:22 --> Output Class Initialized
DEBUG - 2014-01-18 14:43:22 --> Security Class Initialized
DEBUG - 2014-01-18 14:43:22 --> Input Class Initialized
DEBUG - 2014-01-18 14:43:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:43:22 --> Language Class Initialized
DEBUG - 2014-01-18 14:43:22 --> Loader Class Initialized
DEBUG - 2014-01-18 14:43:22 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:43:22 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:43:22 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:43:22 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:43:22 --> Session Class Initialized
DEBUG - 2014-01-18 14:43:22 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:43:22 --> Session routines successfully run
DEBUG - 2014-01-18 14:43:22 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:43:22 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:43:22 --> Model Class Initialized
DEBUG - 2014-01-18 14:43:22 --> Model Class Initialized
DEBUG - 2014-01-18 14:43:22 --> Controller Class Initialized
DEBUG - 2014-01-18 14:43:22 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 14:43:22 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:43:22 --> Final output sent to browser
DEBUG - 2014-01-18 14:43:22 --> Total execution time: 0.0580
DEBUG - 2014-01-18 14:43:39 --> Config Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:43:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:43:39 --> URI Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Router Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Output Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Security Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Input Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:43:39 --> Language Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Loader Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:43:39 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:43:39 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:43:39 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Session Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:43:39 --> Session routines successfully run
DEBUG - 2014-01-18 14:43:39 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Model Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Model Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Controller Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 14:43:39 --> Config Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:43:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:43:39 --> URI Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Router Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Output Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Security Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Input Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:43:39 --> Language Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Loader Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:43:39 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:43:39 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:43:39 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Session Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:43:39 --> Session routines successfully run
DEBUG - 2014-01-18 14:43:39 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Model Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Model Class Initialized
DEBUG - 2014-01-18 14:43:39 --> Controller Class Initialized
DEBUG - 2014-01-18 14:43:39 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 14:43:39 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:43:39 --> Final output sent to browser
DEBUG - 2014-01-18 14:43:39 --> Total execution time: 0.0542
DEBUG - 2014-01-18 14:44:01 --> Config Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:44:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:44:01 --> URI Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Router Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Output Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Security Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Input Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:44:01 --> Language Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Loader Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:44:01 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:44:01 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:44:01 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Session Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:44:01 --> Session routines successfully run
DEBUG - 2014-01-18 14:44:01 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Model Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Model Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Controller Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 14:44:01 --> Config Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:44:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:44:01 --> URI Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Router Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Output Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Security Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Input Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:44:01 --> Language Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Loader Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:44:01 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:44:01 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:44:01 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Session Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:44:01 --> Session routines successfully run
DEBUG - 2014-01-18 14:44:01 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Model Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Model Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Controller Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Model Class Initialized
DEBUG - 2014-01-18 14:44:01 --> Model Class Initialized
DEBUG - 2014-01-18 14:44:01 --> File loaded: application/views/wniosek/lista.php
DEBUG - 2014-01-18 14:44:01 --> File loaded: application/views/user/aktualnosci.php
DEBUG - 2014-01-18 14:44:01 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:44:01 --> Final output sent to browser
DEBUG - 2014-01-18 14:44:01 --> Total execution time: 0.0685
DEBUG - 2014-01-18 14:44:03 --> Config Class Initialized
DEBUG - 2014-01-18 14:44:03 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:44:03 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:44:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:44:03 --> URI Class Initialized
DEBUG - 2014-01-18 14:44:03 --> Router Class Initialized
DEBUG - 2014-01-18 14:44:03 --> Output Class Initialized
DEBUG - 2014-01-18 14:44:03 --> Security Class Initialized
DEBUG - 2014-01-18 14:44:03 --> Input Class Initialized
DEBUG - 2014-01-18 14:44:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:44:03 --> Language Class Initialized
DEBUG - 2014-01-18 14:44:03 --> Loader Class Initialized
DEBUG - 2014-01-18 14:44:03 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:44:03 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:44:03 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:44:03 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:44:03 --> Session Class Initialized
DEBUG - 2014-01-18 14:44:03 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:44:03 --> Session routines successfully run
DEBUG - 2014-01-18 14:44:03 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:44:03 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:44:03 --> Model Class Initialized
DEBUG - 2014-01-18 14:44:03 --> Model Class Initialized
DEBUG - 2014-01-18 14:44:03 --> Controller Class Initialized
DEBUG - 2014-01-18 14:44:03 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 14:44:03 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 14:44:03 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 14:44:03 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 14:44:03 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:44:03 --> Final output sent to browser
DEBUG - 2014-01-18 14:44:03 --> Total execution time: 0.0638
DEBUG - 2014-01-18 14:44:06 --> Config Class Initialized
DEBUG - 2014-01-18 14:44:06 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:44:06 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:44:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:44:06 --> URI Class Initialized
DEBUG - 2014-01-18 14:44:06 --> Router Class Initialized
DEBUG - 2014-01-18 14:44:06 --> Output Class Initialized
DEBUG - 2014-01-18 14:44:06 --> Security Class Initialized
DEBUG - 2014-01-18 14:44:06 --> Input Class Initialized
DEBUG - 2014-01-18 14:44:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:44:06 --> Language Class Initialized
DEBUG - 2014-01-18 14:44:06 --> Loader Class Initialized
DEBUG - 2014-01-18 14:44:06 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:44:06 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:44:06 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:44:06 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:44:06 --> Session Class Initialized
DEBUG - 2014-01-18 14:44:06 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:44:06 --> Session routines successfully run
DEBUG - 2014-01-18 14:44:06 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:44:06 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:44:06 --> Model Class Initialized
DEBUG - 2014-01-18 14:44:06 --> Model Class Initialized
DEBUG - 2014-01-18 14:44:06 --> Controller Class Initialized
DEBUG - 2014-01-18 14:44:06 --> File loaded: application/views/user/podglad.php
DEBUG - 2014-01-18 14:44:06 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:44:06 --> Final output sent to browser
DEBUG - 2014-01-18 14:44:06 --> Total execution time: 0.0749
DEBUG - 2014-01-18 14:44:18 --> Config Class Initialized
DEBUG - 2014-01-18 14:44:18 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:44:18 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:44:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:44:18 --> URI Class Initialized
DEBUG - 2014-01-18 14:44:18 --> Router Class Initialized
DEBUG - 2014-01-18 14:44:18 --> Output Class Initialized
DEBUG - 2014-01-18 14:44:18 --> Security Class Initialized
DEBUG - 2014-01-18 14:44:18 --> Input Class Initialized
DEBUG - 2014-01-18 14:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:44:18 --> Language Class Initialized
DEBUG - 2014-01-18 14:44:18 --> Loader Class Initialized
DEBUG - 2014-01-18 14:44:18 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:44:18 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:44:18 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:44:18 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:44:18 --> Session Class Initialized
DEBUG - 2014-01-18 14:44:18 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:44:18 --> Session routines successfully run
DEBUG - 2014-01-18 14:44:18 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:44:18 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:44:18 --> Model Class Initialized
DEBUG - 2014-01-18 14:44:18 --> Model Class Initialized
DEBUG - 2014-01-18 14:44:18 --> Controller Class Initialized
DEBUG - 2014-01-18 14:44:18 --> Config Class Initialized
DEBUG - 2014-01-18 14:44:18 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:44:18 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:44:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:44:18 --> URI Class Initialized
DEBUG - 2014-01-18 14:44:18 --> Router Class Initialized
DEBUG - 2014-01-18 14:44:18 --> No URI present. Default controller set.
DEBUG - 2014-01-18 14:44:18 --> Output Class Initialized
DEBUG - 2014-01-18 14:44:18 --> Security Class Initialized
DEBUG - 2014-01-18 14:44:18 --> Input Class Initialized
DEBUG - 2014-01-18 14:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:44:18 --> Language Class Initialized
DEBUG - 2014-01-18 14:44:18 --> Loader Class Initialized
DEBUG - 2014-01-18 14:44:18 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:44:18 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:44:18 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:44:18 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:44:18 --> Session Class Initialized
DEBUG - 2014-01-18 14:44:18 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:44:18 --> Session routines successfully run
DEBUG - 2014-01-18 14:44:18 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:44:18 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:44:18 --> Model Class Initialized
DEBUG - 2014-01-18 14:44:18 --> Model Class Initialized
DEBUG - 2014-01-18 14:44:18 --> Controller Class Initialized
DEBUG - 2014-01-18 14:44:18 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 14:44:18 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:44:18 --> Final output sent to browser
DEBUG - 2014-01-18 14:44:18 --> Total execution time: 0.0553
DEBUG - 2014-01-18 14:52:37 --> Config Class Initialized
DEBUG - 2014-01-18 14:52:37 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:52:37 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:52:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:52:37 --> URI Class Initialized
DEBUG - 2014-01-18 14:52:37 --> Router Class Initialized
DEBUG - 2014-01-18 14:52:37 --> Output Class Initialized
DEBUG - 2014-01-18 14:52:37 --> Security Class Initialized
DEBUG - 2014-01-18 14:52:37 --> Input Class Initialized
DEBUG - 2014-01-18 14:52:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:52:37 --> Language Class Initialized
DEBUG - 2014-01-18 14:52:37 --> Loader Class Initialized
DEBUG - 2014-01-18 14:52:37 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:52:37 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:52:37 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:52:37 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:52:37 --> Session Class Initialized
DEBUG - 2014-01-18 14:52:38 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:52:38 --> Session routines successfully run
DEBUG - 2014-01-18 14:52:38 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:52:38 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:52:38 --> Model Class Initialized
DEBUG - 2014-01-18 14:52:38 --> Model Class Initialized
DEBUG - 2014-01-18 14:52:38 --> Controller Class Initialized
DEBUG - 2014-01-18 14:52:38 --> File loaded: application/views/user/reset_hasla.php
DEBUG - 2014-01-18 14:52:38 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:52:38 --> Final output sent to browser
DEBUG - 2014-01-18 14:52:38 --> Total execution time: 0.0846
DEBUG - 2014-01-18 14:54:35 --> Config Class Initialized
DEBUG - 2014-01-18 14:54:35 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:54:35 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:54:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:54:35 --> URI Class Initialized
DEBUG - 2014-01-18 14:54:35 --> Router Class Initialized
DEBUG - 2014-01-18 14:54:35 --> Output Class Initialized
DEBUG - 2014-01-18 14:54:35 --> Security Class Initialized
DEBUG - 2014-01-18 14:54:35 --> Input Class Initialized
DEBUG - 2014-01-18 14:54:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:54:35 --> Language Class Initialized
DEBUG - 2014-01-18 14:54:35 --> Loader Class Initialized
DEBUG - 2014-01-18 14:54:35 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:54:35 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:54:35 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:54:35 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:54:35 --> Session Class Initialized
DEBUG - 2014-01-18 14:54:35 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:54:35 --> Session routines successfully run
DEBUG - 2014-01-18 14:54:35 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:54:35 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:54:35 --> Model Class Initialized
DEBUG - 2014-01-18 14:54:35 --> Model Class Initialized
DEBUG - 2014-01-18 14:54:35 --> Controller Class Initialized
DEBUG - 2014-01-18 14:54:35 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 14:54:35 --> Model Class Initialized
ERROR - 2014-01-18 14:54:38 --> Severity: Notice  --> Undefined index: e-mail C:\wamp\www\Windykator1\application\models\users.php 153
DEBUG - 2014-01-18 14:54:38 --> Config Class Initialized
DEBUG - 2014-01-18 14:54:38 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:54:38 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:54:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:54:38 --> URI Class Initialized
DEBUG - 2014-01-18 14:54:38 --> Router Class Initialized
DEBUG - 2014-01-18 14:54:38 --> Output Class Initialized
DEBUG - 2014-01-18 14:54:38 --> Security Class Initialized
DEBUG - 2014-01-18 14:54:38 --> Input Class Initialized
DEBUG - 2014-01-18 14:54:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:54:38 --> Language Class Initialized
DEBUG - 2014-01-18 14:54:38 --> Loader Class Initialized
DEBUG - 2014-01-18 14:54:38 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:54:38 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:54:38 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:54:38 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:54:38 --> Session Class Initialized
DEBUG - 2014-01-18 14:54:38 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:54:38 --> Session routines successfully run
DEBUG - 2014-01-18 14:54:38 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:54:38 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:54:38 --> Model Class Initialized
DEBUG - 2014-01-18 14:54:38 --> Model Class Initialized
DEBUG - 2014-01-18 14:54:38 --> Controller Class Initialized
DEBUG - 2014-01-18 14:54:38 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 14:54:38 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:54:38 --> Final output sent to browser
DEBUG - 2014-01-18 14:54:38 --> Total execution time: 0.0591
DEBUG - 2014-01-18 14:55:22 --> Config Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:55:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:55:22 --> URI Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Router Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Output Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Security Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Input Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:55:22 --> Language Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Loader Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:55:22 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:55:22 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:55:22 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Session Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:55:22 --> Session routines successfully run
DEBUG - 2014-01-18 14:55:22 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Model Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Model Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Controller Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 14:55:22 --> Config Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:55:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:55:22 --> URI Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Router Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Output Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Security Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Input Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:55:22 --> Language Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Loader Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:55:22 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:55:22 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:55:22 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Session Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:55:22 --> Session routines successfully run
DEBUG - 2014-01-18 14:55:22 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Model Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Model Class Initialized
DEBUG - 2014-01-18 14:55:22 --> Controller Class Initialized
DEBUG - 2014-01-18 14:55:22 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 14:55:22 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:55:22 --> Final output sent to browser
DEBUG - 2014-01-18 14:55:22 --> Total execution time: 0.0601
DEBUG - 2014-01-18 14:58:56 --> Config Class Initialized
DEBUG - 2014-01-18 14:58:56 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:58:56 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:58:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:58:56 --> URI Class Initialized
DEBUG - 2014-01-18 14:58:56 --> Router Class Initialized
DEBUG - 2014-01-18 14:58:56 --> Output Class Initialized
DEBUG - 2014-01-18 14:58:56 --> Security Class Initialized
DEBUG - 2014-01-18 14:58:56 --> Input Class Initialized
DEBUG - 2014-01-18 14:58:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:58:56 --> Language Class Initialized
DEBUG - 2014-01-18 14:58:56 --> Loader Class Initialized
DEBUG - 2014-01-18 14:58:56 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:58:56 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:58:56 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:58:56 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:58:56 --> Session Class Initialized
DEBUG - 2014-01-18 14:58:56 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:58:56 --> Session routines successfully run
DEBUG - 2014-01-18 14:58:56 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:58:56 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:58:56 --> Model Class Initialized
DEBUG - 2014-01-18 14:58:56 --> Model Class Initialized
DEBUG - 2014-01-18 14:58:56 --> Controller Class Initialized
DEBUG - 2014-01-18 14:58:56 --> File loaded: application/views/user/reset_hasla.php
DEBUG - 2014-01-18 14:58:56 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:58:56 --> Final output sent to browser
DEBUG - 2014-01-18 14:58:56 --> Total execution time: 0.0541
DEBUG - 2014-01-18 14:59:07 --> Config Class Initialized
DEBUG - 2014-01-18 14:59:07 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:59:07 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:59:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:59:07 --> URI Class Initialized
DEBUG - 2014-01-18 14:59:07 --> Router Class Initialized
DEBUG - 2014-01-18 14:59:07 --> Output Class Initialized
DEBUG - 2014-01-18 14:59:07 --> Security Class Initialized
DEBUG - 2014-01-18 14:59:07 --> Input Class Initialized
DEBUG - 2014-01-18 14:59:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:59:07 --> Language Class Initialized
DEBUG - 2014-01-18 14:59:07 --> Loader Class Initialized
DEBUG - 2014-01-18 14:59:07 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:59:07 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:59:07 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:59:07 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:59:07 --> Session Class Initialized
DEBUG - 2014-01-18 14:59:07 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:59:07 --> Session routines successfully run
DEBUG - 2014-01-18 14:59:07 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:59:07 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:59:07 --> Model Class Initialized
DEBUG - 2014-01-18 14:59:07 --> Model Class Initialized
DEBUG - 2014-01-18 14:59:07 --> Controller Class Initialized
DEBUG - 2014-01-18 14:59:07 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 14:59:07 --> Model Class Initialized
ERROR - 2014-01-18 14:59:11 --> Severity: Notice  --> Undefined index: e-mail C:\wamp\www\Windykator1\application\models\users.php 153
DEBUG - 2014-01-18 14:59:11 --> Config Class Initialized
DEBUG - 2014-01-18 14:59:11 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:59:11 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:59:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:59:11 --> URI Class Initialized
DEBUG - 2014-01-18 14:59:11 --> Router Class Initialized
DEBUG - 2014-01-18 14:59:11 --> Output Class Initialized
DEBUG - 2014-01-18 14:59:11 --> Security Class Initialized
DEBUG - 2014-01-18 14:59:11 --> Input Class Initialized
DEBUG - 2014-01-18 14:59:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:59:11 --> Language Class Initialized
DEBUG - 2014-01-18 14:59:11 --> Loader Class Initialized
DEBUG - 2014-01-18 14:59:11 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:59:11 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:59:11 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:59:11 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:59:11 --> Session Class Initialized
DEBUG - 2014-01-18 14:59:11 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:59:11 --> Session routines successfully run
DEBUG - 2014-01-18 14:59:11 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:59:11 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:59:11 --> Model Class Initialized
DEBUG - 2014-01-18 14:59:11 --> Model Class Initialized
DEBUG - 2014-01-18 14:59:11 --> Controller Class Initialized
DEBUG - 2014-01-18 14:59:11 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 14:59:11 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:59:11 --> Final output sent to browser
DEBUG - 2014-01-18 14:59:11 --> Total execution time: 0.0587
DEBUG - 2014-01-18 14:59:52 --> Config Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:59:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:59:52 --> URI Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Router Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Output Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Security Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Input Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:59:52 --> Language Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Loader Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:59:52 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:59:52 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:59:52 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Session Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:59:52 --> Session routines successfully run
DEBUG - 2014-01-18 14:59:52 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Model Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Model Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Controller Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 14:59:52 --> Config Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Hooks Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Utf8 Class Initialized
DEBUG - 2014-01-18 14:59:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 14:59:52 --> URI Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Router Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Output Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Security Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Input Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 14:59:52 --> Language Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Loader Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Helper loaded: url_helper
DEBUG - 2014-01-18 14:59:52 --> Helper loaded: form_helper
DEBUG - 2014-01-18 14:59:52 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 14:59:52 --> Database Driver Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Session Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Helper loaded: string_helper
DEBUG - 2014-01-18 14:59:52 --> Session routines successfully run
DEBUG - 2014-01-18 14:59:52 --> User Agent Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Form Validation Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Model Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Model Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Controller Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Model Class Initialized
DEBUG - 2014-01-18 14:59:52 --> Model Class Initialized
DEBUG - 2014-01-18 14:59:52 --> File loaded: application/views/wniosek/lista.php
DEBUG - 2014-01-18 14:59:52 --> File loaded: application/views/user/aktualnosci.php
DEBUG - 2014-01-18 14:59:52 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 14:59:52 --> Final output sent to browser
DEBUG - 2014-01-18 14:59:52 --> Total execution time: 0.0710
DEBUG - 2014-01-18 15:00:01 --> Config Class Initialized
DEBUG - 2014-01-18 15:00:01 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:00:01 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:00:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:00:01 --> URI Class Initialized
DEBUG - 2014-01-18 15:00:01 --> Router Class Initialized
DEBUG - 2014-01-18 15:00:01 --> Output Class Initialized
DEBUG - 2014-01-18 15:00:01 --> Security Class Initialized
DEBUG - 2014-01-18 15:00:01 --> Input Class Initialized
DEBUG - 2014-01-18 15:00:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:00:01 --> Language Class Initialized
DEBUG - 2014-01-18 15:00:02 --> Loader Class Initialized
DEBUG - 2014-01-18 15:00:02 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:00:02 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:00:02 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:00:02 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:00:02 --> Session Class Initialized
DEBUG - 2014-01-18 15:00:02 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:00:02 --> Session routines successfully run
DEBUG - 2014-01-18 15:00:02 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:00:02 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:00:02 --> Model Class Initialized
DEBUG - 2014-01-18 15:00:02 --> Model Class Initialized
DEBUG - 2014-01-18 15:00:02 --> Controller Class Initialized
DEBUG - 2014-01-18 15:00:02 --> Config Class Initialized
DEBUG - 2014-01-18 15:00:02 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:00:02 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:00:02 --> URI Class Initialized
DEBUG - 2014-01-18 15:00:02 --> Router Class Initialized
DEBUG - 2014-01-18 15:00:02 --> No URI present. Default controller set.
DEBUG - 2014-01-18 15:00:02 --> Output Class Initialized
DEBUG - 2014-01-18 15:00:02 --> Security Class Initialized
DEBUG - 2014-01-18 15:00:02 --> Input Class Initialized
DEBUG - 2014-01-18 15:00:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:00:02 --> Language Class Initialized
DEBUG - 2014-01-18 15:00:02 --> Loader Class Initialized
DEBUG - 2014-01-18 15:00:02 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:00:02 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:00:02 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:00:02 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:00:02 --> Session Class Initialized
DEBUG - 2014-01-18 15:00:02 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:00:02 --> Session routines successfully run
DEBUG - 2014-01-18 15:00:02 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:00:02 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:00:02 --> Model Class Initialized
DEBUG - 2014-01-18 15:00:02 --> Model Class Initialized
DEBUG - 2014-01-18 15:00:02 --> Controller Class Initialized
DEBUG - 2014-01-18 15:00:02 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 15:00:02 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 15:00:02 --> Final output sent to browser
DEBUG - 2014-01-18 15:00:02 --> Total execution time: 0.0654
DEBUG - 2014-01-18 15:00:08 --> Config Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:00:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:00:08 --> URI Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Router Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Output Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Security Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Input Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:00:08 --> Language Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Loader Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:00:08 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:00:08 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:00:08 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Session Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:00:08 --> Session routines successfully run
DEBUG - 2014-01-18 15:00:08 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Model Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Model Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Controller Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 15:00:08 --> Config Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:00:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:00:08 --> URI Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Router Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Output Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Security Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Input Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:00:08 --> Language Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Loader Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:00:08 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:00:08 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:00:08 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Session Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:00:08 --> Session routines successfully run
DEBUG - 2014-01-18 15:00:08 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Model Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Model Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Controller Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Model Class Initialized
DEBUG - 2014-01-18 15:00:08 --> Model Class Initialized
DEBUG - 2014-01-18 15:00:08 --> File loaded: application/views/wniosek/lista.php
DEBUG - 2014-01-18 15:00:08 --> File loaded: application/views/user/aktualnosci.php
DEBUG - 2014-01-18 15:00:08 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 15:00:08 --> Final output sent to browser
DEBUG - 2014-01-18 15:00:08 --> Total execution time: 0.0675
DEBUG - 2014-01-18 15:00:10 --> Config Class Initialized
DEBUG - 2014-01-18 15:00:10 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:00:10 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:00:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:00:10 --> URI Class Initialized
DEBUG - 2014-01-18 15:00:10 --> Router Class Initialized
DEBUG - 2014-01-18 15:00:10 --> Output Class Initialized
DEBUG - 2014-01-18 15:00:10 --> Security Class Initialized
DEBUG - 2014-01-18 15:00:10 --> Input Class Initialized
DEBUG - 2014-01-18 15:00:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:00:10 --> Language Class Initialized
DEBUG - 2014-01-18 15:00:10 --> Loader Class Initialized
DEBUG - 2014-01-18 15:00:10 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:00:10 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:00:10 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:00:10 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:00:10 --> Session Class Initialized
DEBUG - 2014-01-18 15:00:10 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:00:10 --> Session routines successfully run
DEBUG - 2014-01-18 15:00:10 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:00:10 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:00:10 --> Model Class Initialized
DEBUG - 2014-01-18 15:00:10 --> Model Class Initialized
DEBUG - 2014-01-18 15:00:10 --> Controller Class Initialized
DEBUG - 2014-01-18 15:00:10 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 15:00:10 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 15:00:10 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 15:00:10 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 15:00:10 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 15:00:10 --> Final output sent to browser
DEBUG - 2014-01-18 15:00:10 --> Total execution time: 0.0659
DEBUG - 2014-01-18 15:00:14 --> Config Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:00:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:00:14 --> URI Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Router Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Output Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Security Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Input Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:00:14 --> Language Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Loader Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:00:14 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:00:14 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:00:14 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Session Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:00:14 --> Session routines successfully run
DEBUG - 2014-01-18 15:00:14 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Model Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Model Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Controller Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Config Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:00:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:00:14 --> URI Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Router Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Output Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Security Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Input Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:00:14 --> Language Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Loader Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:00:14 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:00:14 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:00:14 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Session Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:00:14 --> Session routines successfully run
DEBUG - 2014-01-18 15:00:14 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Model Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Model Class Initialized
DEBUG - 2014-01-18 15:00:14 --> Controller Class Initialized
DEBUG - 2014-01-18 15:00:14 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 15:00:14 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 15:00:14 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 15:00:14 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 15:00:14 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 15:00:14 --> Final output sent to browser
DEBUG - 2014-01-18 15:00:14 --> Total execution time: 0.0929
DEBUG - 2014-01-18 15:00:18 --> Config Class Initialized
DEBUG - 2014-01-18 15:00:18 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:00:18 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:00:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:00:18 --> URI Class Initialized
DEBUG - 2014-01-18 15:00:18 --> Router Class Initialized
DEBUG - 2014-01-18 15:00:18 --> Output Class Initialized
DEBUG - 2014-01-18 15:00:18 --> Security Class Initialized
DEBUG - 2014-01-18 15:00:18 --> Input Class Initialized
DEBUG - 2014-01-18 15:00:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:00:18 --> Language Class Initialized
DEBUG - 2014-01-18 15:00:18 --> Loader Class Initialized
DEBUG - 2014-01-18 15:00:18 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:00:18 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:00:18 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:00:18 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:00:18 --> Session Class Initialized
DEBUG - 2014-01-18 15:00:18 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:00:18 --> Session routines successfully run
DEBUG - 2014-01-18 15:00:18 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:00:18 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:00:18 --> Model Class Initialized
DEBUG - 2014-01-18 15:00:18 --> Model Class Initialized
DEBUG - 2014-01-18 15:00:18 --> Controller Class Initialized
DEBUG - 2014-01-18 15:00:18 --> Config Class Initialized
DEBUG - 2014-01-18 15:00:18 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:00:18 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:00:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:00:18 --> URI Class Initialized
DEBUG - 2014-01-18 15:00:18 --> Router Class Initialized
DEBUG - 2014-01-18 15:00:18 --> No URI present. Default controller set.
DEBUG - 2014-01-18 15:00:18 --> Output Class Initialized
DEBUG - 2014-01-18 15:00:18 --> Security Class Initialized
DEBUG - 2014-01-18 15:00:18 --> Input Class Initialized
DEBUG - 2014-01-18 15:00:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:00:18 --> Language Class Initialized
DEBUG - 2014-01-18 15:00:18 --> Loader Class Initialized
DEBUG - 2014-01-18 15:00:18 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:00:18 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:00:18 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:00:18 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:00:18 --> Session Class Initialized
DEBUG - 2014-01-18 15:00:18 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:00:18 --> Session routines successfully run
DEBUG - 2014-01-18 15:00:18 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:00:18 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:00:18 --> Model Class Initialized
DEBUG - 2014-01-18 15:00:19 --> Model Class Initialized
DEBUG - 2014-01-18 15:00:19 --> Controller Class Initialized
DEBUG - 2014-01-18 15:00:19 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 15:00:19 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 15:00:19 --> Final output sent to browser
DEBUG - 2014-01-18 15:00:19 --> Total execution time: 0.0564
DEBUG - 2014-01-18 15:00:34 --> Config Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:00:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:00:34 --> URI Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Router Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Output Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Security Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Input Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:00:34 --> Language Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Loader Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:00:34 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:00:34 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:00:34 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Session Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:00:34 --> Session routines successfully run
DEBUG - 2014-01-18 15:00:34 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Model Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Model Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Controller Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 15:00:34 --> Config Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:00:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:00:34 --> URI Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Router Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Output Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Security Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Input Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:00:34 --> Language Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Loader Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:00:34 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:00:34 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:00:34 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Session Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:00:34 --> Session routines successfully run
DEBUG - 2014-01-18 15:00:34 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Model Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Model Class Initialized
DEBUG - 2014-01-18 15:00:34 --> Controller Class Initialized
DEBUG - 2014-01-18 15:00:34 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 15:00:34 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 15:00:34 --> Final output sent to browser
DEBUG - 2014-01-18 15:00:34 --> Total execution time: 0.0613
DEBUG - 2014-01-18 15:03:09 --> Config Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:03:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:03:09 --> URI Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Router Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Output Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Security Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Input Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:03:09 --> Language Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Loader Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:03:09 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:03:09 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:03:09 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Session Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:03:09 --> Session routines successfully run
DEBUG - 2014-01-18 15:03:09 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Model Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Model Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Controller Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 15:03:09 --> Config Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:03:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:03:09 --> URI Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Router Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Output Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Security Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Input Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:03:09 --> Language Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Loader Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:03:09 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:03:09 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:03:09 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Session Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:03:09 --> Session routines successfully run
DEBUG - 2014-01-18 15:03:09 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Model Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Model Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Controller Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Model Class Initialized
DEBUG - 2014-01-18 15:03:09 --> Model Class Initialized
DEBUG - 2014-01-18 15:03:09 --> File loaded: application/views/wniosek/lista.php
DEBUG - 2014-01-18 15:03:09 --> File loaded: application/views/user/aktualnosci.php
DEBUG - 2014-01-18 15:03:09 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 15:03:09 --> Final output sent to browser
DEBUG - 2014-01-18 15:03:09 --> Total execution time: 0.0663
DEBUG - 2014-01-18 15:03:14 --> Config Class Initialized
DEBUG - 2014-01-18 15:03:14 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:03:14 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:03:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:03:14 --> URI Class Initialized
DEBUG - 2014-01-18 15:03:14 --> Router Class Initialized
DEBUG - 2014-01-18 15:03:14 --> Output Class Initialized
DEBUG - 2014-01-18 15:03:14 --> Security Class Initialized
DEBUG - 2014-01-18 15:03:14 --> Input Class Initialized
DEBUG - 2014-01-18 15:03:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:03:14 --> Language Class Initialized
DEBUG - 2014-01-18 15:03:14 --> Loader Class Initialized
DEBUG - 2014-01-18 15:03:14 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:03:14 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:03:14 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:03:14 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:03:14 --> Session Class Initialized
DEBUG - 2014-01-18 15:03:14 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:03:14 --> Session routines successfully run
DEBUG - 2014-01-18 15:03:14 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:03:14 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:03:14 --> Model Class Initialized
DEBUG - 2014-01-18 15:03:14 --> Model Class Initialized
DEBUG - 2014-01-18 15:03:14 --> Controller Class Initialized
DEBUG - 2014-01-18 15:03:14 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 15:03:14 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 15:03:14 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 15:03:14 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 15:03:14 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 15:03:14 --> Final output sent to browser
DEBUG - 2014-01-18 15:03:14 --> Total execution time: 0.0617
DEBUG - 2014-01-18 15:03:25 --> Config Class Initialized
DEBUG - 2014-01-18 15:03:25 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:03:25 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:03:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:03:25 --> URI Class Initialized
DEBUG - 2014-01-18 15:03:25 --> Router Class Initialized
DEBUG - 2014-01-18 15:03:25 --> Output Class Initialized
DEBUG - 2014-01-18 15:03:25 --> Security Class Initialized
DEBUG - 2014-01-18 15:03:25 --> Input Class Initialized
DEBUG - 2014-01-18 15:03:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:03:25 --> Language Class Initialized
DEBUG - 2014-01-18 15:03:25 --> Loader Class Initialized
DEBUG - 2014-01-18 15:03:25 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:03:25 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:03:25 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:03:25 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:03:25 --> Session Class Initialized
DEBUG - 2014-01-18 15:03:25 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:03:25 --> Session routines successfully run
DEBUG - 2014-01-18 15:03:25 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:03:25 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:03:25 --> Model Class Initialized
DEBUG - 2014-01-18 15:03:25 --> Model Class Initialized
DEBUG - 2014-01-18 15:03:25 --> Controller Class Initialized
DEBUG - 2014-01-18 15:03:25 --> File loaded: application/views/user/podglad.php
DEBUG - 2014-01-18 15:03:25 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 15:03:25 --> Final output sent to browser
DEBUG - 2014-01-18 15:03:25 --> Total execution time: 0.0599
DEBUG - 2014-01-18 15:03:33 --> Config Class Initialized
DEBUG - 2014-01-18 15:03:33 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:03:33 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:03:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:03:33 --> URI Class Initialized
DEBUG - 2014-01-18 15:03:33 --> Router Class Initialized
DEBUG - 2014-01-18 15:03:33 --> Output Class Initialized
DEBUG - 2014-01-18 15:03:33 --> Security Class Initialized
DEBUG - 2014-01-18 15:03:33 --> Input Class Initialized
DEBUG - 2014-01-18 15:03:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:03:33 --> Language Class Initialized
DEBUG - 2014-01-18 15:03:33 --> Loader Class Initialized
DEBUG - 2014-01-18 15:03:33 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:03:33 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:03:33 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:03:33 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:03:33 --> Session Class Initialized
DEBUG - 2014-01-18 15:03:33 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:03:33 --> Session routines successfully run
DEBUG - 2014-01-18 15:03:33 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:03:33 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:03:33 --> Model Class Initialized
DEBUG - 2014-01-18 15:03:33 --> Model Class Initialized
DEBUG - 2014-01-18 15:03:33 --> Controller Class Initialized
DEBUG - 2014-01-18 15:03:33 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 15:03:33 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 15:03:33 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 15:03:33 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 15:03:33 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 15:03:33 --> Final output sent to browser
DEBUG - 2014-01-18 15:03:33 --> Total execution time: 0.0729
DEBUG - 2014-01-18 15:03:37 --> Config Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:03:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:03:37 --> URI Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Router Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Output Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Security Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Input Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:03:37 --> Language Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Loader Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:03:37 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:03:37 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:03:37 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Session Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:03:37 --> Session routines successfully run
DEBUG - 2014-01-18 15:03:37 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Model Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Model Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Controller Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Config Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:03:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:03:37 --> URI Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Router Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Output Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Security Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Input Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:03:37 --> Language Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Loader Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:03:37 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:03:37 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:03:37 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Session Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:03:37 --> Session routines successfully run
DEBUG - 2014-01-18 15:03:37 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Model Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Model Class Initialized
DEBUG - 2014-01-18 15:03:37 --> Controller Class Initialized
DEBUG - 2014-01-18 15:03:37 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 15:03:37 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 15:03:37 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 15:03:37 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 15:03:37 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 15:03:37 --> Final output sent to browser
DEBUG - 2014-01-18 15:03:37 --> Total execution time: 0.0752
DEBUG - 2014-01-18 15:03:41 --> Config Class Initialized
DEBUG - 2014-01-18 15:03:41 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:03:41 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:03:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:03:41 --> URI Class Initialized
DEBUG - 2014-01-18 15:03:41 --> Router Class Initialized
DEBUG - 2014-01-18 15:03:41 --> Output Class Initialized
DEBUG - 2014-01-18 15:03:41 --> Security Class Initialized
DEBUG - 2014-01-18 15:03:41 --> Input Class Initialized
DEBUG - 2014-01-18 15:03:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:03:41 --> Language Class Initialized
DEBUG - 2014-01-18 15:03:41 --> Loader Class Initialized
DEBUG - 2014-01-18 15:03:41 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:03:41 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:03:41 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:03:41 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:03:41 --> Session Class Initialized
DEBUG - 2014-01-18 15:03:41 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:03:41 --> Session routines successfully run
DEBUG - 2014-01-18 15:03:41 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:03:41 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:03:41 --> Model Class Initialized
DEBUG - 2014-01-18 15:03:41 --> Model Class Initialized
DEBUG - 2014-01-18 15:03:41 --> Controller Class Initialized
DEBUG - 2014-01-18 15:03:41 --> File loaded: application/views/user/podglad.php
DEBUG - 2014-01-18 15:03:41 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 15:03:41 --> Final output sent to browser
DEBUG - 2014-01-18 15:03:41 --> Total execution time: 0.0585
DEBUG - 2014-01-18 15:03:47 --> Config Class Initialized
DEBUG - 2014-01-18 15:03:47 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:03:47 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:03:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:03:47 --> URI Class Initialized
DEBUG - 2014-01-18 15:03:47 --> Router Class Initialized
DEBUG - 2014-01-18 15:03:47 --> Output Class Initialized
DEBUG - 2014-01-18 15:03:47 --> Security Class Initialized
DEBUG - 2014-01-18 15:03:47 --> Input Class Initialized
DEBUG - 2014-01-18 15:03:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:03:47 --> Language Class Initialized
DEBUG - 2014-01-18 15:03:47 --> Loader Class Initialized
DEBUG - 2014-01-18 15:03:47 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:03:47 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:03:47 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:03:47 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:03:47 --> Session Class Initialized
DEBUG - 2014-01-18 15:03:47 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:03:47 --> Session routines successfully run
DEBUG - 2014-01-18 15:03:47 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:03:47 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:03:47 --> Model Class Initialized
DEBUG - 2014-01-18 15:03:47 --> Model Class Initialized
DEBUG - 2014-01-18 15:03:47 --> Controller Class Initialized
DEBUG - 2014-01-18 15:03:47 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 15:03:47 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 15:03:47 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 15:03:47 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 15:03:47 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 15:03:47 --> Final output sent to browser
DEBUG - 2014-01-18 15:03:47 --> Total execution time: 0.0678
DEBUG - 2014-01-18 15:03:51 --> Config Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:03:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:03:51 --> URI Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Router Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Output Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Security Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Input Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:03:51 --> Language Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Loader Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:03:51 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:03:51 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:03:51 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Session Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:03:51 --> Session routines successfully run
DEBUG - 2014-01-18 15:03:51 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Model Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Model Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Controller Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Config Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:03:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:03:51 --> URI Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Router Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Output Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Security Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Input Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:03:51 --> Language Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Loader Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:03:51 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:03:51 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:03:51 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Session Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:03:51 --> Session routines successfully run
DEBUG - 2014-01-18 15:03:51 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Model Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Model Class Initialized
DEBUG - 2014-01-18 15:03:51 --> Controller Class Initialized
DEBUG - 2014-01-18 15:03:52 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 15:03:52 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 15:03:52 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 15:03:52 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 15:03:52 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 15:03:52 --> Final output sent to browser
DEBUG - 2014-01-18 15:03:52 --> Total execution time: 0.0801
DEBUG - 2014-01-18 15:03:53 --> Config Class Initialized
DEBUG - 2014-01-18 15:03:53 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:03:53 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:03:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:03:53 --> URI Class Initialized
DEBUG - 2014-01-18 15:03:53 --> Router Class Initialized
DEBUG - 2014-01-18 15:03:53 --> Output Class Initialized
DEBUG - 2014-01-18 15:03:53 --> Security Class Initialized
DEBUG - 2014-01-18 15:03:53 --> Input Class Initialized
DEBUG - 2014-01-18 15:03:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:03:53 --> Language Class Initialized
DEBUG - 2014-01-18 15:03:53 --> Loader Class Initialized
DEBUG - 2014-01-18 15:03:53 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:03:53 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:03:53 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:03:53 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:03:53 --> Session Class Initialized
DEBUG - 2014-01-18 15:03:53 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:03:53 --> Session routines successfully run
DEBUG - 2014-01-18 15:03:53 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:03:53 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:03:53 --> Model Class Initialized
DEBUG - 2014-01-18 15:03:53 --> Model Class Initialized
DEBUG - 2014-01-18 15:03:53 --> Controller Class Initialized
DEBUG - 2014-01-18 15:03:53 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 15:03:53 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 15:03:53 --> File loaded: application/views/user/listaZablokowanych.php
DEBUG - 2014-01-18 15:03:53 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 15:03:53 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 15:03:53 --> Final output sent to browser
DEBUG - 2014-01-18 15:03:53 --> Total execution time: 0.0929
DEBUG - 2014-01-18 15:04:00 --> Config Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:04:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:04:00 --> URI Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Router Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Output Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Security Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Input Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:04:00 --> Language Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Loader Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:04:00 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:04:00 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:04:00 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Session Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:04:00 --> Session routines successfully run
DEBUG - 2014-01-18 15:04:00 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Model Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Model Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Controller Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Config Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:04:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:04:00 --> URI Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Router Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Output Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Security Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Input Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:04:00 --> Language Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Loader Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:04:00 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:04:00 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:04:00 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Session Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:04:00 --> Session routines successfully run
DEBUG - 2014-01-18 15:04:00 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Model Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Model Class Initialized
DEBUG - 2014-01-18 15:04:00 --> Controller Class Initialized
DEBUG - 2014-01-18 15:04:00 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 15:04:00 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 15:04:00 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 15:04:00 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 15:04:00 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 15:04:00 --> Final output sent to browser
DEBUG - 2014-01-18 15:04:00 --> Total execution time: 0.0667
DEBUG - 2014-01-18 15:04:03 --> Config Class Initialized
DEBUG - 2014-01-18 15:04:03 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:04:03 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:04:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:04:03 --> URI Class Initialized
DEBUG - 2014-01-18 15:04:03 --> Router Class Initialized
DEBUG - 2014-01-18 15:04:03 --> Output Class Initialized
DEBUG - 2014-01-18 15:04:03 --> Security Class Initialized
DEBUG - 2014-01-18 15:04:03 --> Input Class Initialized
DEBUG - 2014-01-18 15:04:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:04:03 --> Language Class Initialized
DEBUG - 2014-01-18 15:04:03 --> Loader Class Initialized
DEBUG - 2014-01-18 15:04:03 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:04:03 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:04:03 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:04:03 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:04:03 --> Session Class Initialized
DEBUG - 2014-01-18 15:04:03 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:04:03 --> Session routines successfully run
DEBUG - 2014-01-18 15:04:03 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:04:03 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:04:03 --> Model Class Initialized
DEBUG - 2014-01-18 15:04:03 --> Model Class Initialized
DEBUG - 2014-01-18 15:04:03 --> Controller Class Initialized
DEBUG - 2014-01-18 15:04:03 --> File loaded: application/views/user/podglad.php
DEBUG - 2014-01-18 15:04:03 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 15:04:03 --> Final output sent to browser
DEBUG - 2014-01-18 15:04:03 --> Total execution time: 0.0563
DEBUG - 2014-01-18 15:04:26 --> Config Class Initialized
DEBUG - 2014-01-18 15:04:26 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:04:26 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:04:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:04:26 --> URI Class Initialized
DEBUG - 2014-01-18 15:04:26 --> Router Class Initialized
DEBUG - 2014-01-18 15:04:26 --> Output Class Initialized
DEBUG - 2014-01-18 15:04:26 --> Security Class Initialized
DEBUG - 2014-01-18 15:04:26 --> Input Class Initialized
DEBUG - 2014-01-18 15:04:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:04:26 --> Language Class Initialized
DEBUG - 2014-01-18 15:04:26 --> Loader Class Initialized
DEBUG - 2014-01-18 15:04:26 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:04:26 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:04:26 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:04:26 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:04:26 --> Session Class Initialized
DEBUG - 2014-01-18 15:04:26 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:04:26 --> Session routines successfully run
DEBUG - 2014-01-18 15:04:26 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:04:26 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:04:26 --> Model Class Initialized
DEBUG - 2014-01-18 15:04:26 --> Model Class Initialized
DEBUG - 2014-01-18 15:04:26 --> Controller Class Initialized
DEBUG - 2014-01-18 15:04:26 --> Config Class Initialized
DEBUG - 2014-01-18 15:04:26 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:04:26 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:04:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:04:26 --> URI Class Initialized
DEBUG - 2014-01-18 15:04:26 --> Router Class Initialized
DEBUG - 2014-01-18 15:04:26 --> No URI present. Default controller set.
DEBUG - 2014-01-18 15:04:26 --> Output Class Initialized
DEBUG - 2014-01-18 15:04:26 --> Security Class Initialized
DEBUG - 2014-01-18 15:04:26 --> Input Class Initialized
DEBUG - 2014-01-18 15:04:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:04:26 --> Language Class Initialized
DEBUG - 2014-01-18 15:04:26 --> Loader Class Initialized
DEBUG - 2014-01-18 15:04:26 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:04:26 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:04:26 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:04:26 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:04:26 --> Session Class Initialized
DEBUG - 2014-01-18 15:04:26 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:04:26 --> Session routines successfully run
DEBUG - 2014-01-18 15:04:26 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:04:26 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:04:26 --> Model Class Initialized
DEBUG - 2014-01-18 15:04:26 --> Model Class Initialized
DEBUG - 2014-01-18 15:04:26 --> Controller Class Initialized
DEBUG - 2014-01-18 15:04:26 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 15:04:26 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 15:04:26 --> Final output sent to browser
DEBUG - 2014-01-18 15:04:26 --> Total execution time: 0.0532
DEBUG - 2014-01-18 15:04:48 --> Config Class Initialized
DEBUG - 2014-01-18 15:04:48 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:04:48 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:04:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:04:48 --> URI Class Initialized
DEBUG - 2014-01-18 15:04:48 --> Router Class Initialized
DEBUG - 2014-01-18 15:04:48 --> Output Class Initialized
DEBUG - 2014-01-18 15:04:48 --> Security Class Initialized
DEBUG - 2014-01-18 15:04:48 --> Input Class Initialized
DEBUG - 2014-01-18 15:04:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:04:48 --> Language Class Initialized
DEBUG - 2014-01-18 15:04:48 --> Loader Class Initialized
DEBUG - 2014-01-18 15:04:48 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:04:48 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:04:48 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:04:48 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:04:48 --> Session Class Initialized
DEBUG - 2014-01-18 15:04:48 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:04:48 --> Session routines successfully run
DEBUG - 2014-01-18 15:04:48 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:04:48 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:04:48 --> Model Class Initialized
DEBUG - 2014-01-18 15:04:48 --> Model Class Initialized
DEBUG - 2014-01-18 15:04:48 --> Controller Class Initialized
DEBUG - 2014-01-18 15:04:48 --> File loaded: application/views/user/reset_hasla.php
DEBUG - 2014-01-18 15:04:48 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 15:04:48 --> Final output sent to browser
DEBUG - 2014-01-18 15:04:48 --> Total execution time: 0.0617
DEBUG - 2014-01-18 15:04:59 --> Config Class Initialized
DEBUG - 2014-01-18 15:04:59 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:04:59 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:04:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:04:59 --> URI Class Initialized
DEBUG - 2014-01-18 15:04:59 --> Router Class Initialized
DEBUG - 2014-01-18 15:04:59 --> Output Class Initialized
DEBUG - 2014-01-18 15:04:59 --> Security Class Initialized
DEBUG - 2014-01-18 15:04:59 --> Input Class Initialized
DEBUG - 2014-01-18 15:04:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:04:59 --> Language Class Initialized
DEBUG - 2014-01-18 15:04:59 --> Loader Class Initialized
DEBUG - 2014-01-18 15:04:59 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:04:59 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:04:59 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:04:59 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:04:59 --> Session Class Initialized
DEBUG - 2014-01-18 15:04:59 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:04:59 --> Session routines successfully run
DEBUG - 2014-01-18 15:04:59 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:04:59 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:04:59 --> Model Class Initialized
DEBUG - 2014-01-18 15:04:59 --> Model Class Initialized
DEBUG - 2014-01-18 15:04:59 --> Controller Class Initialized
DEBUG - 2014-01-18 15:04:59 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 15:04:59 --> Model Class Initialized
ERROR - 2014-01-18 15:05:01 --> Severity: Notice  --> Undefined index: e-mail C:\wamp\www\Windykator1\application\models\users.php 153
DEBUG - 2014-01-18 15:05:01 --> Config Class Initialized
DEBUG - 2014-01-18 15:05:01 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:05:01 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:05:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:05:01 --> URI Class Initialized
DEBUG - 2014-01-18 15:05:01 --> Router Class Initialized
DEBUG - 2014-01-18 15:05:01 --> Output Class Initialized
DEBUG - 2014-01-18 15:05:01 --> Security Class Initialized
DEBUG - 2014-01-18 15:05:01 --> Input Class Initialized
DEBUG - 2014-01-18 15:05:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:05:01 --> Language Class Initialized
DEBUG - 2014-01-18 15:05:01 --> Loader Class Initialized
DEBUG - 2014-01-18 15:05:01 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:05:01 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:05:01 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:05:01 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:05:01 --> Session Class Initialized
DEBUG - 2014-01-18 15:05:01 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:05:01 --> Session routines successfully run
DEBUG - 2014-01-18 15:05:01 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:05:01 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:05:01 --> Model Class Initialized
DEBUG - 2014-01-18 15:05:01 --> Model Class Initialized
DEBUG - 2014-01-18 15:05:01 --> Controller Class Initialized
DEBUG - 2014-01-18 15:05:01 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 15:05:01 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 15:05:01 --> Final output sent to browser
DEBUG - 2014-01-18 15:05:01 --> Total execution time: 0.0754
DEBUG - 2014-01-18 15:05:25 --> Config Class Initialized
DEBUG - 2014-01-18 15:05:25 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:05:25 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:05:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:05:25 --> URI Class Initialized
DEBUG - 2014-01-18 15:05:25 --> Router Class Initialized
DEBUG - 2014-01-18 15:05:25 --> Output Class Initialized
DEBUG - 2014-01-18 15:05:25 --> Security Class Initialized
DEBUG - 2014-01-18 15:05:25 --> Input Class Initialized
DEBUG - 2014-01-18 15:05:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:05:25 --> Language Class Initialized
DEBUG - 2014-01-18 15:05:25 --> Loader Class Initialized
DEBUG - 2014-01-18 15:05:25 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:05:25 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:05:25 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:05:25 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:05:25 --> Session Class Initialized
DEBUG - 2014-01-18 15:05:25 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:05:25 --> Session routines successfully run
DEBUG - 2014-01-18 15:05:25 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:05:25 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:05:25 --> Model Class Initialized
DEBUG - 2014-01-18 15:05:25 --> Model Class Initialized
DEBUG - 2014-01-18 15:05:25 --> Controller Class Initialized
DEBUG - 2014-01-18 15:05:25 --> File loaded: application/views/user/reset_hasla.php
DEBUG - 2014-01-18 15:05:25 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 15:05:25 --> Final output sent to browser
DEBUG - 2014-01-18 15:05:25 --> Total execution time: 0.0726
DEBUG - 2014-01-18 15:05:45 --> Config Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:05:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:05:45 --> URI Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Router Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Output Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Security Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Input Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:05:45 --> Language Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Loader Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:05:45 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:05:45 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:05:45 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Session Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:05:45 --> Session routines successfully run
DEBUG - 2014-01-18 15:05:45 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Model Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Model Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Controller Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 15:05:45 --> Config Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:05:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:05:45 --> URI Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Router Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Output Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Security Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Input Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:05:45 --> Language Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Loader Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:05:45 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:05:45 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:05:45 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Session Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:05:45 --> Session routines successfully run
DEBUG - 2014-01-18 15:05:45 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Model Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Model Class Initialized
DEBUG - 2014-01-18 15:05:45 --> Controller Class Initialized
DEBUG - 2014-01-18 15:05:45 --> File loaded: application/views/user/reset_hasla.php
DEBUG - 2014-01-18 15:05:45 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 15:05:45 --> Final output sent to browser
DEBUG - 2014-01-18 15:05:45 --> Total execution time: 0.0526
DEBUG - 2014-01-18 15:15:39 --> Config Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:15:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:15:39 --> URI Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Router Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Output Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Security Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Input Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:15:39 --> Language Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Loader Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:15:39 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:15:39 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:15:39 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Session Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:15:39 --> Session routines successfully run
DEBUG - 2014-01-18 15:15:39 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Model Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Model Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Controller Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 15:15:39 --> Config Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:15:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:15:39 --> URI Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Router Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Output Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Security Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Input Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:15:39 --> Language Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Loader Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:15:39 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:15:39 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:15:39 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Session Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:15:39 --> Session routines successfully run
DEBUG - 2014-01-18 15:15:39 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Model Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Model Class Initialized
DEBUG - 2014-01-18 15:15:39 --> Controller Class Initialized
DEBUG - 2014-01-18 15:15:39 --> File loaded: application/views/user/reset_hasla.php
DEBUG - 2014-01-18 15:15:39 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 15:15:39 --> Final output sent to browser
DEBUG - 2014-01-18 15:15:39 --> Total execution time: 0.0561
DEBUG - 2014-01-18 15:16:34 --> Config Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:16:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:16:34 --> URI Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Router Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Output Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Security Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Input Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:16:34 --> Language Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Loader Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:16:34 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:16:34 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:16:34 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Session Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:16:34 --> Session routines successfully run
DEBUG - 2014-01-18 15:16:34 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Model Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Model Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Controller Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 15:16:34 --> Config Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:16:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:16:34 --> URI Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Router Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Output Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Security Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Input Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:16:34 --> Language Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Loader Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:16:34 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:16:34 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:16:34 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Session Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:16:34 --> Session routines successfully run
DEBUG - 2014-01-18 15:16:34 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Model Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Model Class Initialized
DEBUG - 2014-01-18 15:16:34 --> Controller Class Initialized
DEBUG - 2014-01-18 15:16:34 --> File loaded: application/views/user/reset_hasla.php
DEBUG - 2014-01-18 15:16:34 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 15:16:34 --> Final output sent to browser
DEBUG - 2014-01-18 15:16:34 --> Total execution time: 0.0556
DEBUG - 2014-01-18 15:17:48 --> Config Class Initialized
DEBUG - 2014-01-18 15:17:48 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:17:48 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:17:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:17:48 --> URI Class Initialized
DEBUG - 2014-01-18 15:17:48 --> Router Class Initialized
DEBUG - 2014-01-18 15:17:48 --> Output Class Initialized
DEBUG - 2014-01-18 15:17:48 --> Security Class Initialized
DEBUG - 2014-01-18 15:17:48 --> Input Class Initialized
DEBUG - 2014-01-18 15:17:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:17:48 --> Language Class Initialized
DEBUG - 2014-01-18 15:17:48 --> Loader Class Initialized
DEBUG - 2014-01-18 15:17:48 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:17:48 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:17:48 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:17:48 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:17:48 --> Session Class Initialized
DEBUG - 2014-01-18 15:17:48 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:17:48 --> Session routines successfully run
DEBUG - 2014-01-18 15:17:48 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:17:48 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:17:48 --> Model Class Initialized
DEBUG - 2014-01-18 15:17:48 --> Model Class Initialized
DEBUG - 2014-01-18 15:17:48 --> Controller Class Initialized
DEBUG - 2014-01-18 15:17:48 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 15:17:48 --> Model Class Initialized
ERROR - 2014-01-18 15:17:52 --> Severity: Notice  --> Undefined index: e-mail C:\wamp\www\Windykator1\application\models\users.php 153
DEBUG - 2014-01-18 15:17:52 --> Config Class Initialized
DEBUG - 2014-01-18 15:17:52 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:17:52 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:17:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:17:52 --> URI Class Initialized
DEBUG - 2014-01-18 15:17:52 --> Router Class Initialized
DEBUG - 2014-01-18 15:17:52 --> Output Class Initialized
DEBUG - 2014-01-18 15:17:52 --> Security Class Initialized
DEBUG - 2014-01-18 15:17:52 --> Input Class Initialized
DEBUG - 2014-01-18 15:17:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:17:52 --> Language Class Initialized
DEBUG - 2014-01-18 15:17:52 --> Loader Class Initialized
DEBUG - 2014-01-18 15:17:52 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:17:52 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:17:52 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:17:52 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:17:52 --> Session Class Initialized
DEBUG - 2014-01-18 15:17:52 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:17:52 --> Session routines successfully run
DEBUG - 2014-01-18 15:17:52 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:17:52 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:17:52 --> Model Class Initialized
DEBUG - 2014-01-18 15:17:52 --> Model Class Initialized
DEBUG - 2014-01-18 15:17:52 --> Controller Class Initialized
DEBUG - 2014-01-18 15:17:52 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 15:17:52 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 15:17:52 --> Final output sent to browser
DEBUG - 2014-01-18 15:17:52 --> Total execution time: 0.0837
DEBUG - 2014-01-18 15:19:19 --> Config Class Initialized
DEBUG - 2014-01-18 15:19:19 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:19:19 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:19:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:19:19 --> URI Class Initialized
DEBUG - 2014-01-18 15:19:19 --> Router Class Initialized
DEBUG - 2014-01-18 15:19:19 --> Output Class Initialized
DEBUG - 2014-01-18 15:19:19 --> Security Class Initialized
DEBUG - 2014-01-18 15:19:19 --> Input Class Initialized
DEBUG - 2014-01-18 15:19:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:19:19 --> Language Class Initialized
DEBUG - 2014-01-18 15:19:19 --> Loader Class Initialized
DEBUG - 2014-01-18 15:19:19 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:19:19 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:19:19 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:19:19 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:19:19 --> Session Class Initialized
DEBUG - 2014-01-18 15:19:19 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:19:19 --> Session routines successfully run
DEBUG - 2014-01-18 15:19:19 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:19:19 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:19:19 --> Model Class Initialized
DEBUG - 2014-01-18 15:19:19 --> Model Class Initialized
DEBUG - 2014-01-18 15:19:19 --> Controller Class Initialized
DEBUG - 2014-01-18 15:19:19 --> File loaded: application/views/user/reset_hasla.php
DEBUG - 2014-01-18 15:19:19 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 15:19:19 --> Final output sent to browser
DEBUG - 2014-01-18 15:19:19 --> Total execution time: 0.0780
DEBUG - 2014-01-18 15:19:42 --> Config Class Initialized
DEBUG - 2014-01-18 15:19:42 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:19:42 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:19:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:19:42 --> URI Class Initialized
DEBUG - 2014-01-18 15:19:42 --> Router Class Initialized
DEBUG - 2014-01-18 15:19:42 --> Output Class Initialized
DEBUG - 2014-01-18 15:19:42 --> Security Class Initialized
DEBUG - 2014-01-18 15:19:42 --> Input Class Initialized
DEBUG - 2014-01-18 15:19:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:19:42 --> Language Class Initialized
DEBUG - 2014-01-18 15:19:42 --> Loader Class Initialized
DEBUG - 2014-01-18 15:19:42 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:19:42 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:19:42 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:19:42 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:19:42 --> Session Class Initialized
DEBUG - 2014-01-18 15:19:42 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:19:42 --> Session routines successfully run
DEBUG - 2014-01-18 15:19:42 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:19:42 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:19:42 --> Model Class Initialized
DEBUG - 2014-01-18 15:19:42 --> Model Class Initialized
DEBUG - 2014-01-18 15:19:42 --> Controller Class Initialized
DEBUG - 2014-01-18 15:19:42 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 15:19:42 --> Model Class Initialized
DEBUG - 2014-01-18 15:19:44 --> Config Class Initialized
DEBUG - 2014-01-18 15:19:44 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:19:44 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:19:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:19:44 --> URI Class Initialized
DEBUG - 2014-01-18 15:19:44 --> Router Class Initialized
DEBUG - 2014-01-18 15:19:44 --> Output Class Initialized
DEBUG - 2014-01-18 15:19:44 --> Security Class Initialized
DEBUG - 2014-01-18 15:19:44 --> Input Class Initialized
DEBUG - 2014-01-18 15:19:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:19:44 --> Language Class Initialized
DEBUG - 2014-01-18 15:19:44 --> Loader Class Initialized
DEBUG - 2014-01-18 15:19:44 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:19:44 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:19:44 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:19:44 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:19:44 --> Session Class Initialized
DEBUG - 2014-01-18 15:19:44 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:19:44 --> Session routines successfully run
DEBUG - 2014-01-18 15:19:44 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:19:44 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:19:44 --> Model Class Initialized
DEBUG - 2014-01-18 15:19:44 --> Model Class Initialized
DEBUG - 2014-01-18 15:19:44 --> Controller Class Initialized
DEBUG - 2014-01-18 15:19:44 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 15:19:44 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 15:19:44 --> Final output sent to browser
DEBUG - 2014-01-18 15:19:44 --> Total execution time: 0.0705
DEBUG - 2014-01-18 15:22:46 --> Config Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:22:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:22:46 --> URI Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Router Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Output Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Security Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Input Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:22:46 --> Language Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Loader Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:22:46 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:22:46 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:22:46 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Session Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:22:46 --> Session routines successfully run
DEBUG - 2014-01-18 15:22:46 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Model Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Model Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Controller Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Language file loaded: language/polish/form_validation_lang.php
DEBUG - 2014-01-18 15:22:46 --> Config Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:22:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:22:46 --> URI Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Router Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Output Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Security Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Input Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:22:46 --> Language Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Loader Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:22:46 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:22:46 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:22:46 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Session Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:22:46 --> Session routines successfully run
DEBUG - 2014-01-18 15:22:46 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Model Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Model Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Controller Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Model Class Initialized
DEBUG - 2014-01-18 15:22:46 --> Model Class Initialized
DEBUG - 2014-01-18 15:22:46 --> File loaded: application/views/wniosek/lista.php
DEBUG - 2014-01-18 15:22:46 --> File loaded: application/views/user/aktualnosci.php
DEBUG - 2014-01-18 15:22:46 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 15:22:46 --> Final output sent to browser
DEBUG - 2014-01-18 15:22:46 --> Total execution time: 0.0700
DEBUG - 2014-01-18 15:22:48 --> Config Class Initialized
DEBUG - 2014-01-18 15:22:48 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:22:48 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:22:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:22:48 --> URI Class Initialized
DEBUG - 2014-01-18 15:22:48 --> Router Class Initialized
DEBUG - 2014-01-18 15:22:48 --> Output Class Initialized
DEBUG - 2014-01-18 15:22:48 --> Security Class Initialized
DEBUG - 2014-01-18 15:22:48 --> Input Class Initialized
DEBUG - 2014-01-18 15:22:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:22:48 --> Language Class Initialized
DEBUG - 2014-01-18 15:22:48 --> Loader Class Initialized
DEBUG - 2014-01-18 15:22:48 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:22:48 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:22:48 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:22:48 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:22:48 --> Session Class Initialized
DEBUG - 2014-01-18 15:22:48 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:22:48 --> Session routines successfully run
DEBUG - 2014-01-18 15:22:48 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:22:48 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:22:48 --> Model Class Initialized
DEBUG - 2014-01-18 15:22:48 --> Model Class Initialized
DEBUG - 2014-01-18 15:22:48 --> Controller Class Initialized
DEBUG - 2014-01-18 15:22:48 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 15:22:48 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 15:22:48 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 15:22:48 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 15:22:48 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 15:22:48 --> Final output sent to browser
DEBUG - 2014-01-18 15:22:48 --> Total execution time: 0.0714
DEBUG - 2014-01-18 15:24:26 --> Config Class Initialized
DEBUG - 2014-01-18 15:24:26 --> Hooks Class Initialized
DEBUG - 2014-01-18 15:24:26 --> Utf8 Class Initialized
DEBUG - 2014-01-18 15:24:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 15:24:26 --> URI Class Initialized
DEBUG - 2014-01-18 15:24:26 --> Router Class Initialized
DEBUG - 2014-01-18 15:24:26 --> Output Class Initialized
DEBUG - 2014-01-18 15:24:26 --> Security Class Initialized
DEBUG - 2014-01-18 15:24:26 --> Input Class Initialized
DEBUG - 2014-01-18 15:24:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 15:24:26 --> Language Class Initialized
DEBUG - 2014-01-18 15:24:26 --> Loader Class Initialized
DEBUG - 2014-01-18 15:24:26 --> Helper loaded: url_helper
DEBUG - 2014-01-18 15:24:26 --> Helper loaded: form_helper
DEBUG - 2014-01-18 15:24:26 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 15:24:26 --> Database Driver Class Initialized
DEBUG - 2014-01-18 15:24:26 --> Session Class Initialized
DEBUG - 2014-01-18 15:24:26 --> Helper loaded: string_helper
DEBUG - 2014-01-18 15:24:26 --> Session routines successfully run
DEBUG - 2014-01-18 15:24:26 --> User Agent Class Initialized
DEBUG - 2014-01-18 15:24:26 --> Form Validation Class Initialized
DEBUG - 2014-01-18 15:24:26 --> Model Class Initialized
DEBUG - 2014-01-18 15:24:26 --> Model Class Initialized
DEBUG - 2014-01-18 15:24:26 --> Controller Class Initialized
DEBUG - 2014-01-18 15:24:26 --> File loaded: application/views/user/szukaj.php
DEBUG - 2014-01-18 15:24:26 --> File loaded: application/views/user/akcje.php
DEBUG - 2014-01-18 15:24:26 --> File loaded: application/views/user/lista.php
DEBUG - 2014-01-18 15:24:26 --> File loaded: application/views/user/zarzadzanie.php
DEBUG - 2014-01-18 15:24:26 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 15:24:26 --> Final output sent to browser
DEBUG - 2014-01-18 15:24:26 --> Total execution time: 0.0840
DEBUG - 2014-01-18 16:26:36 --> Config Class Initialized
DEBUG - 2014-01-18 16:26:36 --> Hooks Class Initialized
DEBUG - 2014-01-18 16:26:36 --> Utf8 Class Initialized
DEBUG - 2014-01-18 16:26:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 16:26:36 --> URI Class Initialized
DEBUG - 2014-01-18 16:26:36 --> Router Class Initialized
DEBUG - 2014-01-18 16:26:36 --> Output Class Initialized
DEBUG - 2014-01-18 16:26:36 --> Security Class Initialized
DEBUG - 2014-01-18 16:26:36 --> Input Class Initialized
DEBUG - 2014-01-18 16:26:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 16:26:36 --> Language Class Initialized
DEBUG - 2014-01-18 16:26:36 --> Loader Class Initialized
DEBUG - 2014-01-18 16:26:36 --> Helper loaded: url_helper
DEBUG - 2014-01-18 16:26:36 --> Helper loaded: form_helper
DEBUG - 2014-01-18 16:26:36 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 16:26:36 --> Database Driver Class Initialized
DEBUG - 2014-01-18 16:26:36 --> Session Class Initialized
DEBUG - 2014-01-18 16:26:36 --> Helper loaded: string_helper
DEBUG - 2014-01-18 16:26:36 --> Session routines successfully run
DEBUG - 2014-01-18 16:26:36 --> User Agent Class Initialized
DEBUG - 2014-01-18 16:26:36 --> Form Validation Class Initialized
DEBUG - 2014-01-18 16:26:36 --> Model Class Initialized
DEBUG - 2014-01-18 16:26:36 --> Model Class Initialized
DEBUG - 2014-01-18 16:26:36 --> Controller Class Initialized
DEBUG - 2014-01-18 16:26:36 --> Config Class Initialized
DEBUG - 2014-01-18 16:26:36 --> Hooks Class Initialized
DEBUG - 2014-01-18 16:26:36 --> Utf8 Class Initialized
DEBUG - 2014-01-18 16:26:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-18 16:26:36 --> URI Class Initialized
DEBUG - 2014-01-18 16:26:36 --> Router Class Initialized
DEBUG - 2014-01-18 16:26:36 --> No URI present. Default controller set.
DEBUG - 2014-01-18 16:26:36 --> Output Class Initialized
DEBUG - 2014-01-18 16:26:36 --> Security Class Initialized
DEBUG - 2014-01-18 16:26:36 --> Input Class Initialized
DEBUG - 2014-01-18 16:26:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-18 16:26:36 --> Language Class Initialized
DEBUG - 2014-01-18 16:26:36 --> Loader Class Initialized
DEBUG - 2014-01-18 16:26:36 --> Helper loaded: url_helper
DEBUG - 2014-01-18 16:26:36 --> Helper loaded: form_helper
DEBUG - 2014-01-18 16:26:36 --> Helper loaded: custom_helper
DEBUG - 2014-01-18 16:26:36 --> Database Driver Class Initialized
DEBUG - 2014-01-18 16:26:36 --> Session Class Initialized
DEBUG - 2014-01-18 16:26:36 --> Helper loaded: string_helper
DEBUG - 2014-01-18 16:26:36 --> Session routines successfully run
DEBUG - 2014-01-18 16:26:36 --> User Agent Class Initialized
DEBUG - 2014-01-18 16:26:36 --> Form Validation Class Initialized
DEBUG - 2014-01-18 16:26:36 --> Model Class Initialized
DEBUG - 2014-01-18 16:26:36 --> Model Class Initialized
DEBUG - 2014-01-18 16:26:36 --> Controller Class Initialized
DEBUG - 2014-01-18 16:26:36 --> File loaded: application/views/user/login.php
DEBUG - 2014-01-18 16:26:36 --> File loaded: application/views/index.php
DEBUG - 2014-01-18 16:26:36 --> Final output sent to browser
DEBUG - 2014-01-18 16:26:36 --> Total execution time: 0.0530
